

<?php $__env->startSection('title', 'Api Key'); ?>


<?php echo $__env->make('admin.components.styles', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



<?php $__env->startSection('body'); ?>


        <div class="row mt-4">
            <div class="col">
                <div class="card mb-0">
                    <div class="card-header">
                        <i class="fas fa-key"></i> API Keys
                        <a class="btn btn-primary btn-sm pull-right m-b-0 add" href="#" data-toggle="modal" data-target="#addApiKey" role="button"><i class="fa fa-plus"></i>&nbsp; New</a>

                    </div>
                    <div  class="col-md-12  pt-4" style="background:white;  display: flex;  flex-wrap: wrap; flex-direction: row; justify-content: center;">
                        


                        <form id="filter-form" style="display:flex; align-items:center;  flex-wrap: wrap; justify-content: space-between; margin-bottom: 0px;">

                            <label for="from_date" class="me-2 h4"  ></label>
                            <input type="date" id="from_date"class="me-2 form-control"   name="from_date"  style="width:40%;">

                            <label for="to_date" class="me-2 h4" >-</label>
                            <input type="date" id="to_date" class="me-2 form-control" name="to_date"  style="width:40%;">

                            <button type="submit" class=" me-2 btn btn-primary" style="padding: 9px;"><i class="fas fa-check"></i></button>
                            
                        </form>

                    </div>
                    
                    </div>


                    <div class="card-body" v-cloak>

                        <?php if(session()->has('message')): ?>
                            <div class="alert alert-success alert-dismissible fade show" role="alert">
                                <strong>Success</strong> &nbsp; <?php echo e(session()->get('message')); ?>

                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>                            
                        <?php endif; ?>

                        <!-- <div class="container">
                            <form id="filter-form" class="filter-form-container row">
                                <div class="col-sm-12 col-md-6 col-lg-5">
                                    <label for="from_date" class="h6">From:</label>
                                    <input type="date" id="from_date" class="form-control">
                                </div>
                                <div class="col-sm-12 col-md-6 col-lg-5">
                                    <label for="to_date" class="h6">To:</label>
                                    <input type="date" id="to_date" class="form-control">
                                </div>
                                <div style="margin-top: 30px;" class="col-sm-12 col-md-6 col-lg-2 applyBtn">
                                    <button type="submit" class="btn btn-sm btn-success">Apply Filter</button>
                                </div>
                            </form>
                        </div> -->

                        <table class="table table-hover apikey-listing table-listing" style="overflow:auto; width:100%;">
                            <thead>
                                <tr>
                                     
                                    <th>ID</th>
                                    <th>Key</th>
                                    <th>Value</th>
                                    <th>Created at</th>
                                    <th>Action</th> 

                                </tr>
                            </thead>
                            <tbody>
                                
                               
                            </tbody>
                        </table>
 

	                  
                    </div>
                </div>
            </div>
        </div>




<div class="modal fade" id="addApiKey" tabindex="-1" role="dialog" saria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-md" role="document">

        <div class="modal-content ">

            <div class="modal-header d-flex justify-content-between">
                <h5 class="modal-title text-dark" id="exampleModalLabel">Add API Key</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>


            <div class="modal-body text-dark">

                <form id="addApiKeyForm"  enctype="multipart/form-data"> 

                    <div id="sending-message" class="text-danger fw-bold"></div>
                    <br>
                        <div class="row d-flex justify-content-center align-items-center">
                            
                                <div class="form-group col-md-12" style="margin-bottom:30px;">

                                    <label class="control-label">Key</label>
                                    <input type="text" name="key" id="key" class="form-control field-radius" required>

                                    <label class="control-label">Value</label>
                                    <input type="text" name="value" id="value" class="form-control field-radius" required>
                                    
                                </div>
                            </div>
                
                            <div class="modal-footer">
                                <button type="submit" class="btn btn-primary">Add</button>
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                            </div>
           
                </form> 
            </div>

        </div>
    </div>
</div>
 




<div class="modal fade" id="editApiKey" tabindex="-1" role="dialog" saria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-md" role="document">
        <div class="modal-content ">

            <div class="modal-header d-flex justify-content-between">
                <h5 class="modal-title text-dark" id="exampleModalLabel">Edit API Key</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>

            </div>

            


            <div class="modal-body text-dark">



                

                    <input type="hidden" name="apikey_id" id="apikey_id">

                    <div id="update-message" class="text-danger fw-bold"></div>
                    <br>
                
                        <div class="row d-flex justify-content-center align-items-center">
                            

                            
                                <div class="form-group col-md-12" style="margin-bottom:30px;">
                                        
                                    <label class="control-label">Key</label>
                                    <input type="text" name="apikey-key" id="apikey-key"  class="form-control field-radius">

                                    <label class="control-label">Value</label>
                                    <input type="text" name="apikey-value" id="apikey-value"  class="form-control field-radius">                                

                                </div>
                            </div>
                
                        <button type="submit" class="btn btn-primary float-lg-right " id="updateApiKeyBtn">Submit</button>
           
                
            </div>

        </div>
    </div>
</div>
<!--      -->




 

<?php $__env->stopSection(); ?>


<script src="https://canvasjs.com/assets/script/canvasjs.min.js"></script>

<script src="https://code.jquery.com/jquery-3.7.0.js"></script>

<script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js" defer></script>

<script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap4.min.js" defer></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.2/css/bootstrap.css">
<link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap4.min.css">


<script type="text/javascript">

    $(function () {
        setTimeout(function () {
            var table = $('.apikey-listing').DataTable({
                processing: true,
                serverSide: true,
                ajax: {
                    url :"<?php echo e(url('/admin/apikeys-list')); ?>",
                    data: function (d) {
                        d.from_date = $('#from_date').val();
                        d.to_date = $('#to_date').val();
                    }
                },

                columns: [
                    {data: 'id', name: 'id'},
                    {data: 'key', name: 'key'},
                    {data: 'value', name: 'value'},
                    {data: 'created', name: 'created'},
                    {
                        data: 'action', 
                        name: 'action', 
                        orderable: false, 
                        searchable: false
                    },
                ],
                order: [[0, 'desc']],

            });

            $('#filter-form').on('submit', function (e) {
                e.preventDefault();
                $('.apikey-listing').DataTable().ajax.reload();
            }); 
        }, 2000); 
    });
</script>



<script>
   $(document).ready(function() {

        $('.add').click(function() {
            $('#addApiKey').modal('show');
        });

        $('#addApiKeyForm').submit(function(e) {
        e.preventDefault(); 


        var form = $(this);
        var formData = new FormData(form[0]);

        var csrfToken = document.querySelector('meta[name="csrf-token"]').getAttribute('content');

        $('#sending-message').text('Processing request, please wait...');

        $.ajax({
        url: "<?php echo e(url('admin/add-apikey')); ?>", 
        type: "POST",
        headers: {
          'X-CSRF-TOKEN': csrfToken
        },
        data: formData,
        contentType: false,
        processData: false,
        success: function(response) {
            

        },
        error: function(xhr) {
            // Handle error response
            $('#sending-message').text(xhr);
            console.log(xhr.responseText);
        },
        complete: function() {
            $('#sending-message').text('');
            $('#addApiKey').modal('hide');
            // $('.apikey-listing').DataTable().ajax.reload();
            location.reload();

        }
        });

    });

    });

</script>



<script>
    $(document).ready(function () {
       
        $(document).on('click','.status' ,function () {
            var apikey_id = $(this).val();

            console.log(apikey_id);


            $('#editApiKey').modal('show');

            $.ajax({
                type: "GET",
                url: "/admin/edit-apikey/"+apikey_id,
                dataType:"json",
                success: function (response) {
                    console.log(response);

                    $('#apikey_id').val(apikey_id);
                    $('#apikey-key').val(response.apikey.key);
                    $('#apikey-value').val(response.apikey.value);

                }
            });
        });
    });
</script>




<script>

    $(document).ready(function() {
         $('#updateApiKeyBtn').on('click', function() {
            
            var apikey_id = $('#apikey_id').val();
            var key = $('#apikey-key').val();
            var value = $('#apikey-value').val();

            $('#update-message').text('Processing request, please wait...');

                $.ajax({
                    url: '/admin/update-apikey',
                    type: 'GET',
                    data: {

                        'apikey_id': apikey_id,
                        'key': key,
                        'value': value,

                    },
                    success: function(response) {
                        
                        // $('#editApiKey').modal('hide');
                        // $('.apikey-listing').DataTable().ajax.reload();

                    },
                    error: function(xhr) {
                        $('#update-message').text(xhr);
                    },
                    complete: function() {
                        $('#update-message').text('');
                        $('#editApiKey').modal('hide');
                        $('.apikey-listing').DataTable().ajax.reload();
                    }
                });
            });
        });

</script>
<?php echo $__env->make('brackets/admin-ui::admin.layout.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\backend-zitransfer\src\resources\views/admin/apikey/index.blade.php ENDPATH**/ ?>