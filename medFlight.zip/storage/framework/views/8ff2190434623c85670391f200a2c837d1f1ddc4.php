<footer class="app-footer">
    <div class="container-fluid">
        
    </div>
</footer><?php /**PATH C:\xampp\htdocs\medFlight\vendor\brackets\admin-ui\src/../resources/views/admin/partials/footer.blade.php ENDPATH**/ ?>