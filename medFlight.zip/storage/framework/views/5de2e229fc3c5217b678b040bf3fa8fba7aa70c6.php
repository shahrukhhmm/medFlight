<!-- font awesome -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css"
    integrity="sha512-MV7K8+y+gLIBoVD59lQIYicR65iaqukzvf/nwasF0nqhPay5w/9lJmVM2hMDcnK1OnMGCdVK+iQrJ7lzPJQd1w=="
    crossorigin="anonymous" referrerpolicy="no-referrer" />


<div class="sidebar">
    <nav class="sidebar-nav">
        <ul class="nav">
            <li class="nav-title"><?php echo e(trans('brackets/admin-ui::admin.sidebar.content')); ?></li>
            



            <li class="nav-title"><?php echo e(trans('brackets/admin-ui::admin.sidebar.settings')); ?></li>
            <li class="nav-item"><a class="nav-link" href="<?php echo e(url('admin/dashboard')); ?>"><i class="nav-icon fas fa-bars"
                        style="color: white;"></i>
                    Dashboard</a></li>
            <li class="nav-item"><a class="nav-link" href="<?php echo e(url('admin/countries')); ?>">
                <i class="nav-icon fas fa-flag" style="color:white;"></i>Countries</a>
            </li>

            <li class="nav-item"><a class="nav-link" href="<?php echo e(url('admin/visitors-all')); ?>">
                <i class="nav-icon fas fa-users" style="color:white;"></i>Visitors</a>
            </li>

            <li class="nav-item"><a class="nav-link" href="<?php echo e(url('admin/api-keys')); ?>">
                <i class="nav-icon fas fa-key" style="color:white;"></i>API Keys</a>
            </li>

            <li class="nav-item"><a class="nav-link" href="<?php echo e(url('admin/users-all')); ?>">
                <i class="nav-icon fas fa-user" style="color:white;"></i>Users</a>
            </li>

            

            <li class="nav-item"><a class="nav-link" href="<?php echo e(url('admin/file-page')); ?>">
                <i class="nav-icon fas fa-file" style="color:white;"></i>Files</a>
            </li>

            <li class="nav-item"><a class="nav-link" href="<?php echo e(url('admin/advertisments')); ?>">
                <i class="nav-icon fas fa-bullhorn" style="color:white;"></i>Advertisements</a>
            </li>

            <li class="nav-item"><a class="nav-link" href="<?php echo e(url('admin/themes')); ?>">
                <i class="nav-icon fas fa-paint-brush" style="color:white;"></i>Themes</a>
            </li>



            <li class="nav-item"><a class="nav-link" href="<?php echo e(url('admin/admin-users')); ?>"><i
                        class="nav-icon fas fa-cogs" style="color:white;"></i> <?php echo e(__('Manage access')); ?></a></li>
            <!-- <li class="nav-item"><a class="nav-link" href="<?php echo e(url('admin/translations')); ?>"><i class="nav-icon icon-location-pin"></i> <?php echo e(__('Translations')); ?></a></li> -->
            
            
        </ul>
    </nav>
    <button class="sidebar-minimizer brand-minimizer" type="button"></button>
</div>
<?php /**PATH C:\xampp\htdocs\backend-zitransfer\src\resources\views/admin/layout/sidebar.blade.php ENDPATH**/ ?>