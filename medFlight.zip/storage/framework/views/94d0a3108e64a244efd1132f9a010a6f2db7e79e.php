<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <?php if(session('error')): ?>
        <div class="alert alert-danger">
            <?php echo e(session('error')); ?>

        </div>
    <?php endif; ?>
    <form action="<?php echo e(url('/submit-word-to-pdf')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <input type="file" name="word_file" placeholder="Upload word file">
        <button type="submit">Submit</button>
    </form>
</body>
</html><?php /**PATH C:\xampp\htdocs\backend-zitransfer\src\resources\views/admin/txt-to-pdf/index.blade.php ENDPATH**/ ?>