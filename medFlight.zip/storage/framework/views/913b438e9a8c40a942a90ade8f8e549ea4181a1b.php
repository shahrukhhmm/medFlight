

<?php $__env->startSection('title', 'Country'); ?>


<?php echo $__env->make('admin.components.styles', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('body'); ?>


        <div class="row mt-4">
            <div class="col">
                <div class="card">

                    <div class="card-header">
                        <i class="fa fa-align-justify"></i> Countries
                        <a class="btn btn-primary btn-sm pull-right m-b-0 add" href="#" data-toggle="modal" data-target="#addCountry" role="button"><i class="fa fa-plus"></i>&nbsp; New</a>

                    </div>

                    <div  class="col-md-12 pt-4" style="background:white;  display: flex;  flex-wrap: wrap; flex-direction: row; justify-content: center;">
                        
                        <p style="margin-top: 14px;"></p>


                        <form id="filter-form" style="display:flex; align-items:center;  flex-wrap: wrap; justify-content: space-between; margin-bottom: 0px;">

                            <label for="from_date" class="me-2 h4"  ></label>
                            <input type="date" id="from_date"class="me-2 form-control"   name="from_date"  style="width:40%;">

                            <label for="to_date" class="me-2 h4" >-</label>
                            <input type="date" id="to_date" class="me-2 form-control" name="to_date"  style="width:40%;">

                            <button type="submit" class=" me-2 btn btn-primary" style="padding: 9px;"><i class="fas fa-check"></i></button>
                            
                        </form>

                    </div>




                    <div class="card-body" v-cloak>

                        <?php if(session()->has('message')): ?>
                            <div class="alert alert-success alert-dismissible fade show" role="alert">
                                <strong>Success</strong> &nbsp; <?php echo e(session()->get('message')); ?>

                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>                            
                        <?php endif; ?>

                        <!-- <div class="container">
                            <form id="filter-form" class="filter-form-container row">
                                <div class="col-sm-12 col-md-6 col-lg-5">
                                    <label for="from_date" class="h6">From:</label>
                                    <input type="date" id="from_date" class="form-control">
                                </div>
                                <div class="col-sm-12 col-md-6 col-lg-5">
                                    <label for="to_date" class="h6">To:</label>
                                    <input type="date" id="to_date" class="form-control">
                                </div>
                                <div style="margin-top: 30px;" class="col-sm-12 col-md-6 col-lg-2 applyBtn">
                                    <button type="submit" class="btn btn-sm btn-success">Apply Filter</button>
                                </div>
                            </form>
                        </div> -->


                        <table class="datatables-basic table table-hover country-listing table-listing" style="overflow:auto; width:100%;">
                            <thead>
                                <tr>
                                <th>ID</th>
                                <th>Country Name</th>
                                <th>Display Name</th>
                                <th>Currency Symbol</th>
                                <th>Country Code</th>
                                <th>Status</th>
                                <th>Language</th>
                                <th>Created at</th>    
                                <th>Flags</th>            
                                <th>Action</th>
                                </tr>
                            </thead>
                        </table>
 
                    </div>
                </div>
            </div>
        </div>



    


    <div class="modal fade" id="addCountry" tabindex="-1" role="dialog" saria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-md" role="document">

            <div class="modal-content ">

                <div class="modal-header d-flex justify-content-between">
                    <h5 class="modal-title text-dark" id="exampleModalLabel">Add Country</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>

                <div class="modal-body text-dark">
                        <form id="addCountryForm"  enctype="multipart/form-data">

                            <input type="hidden" name="document_url" id="document_url">

                            <div id="sending-message" class="text-danger fw-bold"></div>
                        
                    
                            <div class="row d-flex justify-content-center align-items-center">
                                
                            <div class="form-group col-md-12">

                                <label class="control-label mt-2">Name</label>
                                <input type="text" name="country_name" id="country_name" class="form-control field-radius" required>

                                <label class="control-label mt-2">Display Name</label>
                                <input type="text" name="name_display" id="name_display" class="form-control field-radius" required>

                                <label class="control-label mt-2">Symbol</label>
                                <input type="text" name="currency_symbol" id="currency_symbol" class="form-control field-radius" required>

                                <label class="control-label mt-2">Code</label>
                                <input type="text" name="country_code" id="country_code" class="form-control field-radius" required>

                                <label class="control-label mt-2">Status</label>
                                <input type="text" name="status" id="status" class="form-control field-radius" required>

                                <label class="control-label mt-2">Language</label>
                                <input type="text" name="language" id="language" class="form-control field-radius" required>

                                <div class="form-group  mt-3" id="docGroup" style="margin-top: 15px;">
                                    <label for="add_image" class="form-label">Upload Image:</label>
                                    <input type="file" class="form-control field-radius" id="add_image" name="add_image" aria-label="add_image" required>
                                    <div class="invalid-feedback">
                                        Please select a file.
                                    </div>
                                </div>

                                <br>
                                <div id="progress-bar-container" class="progress" style="display: none;">
                                    <div class="progress-bar progress-bar-striped progress-bar-animated" id="progress-bar" role="progressbar" style="width: 0%;" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100"></div>
                                </div>

                            </div>
                                    
                            </div>
                    
                            <button type="submit" class="btn btn-primary float-lg-right " id="addCountryBtn">Submit</button>
            
                        </form>
                </div>

            </div>
        </div>
    </div>


 



<div class="modal fade" id="editCountry" tabindex="-1" role="dialog" saria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-md" role="document">

        <div class="modal-content ">

            <div class="modal-header d-flex justify-content-between">
                <h5 class="modal-title text-dark" id="exampleModalLabel">Edit Country</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>

            <div class="modal-body text-dark">
                

                    <input type="hidden" name="country_id" id="country_id">                                
                    <input type="hidden" name="flag_url" id="flag_url">

                    <div id="update-message" class="text-danger fw-bold"></div>
                
                        <div class="row d-flex justify-content-center align-items-center">
                            
                            
                                <div class="form-group col-md-12">

                                <label class="control-label mt-3">Name</label>
                                <input type="text" name="name" id="name" class="form-control field-radius">

                                <label class="control-label mt-3">Display Name</label>
                                <input type="text" name="display_name" id="display_name" class="form-control field-radius">

                                <label class="control-label mt-3">Symbol</label>
                                <input type="text" name="symbol" id="symbol" class="form-control field-radius">

                                <label class="control-label mt-3">Code</label>
                                <input type="text" name="code" id="code" class="form-control field-radius">

                                <label class="control-label mt-3">Status</label>
                                <input type="text" name="country_status" id="country_status" class="form-control field-radius">

                                <label class="control-label mt-3">Language</label>
                                <input type="text" name="country_lang" id="country_lang" class="form-control field-radius">

                                <div class="form-group mt-3" style="margin-top: 15px;">
                                    <label for="flag_image" class="form-label">Upload Document:</label>
                                    <input type="file" class="form-control field-radius" id="flag_image" name="flag_image" aria-label="flag_image">
                                    <div class="invalid-feedback">
                                        Please select a file.
                                    </div>
                                </div>

                                <br>
                                <div id="update-bar-container" class="progress" style="display: none;">
                                    <div class="progress-bar progress-bar-striped progress-bar-animated update-bar" id="update-bar" role="progressbar" style="width: 0%;" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100"></div>
                                </div>

                                </div>
                            </div>
                
                        <button type="submit" class="btn btn-primary float-lg-right " id="updateCountryBtn">Submit</button>
           
                
            </div>

        </div>
    </div>
</div>



<?php $__env->stopSection(); ?>



<script src="https://canvasjs.com/assets/script/canvasjs.min.js"></script>


<script src="https://code.jquery.com/jquery-3.7.0.js"></script>

<script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js" defer></script>

<script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap4.min.js" defer></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.2/css/bootstrap.css">
<link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap4.min.css">



<script src="https://www.gstatic.com/firebasejs/8.10.0/firebase-app.js"></script>
<script src="https://www.gstatic.com/firebasejs/8.10.0/firebase-storage.js"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>



<script type="text/javascript">

    $(function () {
        setTimeout(function () {
        var table = $('.country-listing').DataTable({
          processing: true,
          serverSide: true,
          ajax: {
            url :"<?php echo e(url('admin/countries-list')); ?>",
            data: function (d) {
            d.from_date = $('#from_date').val();
            d.to_date = $('#to_date').val();
            console.log(d);
        }
        },

          columns: [
            {data: 'id', name: 'id'},
            {data: 'name', name: 'name'},
            {data: 'display_name', name: 'display_name'},
            {data: 'currency_symbol', name: 'currency_symbol'},
            {data: 'country_code', name: 'country_code'},
            {data: 'status', name: 'status'},
            {data: 'language', name: 'language'},
            {data: 'created', name: 'created'},
            {data: 'image', name: 'image'},

            {
                data: 'action', 
                name: 'action', 
                orderable: false, 
                searchable: false
            },

            ],

            order: [[0, 'desc']],

        });

        $('#filter-form').on('submit', function (e) {
            e.preventDefault();
            $('.country-listing').DataTable().ajax.reload();
        });

        }, 2000); 
    });
</script>


<script>

    //  add image on firebase
    function addImage(callback) {
   
        var add_image = document.getElementById("add_image").files[0];
        var progressBarContainer = document.getElementById("progress-bar-container");
        var progressBar = progressBarContainer.querySelector('.progress-bar');


        console.log(add_image);

        var defaultURL = $('#flag_url').val();

        if (!add_image) {
            // Handle the case when no image is selected
            console.log("No image selected");
            callback(defaultURL);
        }
        else{

            console.log(add_image);

            var imageName = add_image.name;
            var fileExtension = imageName.split('.').pop();
            var country_id = $('#country_id').val();
            var country_name = $('#display_name').val();


            var filename = country_id + '-' + country_name  + '-' + 'FLAG-URL' + '.' + fileExtension;

            if (!firebase.apps.length) {
                var firebaseConfig = {
                    // Firebase configuration here
                    apiKey: "AIzaSyBJ1gcj2pOwPthdw4K-tM_p5zwpB9xfJL8",
                    authDomain: "zimo-b9759.firebaseapp.com",
                    projectId: "zimo-b9759",
                    storageBucket: "zimo-b9759.appspot.com",
                    messagingSenderId: "737223151713",
                    appId: "1:737223151713:web:4f1b8f4dc7397f7d21da20",
                    measurementId: "G-528XETL5TK"
                };

                firebase.initializeApp(firebaseConfig);
            }

            // Get a reference to the storage service
            var storage = firebase.storage();

            var storageRef = firebase.storage().ref('zimo/flags/' + filename);
            // Check if the file exists before deleting
            // storageRef.getDownloadURL().then(function(url) {

            //     // File exists, proceed with deletion
            //     storageRef.delete().then(function() {
                    
            //     }); 
            // });

            var uploadTask = storageRef.put(add_image);

            // uploadTask.on('state_changed', function(snapshot) {
            // var progress = (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
            // console.log("Upload is " + progress + "% done");
            // }, 
            uploadTask.on('state_changed', function(snapshot) {
                var progress = (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
                progressBar.style.width = progress + '%';
                progressBar.setAttribute('aria-valuenow', progress);
                progressBar.innerText = progress.toFixed(2) + '%'; // Update the progress text


            }, function(error) {
                console.log(error.message);
            }, function() {
                uploadTask.snapshot.ref.getDownloadURL().then(function(downloadURL) {
                    progressBarContainer.style.display = 'none';
                    var url = downloadURL;
                    callback(url);
                    console.log(url);
                });
            });
            progressBarContainer.style.display = 'block';
        }
    }

    //  update image on firebase

    function updateImage(callback) {
        
        var flag_image = document.getElementById("flag_image").files[0];
        var updateBarContainer = document.getElementById("update-bar-container");
        var updateBar = updateBarContainer.querySelector('.update-bar');



        console.log(flag_image);

        var defaultURL = $('#flag_url').val();

        if (!flag_image) {
            // Handle the case when no image is selected
            console.log("No image selected");
            callback(defaultURL);
        }
        else{

            console.log(flag_image);

            var imageName = flag_image.name;
            var fileExtension = imageName.split('.').pop();
            var country_id = $('#country_id').val();
            var country_name = $('#display_name').val();


            var filename = country_id + '-' + country_name  + '-' + 'FLAG-URL' + '.' + fileExtension;

            if (!firebase.apps.length) {
                var firebaseConfig = {
                    // Firebase configuration here
                    apiKey: "AIzaSyBJ1gcj2pOwPthdw4K-tM_p5zwpB9xfJL8",
                    authDomain: "zimo-b9759.firebaseapp.com",
                    projectId: "zimo-b9759",
                    storageBucket: "zimo-b9759.appspot.com",
                    messagingSenderId: "737223151713",
                    appId: "1:737223151713:web:4f1b8f4dc7397f7d21da20",
                    measurementId: "G-528XETL5TK"
                };

                firebase.initializeApp(firebaseConfig);
            }

            // Get a reference to the storage service
            var storage = firebase.storage();

            var storageRef = firebase.storage().ref('zimo/flags/' + filename);

            var uploadTask = storageRef.put(flag_image);

            uploadTask.on('state_changed', function(snapshot) {

                var progress = (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
                updateBar.style.width = progress + '%';
                updateBar.setAttribute('aria-valuenow', progress);
                updateBar.innerText = progress.toFixed(2) + '%'; // Update the progress text

            // var progress = (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
            // console.log("Upload is " + progress + "% done");
            }, 
            function(error) {
                console.log(error.message);
            },
            function() {
                uploadTask.snapshot.ref.getDownloadURL().then(function(downloadURL) {
                    updateBarContainer.style.display = 'none';
                    var url = downloadURL;
                    callback(url);
                    console.log(url);
                });
            });
            updateBarContainer.style.display = 'block';

        }
    }

</script>





<script>
    $(document).ready(function() {

        $('.add').click(function() {
            $('#addCountry').modal('show');
        });

        $('#addCountryForm').submit(function(e) {
            e.preventDefault(); 


            var form = $(this);
            var formData = new FormData(form[0]);

            addImage(function(url) {

                var csrfToken = document.querySelector('meta[name="csrf-token"]').getAttribute('content');

                var url = formData.append('document_url', url);

                console.log(url);

                $('#sending-message').text('Processing request, please wait...');

                $.ajax({
                    url: "<?php echo e(url('admin/add-country')); ?>", 
                    type: "POST",
                    headers: {
                    'X-CSRF-TOKEN': csrfToken
                    },
                    data: formData,
                    contentType: false,
                    processData: false,
                    success: function(response) {
                        
                        // $('.country-listing').DataTable().ajax.reload();

                    },
                    error: function(xhr) {
                        // Handle error response
                        $('#sending-message').text(xhr);
                        console.log(xhr.responseText);
                    },
                    complete: function(){
                        $('#sending-message').text('');
                        $('#addCountry').modal('hide');
                        location.reload();
                        // $('.country-listing').DataTable().ajax.reload();
                    }
                });

            });

        });
    });

</script>






<script>
    $(document).ready(function () {
       
        $(document).on('click','.status' ,function () {
            var country_id = $(this).val();

            console.log(country_id);


            $('#editCountry').modal('show');

            $.ajax({
                type: "GET",
                url: "/admin/edit-country/"+country_id,
                success: function (response) {
                    console.log(response);
                    $('#country_id').val(country_id);
                    
                    // $('#country_name').val(response.country.name);
                    $('#name').val(response.country.name);
                    $('#display_name').val(response.country.display_name);
                    $('#symbol').val(response.country.currency_symbol);
                    $('#code').val(response.country.country_code);
                    $('#country_status').val(response.country.status);
                    $('#country_lang').val(response.country.language);
                    $('#flag_url').val(response.country.flag_url);

                }
            });
        });
    });
</script>




<script>

    $(document).ready(function() {
        $('#updateCountryBtn').on('click', function() {
            
            var country_id = $('#country_id').val();

            var name = $('#name').val();

            var display_name = $('#display_name').val();

            var currency_symbol = $('#symbol').val();

            var country_code = $('#code').val();

            var status = $('#country_status').val();

            var language = $('#country_lang').val();

            var flag_url = $('#flag_url').val();
        
            console.log(flag_url);

            
            updateImage(function(url) {


                $('#update-message').text('Processing request, please wait...');

                $.ajax({
                    url: '/admin/update-country',
                    type: 'GET',
                    data: {
                        'country_id': country_id,
                        'name': name,
                        'display_name': display_name,
                        'currency_symbol': currency_symbol,
                        'country_code': country_code,
                        'status': status,
                        'language': language,
                        'flag_url': url
                    },
                    success: function(response) {
                    },
                    error: function(xhr) {

                        $('#update-message').text(xhr);
                    },
                    complete: function() {
                        $('#update-message').text('');
                        $('#flag_image').val('');
                        $('#editCountry').modal('hide');
                        $('.country-listing').DataTable().ajax.reload();
                    }
                });
            });
        });
    });

</script>

<?php echo $__env->make('brackets/admin-ui::admin.layout.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\backend-zitransfer\src\resources\views/admin/countries/index.blade.php ENDPATH**/ ?>