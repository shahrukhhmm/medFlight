<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>ZiTransfer</title>

        <style>
            *{
                font-family:'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;
                margin: 0;padding: 0;box-sizing: border-box;
                font-weight: 400;
            }

            body{
                background-color: white;
                letter-spacing: 3px;
            }

            #main{
                background-color: white;
                max-width: 592px;
                margin: auto;
                border-left: 2px solid #e1e1e1;
                border-right: 2px solid #e1e1e1;
                padding: 10px;
            }

            .card{
                padding-right: 30px;
                padding-left: 30px;
                padding-top: 10px;
                padding-bottom: 10px;
            }

            .logo{
                width: 190px;
                height: 46px;
                padding: 8px;
                display: inline-block;
                margin-left: 158px;
            }

            .top-corner-text{
                display: inline-block;
                vertical-align: middle; 
                margin-left: 36px;
            }

            .text{
                font-size: 12px;
                letter-spacing: 1px;
                text-align: center;
   
            }
            
            .head-text{
                letter-spacing: 1.8px;
                font-size: 15px;
                text-align: center;
            }

            .body-text{
                font-size: 12px;
                letter-spacing: 1px;
                line-height: 16px;
                font-weight:500;
            }

            .link{
                color: black;
                font-weight: 600;
                text-decoration: underline;
            }

            .mt{
                margin-top:7px;
            }

            .bold{
                font-weight: 600;
                font-size:19px;
                letter-spacing: 2px;
            }
            .spacing{
                letter-spacing: 1px;
                font-size: 10px;
                margin-top: 7px;
            }

            .ztfr-logo{
                width: 106px;
                margin-top: 20px;
            }

            .transfer-text{
                display: inline-block;
                vertical-align: text-bottom;
                font-size: 13px;
                font-weight: 600;
                letter-spacing: 1.7px;
                margin-bottom: 16px;
                margin-left: 5px;
            }

            .arrow{
                width: 8px;
                margin-left: 2px;
                vertical-align: bottom;
            }

            .share-logos{
                text-align: center;
                margin-top: 9px;
            }

            .share-logos img{
                display: inline-block;
                margin: 0px 5px;
                width: 11%;
                padding-bottom: 12px;
            }

            .id-text{
                letter-spacing: 2px;
                font-size: 14px;
                font-weight: 600;
                font-family: monospace;
            }

            h2 span{
                font-family: monospace;
                font-size: 26px;
            }

            .info{
                letter-spacing: 0.7px;
                font-weight: 400;
                font-family: monospace; 
            }

            .detailsQR{
                display: inline-block;
                width: 25%;
                border: 1px solid #999999;
                border-radius: 8px;
                margin-left: 71px;
                padding: 10px;
            }
            .caption{
                margin-left: 262px;
                font-size: 10px;
                letter-spacing: 1.2px;
                margin-top:6px;
            }

            .heading{
                display: inline-block; 
                margin-left: 65px;
            }

            .tick{
                width: 37%;
            }

            .brands-card{
                margin-left: 45px;
                margin-right: 45px;
                border-top: 1px solid black;
                border-bottom: 1px solid black;
                margin-top: 20px;
            }
            
            .brands-container{
                text-align: center;
                margin-top: 20px;
                margin-bottom: 40px;

            }
            
            .brands{
                display: inline-block;
                width: 10%;
                margin: 0px 17px;
            }

            .brands:first-child {
                margin-left: 0;
            }

            .brands:last-child {
                margin-right: 0;
            }

            .zimo-img{
                width: 13%;
            }
            .footer-top{
                width:10%;
                margin-top: 20px; 
            }
            
            .zimo-group{
                text-align: center;
            }
            .zimo-group p{
                display: inline-block; 
                font-size: 8px;
                letter-spacing: 1px;
                word-spacing: 2px;
            }

            .zimo-group img{
                display: inline-block; 
                margin-left: 4px;
                width: 11px;
                vertical-align: bottom;
            }

            .copyright-text{
                font-size: 8px;
                letter-spacing: 1px;
                word-spacing: 2px;
                margin-top: 10px;
                margin-left: 155px;
            }

            .copyright-text img{
                width: 62px;
                margin-left: 68px;
            }

            .end-note{
                text-align: center;
                font-size: 8px;
                letter-spacing: 1px;
                word-spacing: 0px;
                margin-top: 20px;
            }

            .end-note img{
                width: 1%;
                margin-right: 5px;
            }


            @media  only screen and (max-width: 590px) {
                .text{
                    font-size: 11px;
                }

                .body-text{
                    font-size: 11px;
                }

                .brands{
                    margin: 0px 17px;
                }
             
                .copyright-text img {
                    width: 55px;
                    margin-left: 55px;
                }


            }

            @media  only screen and (max-width: 575px) {
            
                .copyright-text img {
                    width: 53px;
                    margin-left: 57px;
                }
                .copyright-text {
                    word-spacing: 1px;
                }
                .share-logos img {
                    margin: 0px 2px;
                }

            }

            @media  only screen and (max-width: 559px) {

                .top-corner-text {
                    
                    margin-left: 30px;
                }
                .brands{
                    margin: 0px 16px;
                }

                .copyright-text img {
                    margin-left: 43px;
                }
                

            }

            @media  only screen and (max-width: 545px) {

                .logo{
                    margin-left: 98px;
                }

                .copyright-text img {
                    margin-left: 33px;
                    width: 41px;
                }

                .card {
                    padding-right: 28px;
                    padding-left: 28px;
                }


            }
            @media  only screen and (max-width: 519px) {
               

                .card{
                    padding-right: 25px;
                    padding-left: 25px;
                }
                .top-corner-text {
                    margin-left: 13px;
                }
                .brands-card {
                    margin-left: 40px;
                    margin-right: 40px;
                }

                .copyright-text{
                    margin-left: 102px;
                }
                .copyright-text img {
                    margin-left: 50px;
                }
            }

            @media  only screen and (max-width: 482px) {

                .logo {
                    margin-left: 70px;
                }

                .top-corner-text{
                    margin-left: 0px;
                }

               
                .caption{
                    font-size: 8px;
                    margin-left: 184px;
                    letter-spacing: 0.7px;
                }

                .heading{
                    margin-left: 23px;
                }

                .brands-card {
                    margin-left: 30px;
                    margin-right: 30px;
                }
                .brands {
                    margin: 0px 15px;
                }

                .body-text {
                    letter-spacing: 0.7px;
                }
                .copyright-text {
                    margin-left: 47px;
                }
                
                .copyright-text img {
                    width: 44px;
                    margin-left: 53px;
                }
            }

            @media  only screen and (max-width: 445px) {

                .logo{
                    margin-left: 56px;
                }

                .brands {
                    margin: 0px 13px;
                }


                .copyright-text {
                    margin-left: 56px;
                }
                
                .copyright-text img {
                    width: 42px;
                    margin-left: 8px;
                }
            }

            @media  only screen and (max-width: 425px) {
                
                .logo {
                    margin-left: 68px;
                    width: 160px;
                }
                .head-text{
                    font-size: 13px;
                }

                .yes-its-me p {
                    padding-left: 13px;
                }

                .tick {
                    width: 37%;
                }

                .brands-card{
                    margin-left: 20px;
                    margin-right: 20px;
                }

                .brands {
                    margin: 0px 10px;
                }

                .text {
                    font-size: 10px;
                }
                .copyright-text {
                    margin-left: 56px;
                }

                .copyright-text img {
                    width: 40px;
                    margin-left: 20px;
                }

                .end-note img {
                   width: 2%;
                }
                .share-logos img {
                    margin: 0px 5px;
                    width: 10%;
                }

            }

            @media  only screen and (max-width: 415px) {
                .logo {
                    margin-left: 35px;
                }
            }
            @media  only screen and (max-width: 403px) {
                .card {
                    padding-right: 20px;
                    padding-left: 20px;
                }

                .brands-card {
                    margin-left: 15px;
                    margin-right: 15px;
                }
                .copyright-text img {
                    margin-left: 9px;
                }

                .end-note{
                    font-size: 7px;
                }
                .end-note img{
                    width: 2%;
                }

            }

            @media  only screen and (max-width: 392px) {

                .logo {
                    margin-left: 3px;
                }

                .ztfr-logo {
                    width: 61px;
                }
                .top-corner-text{
                    font-size:10px;

                }
                .transfer-text{
                    font-size:11px
                }
                .brands-card {
                    margin-left: 10px;
                    margin-right: 10px;
                }
                .copyright-text img {
                    margin-left: 0px;
                }

                
                .caption {
                    margin-left: 140px;
                    letter-spacing: 0px;
                }

                .detailsQR {
                    margin-left: 28px;
                    width: 27%;
                }

                .copyright-text{
                    margin-left: 0px;
                }
                .share-logos img {
                    margin: 0px 3px;
                }
            }

            @media  only screen and (max-width: 375px) {

                .card {
                    padding-right: 10px;
                    padding-left: 10px;
                }

                .head-text {
                    font-size: 12px;
                }
                .yes-its-me p{
                    font-size: 13px;
                }
        
                .body-text{
                    letter-spacing: 0.7px;
                }
                .copyright-text {
                    margin-left: 12px;
                }
                .copyright-text img {
                    margin-left: 19px;
                }

            }

            @media  only screen and (max-width: 360px) {
            
                .card {
                    padding-right: 5px;
                    padding-left: 5px;
                }
            
                .ztfr-logo {
                    width: 74px;
                }
                .transfer-text{
                    font-size: 11px;
                }
                .bold {
                    font-size: 18px;
                }
                .arrow {
                    width: 8px;
                }
                
                .copyright-text {
                    margin-left: 8px;
                }
                .copyright-text img {
                    margin-left: 8px;
                }

            }
               

            @media  only screen and (max-width: 344px) {

                .logo{
                    margin-left: 11px;
                }

                

                .brands-container{
                    margin-top: 17px;
                    margin-bottom: 28px;
                }

                .brands{
                    width: 8%;
                }

                .end-note{
                    font-size: 7px;
                }
                .end-note img {
                    width: 2%;
                }

                .copyright-text {
                    margin-left: 5px;
                    font-size:7px;
                }
                .copyright-text img {
                    margin-left: 0px;
                }
            
            }

            @media  only screen and (max-width: 320px) {

                .logo {
                    margin-left: 7px;
                }
                .heading {
                    margin-left: 17px;
                }
                .detailsQR {
                    margin-left: 15px;
                }


                .copyright-text {
                    font-size: 7px;
                    word-spacing: 0px;
                    margin-left: 0px;
                }
                .share-logos img {
                    margin: 0px 2px;
                }
                .top {
                    font-size: 10px;
                }
            
            }

            @media  only screen and (max-width: 306px){
                .logo {
                    margin-left: 3px;
                }
            }

        </style>

    </head>
    <body>

    <div id= "main">
        <div class="card">
            <div class="logo">
                <img src="https://firebasestorage.googleapis.com/v0/b/uploadimage-6caaa.appspot.com/o/images%2FZITRANSFER.png?alt=media&token=e5cfa074-0fcd-4b17-9665-70264b1382d4" width="100%"  alt="ztfr-logo">
            </div>
            
            <div class="top-corner-text">           
                <p class="body-text top" style="text-align: right;">ZTFER786786786<?php echo e(@$receiver_id); ?></p>
                <p class="body-text top" style="text-align: right;">Revision Files</p>
            </div> 

            <p class="text mt" style="text-decoration:none !important; color:black !important;"><?php echo e(@$receiver_email); ?></p>

            <br>
            <h4 class="head-text mt">YOU HAVE BEEN SENT</h4>
            <h4 class="head-text mt">Revision Files</h4>

            <br><br>
            <h4 class="head-text mt">SENT BY</h4>
            <p class="text mt" style="text-decoration:none !important; color:black !important;"><?php echo e(@$sender_email); ?></p>


            <br>
            <p style="display:none;">Thank you for using ZTFR. We'll email you a confirmation in real time as soon as your
                files have been downloaded.
            </p>

            <p class="body-text mt" style="text-shadow: 1px 0 black;">ZTFER786786786<?php echo e(@$receiver_id); ?></p>

            <p class="body-text mt">Revision Files</p>

            <p class="body-text mt">Expires on <?php echo e(@$expiry_date); ?></p>
            
            <br>
            <h3 class="mt bold" style="margin-top: 30px;">DOWNLAOD LINK</h3>

            <p class="body-text mt"><a href="<?php echo e(@$file_link); ?>" class="link info"><?php echo e(@$file_link); ?></a></p>
            
            <br>
            <h3 class="bold" style="margin-top: 20px;"><span  class="bold"><?php echo e(@$file_count); ?></span> ITEM</h3>

            <div class="body-text info mt"> 
                <?php $__currentLoopData = $file_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file_detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                    <p style="margin-bottom: 5px;"><?php echo e($file_detail['file_name']); ?></p>
                    <p style="margin-bottom: 10px;"><?php echo e($file_detail['file_size']); ?> <?php echo e($file_detail['file_unit']); ?></p>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <br>
            <h3 class="bold" style="margin-top: 20px;">MESSAGE</h3>

            <p class="body-text mt"><?php echo e(@$note); ?>

            </p>            

            <br>
            <div style="text-align: center;margin-top:10px; margin-bottom: 45px;">
                <a href="#" style="pointer-events:none;"><img src="https://firebasestorage.googleapis.com/v0/b/uploadimage-6caaa.appspot.com/o/images%2FTick%20Download%20TRANSPARENT%20Large.png?alt=media&token=f97c373d-0c3c-4eb0-b407-792b52ef0609"  class="tick" alt="tick"></a>
                <a href="#" style="pointer-events:none;"><img src="<?php echo e($message->embed($qrcode)); ?>" class="detailsQR" alt="qr-code"></a>
                <p class="mt caption">SCAN TO DOWNLOAD</p> 
            </div>


            <div class="brands-card">

                <p class="text" style="margin-top: 20px;">OUR BRANDS</p>

                <div class="brands-container">
                    <a href="https://zitransfer.com/"><img src="https://firebasestorage.googleapis.com/v0/b/uploadimage-6caaa.appspot.com/o/images%2FZTFR.png?alt=media&token=291a63d9-8fbe-4025-824d-c5c7701fec74" class="brands" alt="ztfr"></a>
                    <a href="https://zimomeet.com/"><img src="https://firebasestorage.googleapis.com/v0/b/uploadimage-6caaa.appspot.com/o/images%2FZIMO%20MEET.png?alt=media&token=207ff61c-3154-482b-ae1d-d6a5b6b3d201" class="brands" alt="zimo-meet"></a>
                    <a href="https://zimogroup.org/"><img src="https://firebasestorage.googleapis.com/v0/b/uploadimage-6caaa.appspot.com/o/images%2FZIMO%20(thicker)%20updated%20B.png?alt=media&token=558db11a-1798-4907-bb06-9f09f60a2601" class="brands zimo-img" alt="zimo"></a>
                    <a href="#"><img src="https://firebasestorage.googleapis.com/v0/b/uploadimage-6caaa.appspot.com/o/images%2FZiDoc%20with%20Sec%20Lock.png?alt=media&token=b97fbdfd-01e4-4393-9bc7-9c0df71f1acb" class="brands" alt="zimo-doc"></a>
                    <a href="#"><img src="https://firebasestorage.googleapis.com/v0/b/uploadimage-6caaa.appspot.com/o/images%2FZIMO%20BRICK%20AI.png?alt=media&token=1375e38e-b2e3-47ae-bceb-b9cab4bdf383" class="brands" alt="zimo-ai"></a>
                </div>

            </div>

            <p class="text" style="margin-top: 33px;  text-align: left; text-decoration:none !important; color:black;">To make sure our emails arrive, please add noreply@zitransfer.com to your contact.</p>

            <div class="mt" style="text-align: center;">
                <a href="https://zitransfer.com/" style="text-decoration: none;">
                    <img src="https://firebasestorage.googleapis.com/v0/b/uploadimage-6caaa.appspot.com/o/images%2FZTFR.png?alt=media&token=291a63d9-8fbe-4025-824d-c5c7701fec74" class="footer-top" alt="ztfr">
                </a>    
            </div>

            <div class="zimo-group">
                <p>ZIMO GROUP LONDON UNITED KINGDOM <img src="https://firebasestorage.googleapis.com/v0/b/uploadimage-6caaa.appspot.com/o/images%2FCountry%20Flag.png?alt=media&token=a0cb9402-fc24-464e-8709-c3559ebdbabd" alt="uk-flag"> </p>
            </div>

            <div style="text-align: center;">
                <a href="#" style="pointer-events:none;"><img src="https://firebasestorage.googleapis.com/v0/b/uploadimage-6caaa.appspot.com/o/images%2FZIMO%20ZIG%20B.png?alt=media&token=8e3d7312-ba12-47d4-8d9d-3b2d476fe99f" class="footer-top" alt="zimo-zig"></a>
            </div>
            

        </div>
        <p class="copyright-text">COPYRIGHT © 2023 ZIMO GROUP ALL RIGHTS RESERVED. <a href="#" style="pointer-events:none;"><img src="https://firebasestorage.googleapis.com/v0/b/uploadimage-6caaa.appspot.com/o/images%2FLET'S%20DO%20THIS.png?alt=media&token=a62703f7-0ef2-4dd8-82bc-45f0d7a47873" alt="let-do-this"></a></p>

        <p class="end-note"><img src="https://firebasestorage.googleapis.com/v0/b/uploadimage-6caaa.appspot.com/o/images%2FSecurity%20Lock%20B.png?alt=media&token=c1e62c4a-796f-4859-8211-08b91bb0ec58" alt="sec-lock"> ZITRANSFER USES ADVANCED ENCRYPTION STANDARD (AES) 256-BIT TO PROTECT THE CONFIDENTIIALITY OF THE DATA YOU UPLOAD.</p>

    </div>

    </body>
</html><?php /**PATH C:\xampp\htdocs\backend-zitransfer\src\resources\views/admin/email/revision-files.blade.php ENDPATH**/ ?>