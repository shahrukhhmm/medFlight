

<?php $__env->startSection('title', 'Visitor'); ?>


<?php echo $__env->make('admin.components.styles', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php $__env->startSection('body'); ?>



    <div class="row mt-4">
        <div class="col">
            <div class="card">

                <div class="card-header">
                    <i class="fas fa-users"></i> Visitors
                </div>


                <div class="card-body" v-cloak>


                    <div class="row d-flex justify-content-between" style="border:none;">

                        <div class="col-sm-6   col-lg-2  my-2 ">
                            <div class="small-box bg-secondary">
                                <div class="inner">
                                    <h3><i class="fas fa-users"></i> <?php echo e($t_visitor); ?></h3>
                                    <h6 class="mt-4">Total Visitors</h6>
                                </div>
                              
                               
                            </div>
                        </div>

                       
                        <div class="col-sm-6   col-lg-2  my-2 ">
                            <div class="small-box p-4 bg-danger">
                                <div class="inner">
                                    <h3><?php echo e($todayCount); ?></h3>
                                    <h6>Today</h6>
                                </div>
                                <div class="icon">
                                    <i class="ion ion-bag"></i>
                                </div>
                                <a href="<?php echo e(url('/admin/visitor-data/today')); ?>" class="small-box-footer">
                                    More info
                                    <i class="fas fa-arrow-circle-right"></i>
                                </a>
                            </div>
                        </div>
                        <div class="col-sm-6   col-lg-2  my-2 ">
                            <div class="small-box p-4 bg-dark">
                                <div class="inner">
                                    <h3><?php echo e($weeklyCount); ?></h3>
                                    <h6>This Week</h6>
                                </div>
                                <div class="icon">
                                    <i class="ion ion-bag"></i>
                                </div>
                                <a href="<?php echo e(url('/admin/visitor-data/week')); ?>" class="small-box-footer">
                                    More info
                                    <i class="fas fa-arrow-circle-right"></i>
                                </a>
                            </div>
                        </div>
                        <div class="col-sm-6   col-lg-2  my-2 ">
                            <div class="small-box p-4 bg-info">
                                <div class="inner">
                                    <h3> <?php echo e($monthlyCount); ?></h3>
                                    <h6>This Month</h6>
                                </div>
                                <div class="icon">
                                    <i class="ion ion-bag"></i>
                                </div>
                                <a href="<?php echo e(url('/admin/visitor-data/month')); ?>" class="small-box-footer">
                                    More info
                                    <i class="fas fa-arrow-circle-right"></i>
                                </a>
                            </div>
                        </div>
                        <div class="col-sm-6   col-lg-2  my-2 ">
                            <div class="small-box p-4 bg-primary">
                                <div class="inner">
                                    <h3>  <?php echo e($yearlyCount); ?></h3>
                                    <h6>This Year</h6>
                                </div>
                                <div class="icon">
                                    <i class="ion ion-bag"></i>
                                </div>
                                <a href="<?php echo e(url('/admin/visitor-data/year')); ?>" class="small-box-footer">
                                    More info
                                    <i class="fas fa-arrow-circle-right"></i>
                                </a>
                            </div>
                        </div>
                       
                        
                        
                    </div>



                    <div class="row" style="margin-top: 15px;">
                        <div class="col-md-12">
                            <div class="card-body" style="overflow: auto">
                                <h1 class="text-center">All Visitors</h1>

                                <canvas id="allVisitors" style="height: 380px; width: 100%;"></canvas>
                            </div>
                        </div>

                    </div>




                    <div class="row" style="margin-top: 15px;">
                        <div class="col-lg-4">
                            <h1 class="text-center">DEVICE</h1>
                            <canvas id="visitorDevices" style="height: 370px; width: 100%;"></canvas>

                        </div>
                        <div class="col-lg-4">
                            <h1 class="text-center">PLATFORM</h1>
                            <canvas id="platformDevices" style="height: 370px; width: 100%;"></canvas>

                        </div>

                        <div class="col-lg-4">
                            <h1 class="text-center">COUNTRY</h1>
                            <canvas id="visitorCountries" style="height: 370px; width: 100%;"></canvas>
                        </div>

                    </div>


                    <div class="row" style="margin-top: 15px; margin-bottom: 50px;">
                        
                        <div class="col-md-12">
                            <div class="card-body" style="overflow: auto">
                                <h1 class="text-center">Distinct Visitor</h1>
                                <canvas id="distinct-visitors" style="height: 380px; width: 100%;"></canvas>

                            </div>
                        </div>
                    </div>


                    <div  class="col-md-12 mb-4" style="background:white;  display: flex;  flex-wrap: wrap; flex-direction: row; justify-content: center;">
                        

                        <form id="filter-form" style="display:flex; align-items:center;  flex-wrap: wrap; justify-content: space-between; margin-bottom: 0px;">

                            <label for="from_date" class="me-2 h4"  ></label>
                            <input type="date" id="from_date"class="me-2 form-control"   name="from_date"  style="width:40%;">

                            <label for="to_date" class="me-2 h4" >-</label>
                            <input type="date" id="to_date" class="me-2 form-control" name="to_date"  style="width:40%;">

                            <button type="submit" class=" me-2 btn btn-primary" style="padding: 9px;"><i class="fas fa-check"></i></button>
                            
                        </form>

                    </div>


                    <!-- <div class="container">
                        <form id="filter-form" class="filter-form-container row">
                            <div class="col-sm-12 col-md-6 col-lg-5">
                                <label for="from_date" class="h6">From:</label>
                                <input type="date" id="from_date" class="form-control">
                            </div>
                            <div class="col-sm-12 col-md-6 col-lg-5">
                                <label for="to_date" class="h6">To:</label>
                                <input type="date" id="to_date" class="form-control">
                            </div>
                            <div style="margin-top: 30px;" class="col-sm-12 col-md-6 col-lg-2 applyBtn">
                                <button type="submit" class="btn btn-sm btn-success">Apply Filter</button>
                            </div>
                        </form>
                    </div> -->





                    <table class="table table-hover visitor-listing table-listing" style="overflow:auto; width:100%;">
                        <thead>
                            <tr>

                                <th>ID</th>
                                <th>Ip address</th>
                                <th>Country Name</th>
                                <th>City Name</th>
                                <th>Zip Code</th>
                                <th>Device</th>
                                <th>Platform</th>
                                <th>System</th>
                                <th>Latlng</th>
                                <th>Created at</th>
                                <th>Action</th>

                            </tr>
                        </thead>

                        <tbody>


                        </tbody>
                    </table>

                </div>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>




<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.29.1/moment.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<script src="https://code.jquery.com/jquery-3.7.0.js"></script>

<script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js" defer></script>

<script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap4.min.js" defer></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.2/css/bootstrap.css">
<link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap4.min.css">

<script>
    $(document).ready(function() {

        // all visitor graph

        var AllVisitor = $('#allVisitors');

        var dates = <?php echo json_encode($visitorData->pluck('date')); ?>;
        var counts = <?php echo json_encode($visitorData->pluck('count')); ?>;


        var visitorChart = new Chart(AllVisitor, {
            type: 'line',
            data: {
                labels: dates,
                datasets: [{
                    label: 'Visitors',
                    data: counts,
                    backgroundColor: 'blue',
                    borderWidth: 1
                }]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true
                    }
                },
                plugins: {
                    legend: {
                        display: false
                    },
                    tooltip: {
                        callbacks: {
                            title: function(context) {
                                return moment(context[0].label).format('MMM DD, YYYY');
                            }
                        }
                    }
                }
            }
        });


        // distinct graph

        var distinctVisitor = $('#distinct-visitors');

        var dates = <?php echo json_encode($distinctVisitor->pluck('date')); ?>;
        var counts = <?php echo json_encode($distinctVisitor->pluck('total')); ?>;


        var visitorChart = new Chart(distinctVisitor, {
            type: 'line',
            data: {
                labels: dates,
                datasets: [{
                    label: 'Distinct Visitors',
                    data: counts,
                    backgroundColor: 'black',
                    borderColor: 'rgb(75, 192, 192)',
                    borderWidth: 1
                }]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true
                    }
                },
                plugins: {
                    legend: {
                        display: false
                    },
                    tooltip: {
                        callbacks: {
                            title: function(context) {
                                return moment(context[0].label).format('MMM DD, YYYY');
                            }
                        }
                    }
                }
            }
        });

        // visitor device graph
        var deviceVisitor = $('#visitorDevices');
        var devices = <?php echo json_encode($device->pluck('device')); ?>;
        var counts = <?php echo json_encode($device->pluck('total')); ?>;
        var colors = [
            'lightcoral',
            'lightblue',
            'lightgreen',
            'lightsalmon',
            'lightpink',
            'lightseagreen',
            'lightsteelblue',
            'lightskyblue'
        ];

        var visitorChart = new Chart(deviceVisitor, {
            type: 'pie',
            data: {
                labels: devices,
                datasets: [{
                    data: counts,
                    backgroundColor: colors,
                    borderWidth: 1
                }]
            },
            options: {
                plugins: {
                    legend: {
                        display: true,
                        position: 'right'
                    },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                var device = devices[context.dataIndex];
                                var count = counts[context.dataIndex];
                                return device + ': ' + count;
                            }
                        }
                    }
                }
            }
        });

        // visitor platform graph
        var platformVisitor = $('#platformDevices');
        var platforms = <?php echo json_encode($platform->pluck('platform')); ?>;
        var counts = <?php echo json_encode($platform->pluck('total')); ?>;
        var colors = [
            'lightpink',
            'lightseagreen',
            'lightsteelblue',
            'lightcoral',
            'lightblue',
            'lightgreen',
            'lightsalmon',

            'lightskyblue'
        ];

        var visitorChart = new Chart(platformVisitor, {
            type: 'doughnut',
            data: {
                labels: platforms,
                datasets: [{
                    data: counts,
                    backgroundColor: colors,
                    borderWidth: 1
                }]
            },
            options: {
                plugins: {
                    legend: {
                        display: true,
                        position: 'right'
                    },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                var platform = platforms[context.dataIndex];
                                var count = counts[context.dataIndex];
                                return platform + ': ' + count;
                            }
                        }
                    }
                }
            }
        });

        // visitor country graph
        var countryVisitor = $('#visitorCountries');
        var country = <?php echo json_encode($country->pluck('countryName')); ?>;
        var counts = <?php echo json_encode($country->pluck('total')); ?>;
        var colors = [
            'lightsteelblue',
            'lightskyblue',
            'lightcoral',
            'lightblue',
            'lightpink',
            'lightseagreen',
            'lightgreen',
            'lightsalmon',
        ];





        var visitorChart = new Chart(countryVisitor, {
            type: 'pie',
            data: {
                labels: country,
                datasets: [{
                    data: counts,
                    backgroundColor: colors,
                    borderWidth: 1
                }]
            },
            options: {
                plugins: {
                    legend: {
                        display: true,
                        position: 'right'
                    },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                var platform = country[context.dataIndex];
                                var count = counts[context.dataIndex];
                                return platform + ': ' + count;
                            }
                        }
                    }
                }
            }
        });



    });
</script>


<script type="text/javascript">
    $(function() {
        setTimeout(function() {
            var table = $('.visitor-listing').DataTable({
                processing: true,
                serverSide: true,
                ajax: {
                    url: "<?php echo e(url('admin/visitor-list')); ?>",
                    data: function(d) {
                        d.from_date = $('#from_date').val();
                        d.to_date = $('#to_date').val();
                    }
                },

                columns: [{
                        data: 'id',
                        name: 'id'
                    },
                    {
                        data: 'ip_address',
                        name: 'ip_address'
                    },
                    {
                        data: 'countryName',
                        name: 'countryName'
                    },
                    {
                        data: 'cityName',
                        name: 'cityName'
                    },
                    {
                        data: 'zipCode',
                        name: 'zipCode'
                    },
                    {
                        data: 'device',
                        name: 'device'
                    },
                    {
                        data: 'platform',
                        name: 'platform'
                    },
                    {
                        data: 'system',
                        name: 'system'
                    },
                    {
                        data: 'map',
                        name: 'map',
                        orderable: false,
                        searchable: false
                    },
                    {
                        data: 'created',
                        name: 'created'
                    },
                    {
                        data: 'action',
                        name: 'action',
                        orderable: false,
                        searchable: false
                    },
                ],
                order: [[0, 'desc']],
            });
            $('#filter-form').on('submit', function(e) {
                e.preventDefault();
                $('.visitor-listing').DataTable().ajax.reload();
            });
        }, 1000);
    });
</script>

<?php echo $__env->make('brackets/admin-ui::admin.layout.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\backend-zitransfer\src\resources\views/admin/visitors/index.blade.php ENDPATH**/ ?>