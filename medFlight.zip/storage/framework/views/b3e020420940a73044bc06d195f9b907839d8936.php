

<?php $__env->startSection('title', 'Visitor'); ?>


<?php echo $__env->make('admin.components.styles', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php $__env->startSection('body'); ?>



    <div class="row mt-4">
        <div class="col">
            <div class="card">

                <div class="card-header">
                    <i class="fas fa-users"></i> Country wise visitor
                </div>




                    <div  class="col-md-12 mb-4" style="background:white;  display: flex;  flex-wrap: wrap; flex-direction: row; justify-content: center;">
                        

                        <form id="filter-form" style="display:flex; align-items:center;  flex-wrap: wrap; justify-content: space-between; margin-bottom: 0px;">

                            <label for="from_date" class="me-2 h4"  ></label>
                            <input type="date" id="from_date"class="me-2 form-control"   name="from_date"  style="width:40%;">

                            <label for="to_date" class="me-2 h4" >-</label>
                            <input type="date" id="to_date" class="me-2 form-control" name="to_date"  style="width:40%;">

                            <button type="submit" class=" me-2 btn btn-primary" style="padding: 9px;"><i class="fas fa-check"></i></button>
                            
                        </form>

                    </div>


                
                    <table class="table table-hover visitor-listing table-listing" style="overflow:auto; width:100%;">
                        <thead>
                            <tr>

                                <th>ID</th>
                                <th>Ip address</th>
                                <th>Country Name</th>
                                <th>City Name</th>
                                <th>Zip Code</th>
                                <th>Device</th>
                                <th>Platform</th>
                                <th>System</th>
                                <th>Latlng</th>
                                <th>Created at</th>
                                <th>Action</th>

                            </tr>
                        </thead>

                        <tbody>


                        </tbody>
                    </table>

                </div>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>




<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.29.1/moment.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<script src="https://code.jquery.com/jquery-3.7.0.js"></script>

<script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js" defer></script>

<script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap4.min.js" defer></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.2/css/bootstrap.css">
<link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap4.min.css">



<script type="text/javascript">
    $(function() {
        setTimeout(function() {
            var data = "<?php echo e($country_id); ?>";
            console.log(data);
            var table = $('.visitor-listing').DataTable({
                processing: true,
                serverSide: true,
                ajax: "<?php echo e(url('admin/country-visitor-list')); ?>"+ "/" + data,

                columns: [{
                        data: 'id',
                        name: 'id'
                    },
                    {
                        data: 'ip_address',
                        name: 'ip_address'
                    },
                    {
                        data: 'countryName',
                        name: 'countryName'
                    },
                    {
                        data: 'cityName',
                        name: 'cityName'
                    },
                    {
                        data: 'zipCode',
                        name: 'zipCode'
                    },
                    {
                        data: 'device',
                        name: 'device'
                    },
                    {
                        data: 'platform',
                        name: 'platform'
                    },
                    {
                        data: 'system',
                        name: 'system'
                    },
                    {
                        data: 'map',
                        name: 'map',
                        orderable: false,
                        searchable: false
                    },
                    {
                        data: 'created',
                        name: 'created'
                    },
                    {
                        data: 'action',
                        name: 'action',
                        orderable: false,
                        searchable: false
                    },
                ],
                order: [[0, 'desc']],
            });
         
        }, 1000);
    });
</script>

<?php echo $__env->make('brackets/admin-ui::admin.layout.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\backend-zitransfer\src\resources\views/admin/visitors/visitorCountry.blade.php ENDPATH**/ ?>