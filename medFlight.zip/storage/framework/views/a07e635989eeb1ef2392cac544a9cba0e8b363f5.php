<!DOCTYPE HTML>
<html>
<script src="https://canvasjs.com/assets/script/canvasjs.min.js"></script>

<body>
<div id="uniquevisitor" style="height: 370px; width: 100%; margin-top: 20px;">
</div>
</body>
</html>


<script type="text/javascript">

        var chartvisitor = new CanvasJS.Chart("uniquevisitor", {
            animationEnabled: true, 
		    animationDuration: 1000, 
            title: {
                text: 'Unique Visitors',
                fontFamily: "arial",
                fontSize: 25,
                fontWeight:"bold"
            },
            axisX: {
                // interval: 2,
                // intervalType: "day"
            },
            data: [
                {
                    type: "line",
                    dataPoints: <?php echo json_encode($uniqueVisitor,
                        JSON_NUMERIC_CHECK); ?>
                }
            ]
        });
        chartvisitor.render();

</script>
<?php /**PATH C:\xampp\htdocs\backend-zitransfer\src\resources\views/admin/graph/distinct-visitor.blade.php ENDPATH**/ ?>