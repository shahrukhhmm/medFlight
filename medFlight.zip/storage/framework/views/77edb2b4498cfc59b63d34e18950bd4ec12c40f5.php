

<?php $__env->startSection('title', 'User Detail'); ?>

<?php echo $__env->make('admin.components.styles', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('body'); ?>

        <div class="row">
            <div class="col-lg-12">
              
                <div class="card mb-4">
                    <div class="card-body text-center">
                            
                            <?php if($data->type == "Google"): ?>
                                <div class="d-flex justify-content-center">
                                    <div class="image-frame">
                                        <img src="<?php echo e($data->googleUser->photoUrl); ?>" alt="Image Alt Text" class="circle-image">
                                    </div>
                                </div>
                            <?php else: ?>    
                                <div class="d-flex justify-content-center">
                                    <h4 class="letters circle " >
                                        <?php echo e(Str::substr(@$data->display_name, 0, 1)); ?>

                                    </h4>
                                </div>
                            <?php endif; ?>
                                              
                            <h1 class="my-3 ">
                                <?php echo e(@$data->display_name); ?> 
                            </h1>
                            
                            <p class="my-3 text-muted">
                                <i class="fas fa-envelope mr-2"></i> <?php echo e(@$data->email); ?>

                                <i class="fas fa-map-marker-alt mr-2 "></i><?php echo e(@$data->visitor->countryName); ?>

                            </p>

                            <button class="btn btn-success text-white">Verified</button>
                    </div>  
                </div>

            </div>        
        </div>

        <div class="row" >
            
            <div class="col-lg-5 col-sm-12">

                <div class="card mb-4">

                    <div class="card-body text-center">
                        <h4 class="text-left mt-2 mx-3">
                            User Details
                        </h4>

                        <ul class="list-group list-group-flush mt-4">
                    
                            <li class="list-group-item d-flex justify-content-between align-items-center flex-wrap">
                                <h6 class="mb-0">
                                    <i class="fas fa-key mr-2"></i>
                                    ID
                                </h6>
                                <span class="text-muted">#ZM<?php echo e(@$data->id); ?></span>
                            </li>
                            <li class="list-group-item d-flex justify-content-between align-items-center flex-wrap">
                                <h6 class="mb-0">
                                    <i class="fas fa-envelope mr-2"></i>
                                    Email
                                </h6>
                                <span class="text-muted"><?php echo e(@$data->email); ?></span>
                            </li>

                            <li class="list-group-item d-flex justify-content-between align-items-center flex-wrap">
                                <h6 class="mb-0">     
                                    <i class="fas fa-user mr-2"></i>
                                    Type
                                </h6>
                                <span class="text-muted"><?php echo e(@$data->type); ?></span>
                            </li>
                            <li class="list-group-item d-flex justify-content-between align-items-center flex-wrap">
                                <h6 class="mb-0">
                                    <i class="fas fa-map-marker-alt mr-2"></i>
                                    Country
                                </h6>
                                <span class="text-muted"> <?php echo e(@$data->visitor->countryName); ?></span>
                            </li>
                            
                            <?php if($data->googleUser): ?>
                                <li class="list-group-item d-flex justify-content-between align-items-center flex-wrap">
                                    <h6 class="mb-0">
                                        <i class="fas fa-phone mr-2"></i>
                                        Phone
                                    </h6>
                                    <span class="text-muted"> <?php echo e(@$data->googleUser->phone); ?></span>
                                </li>
                            <?php endif; ?>


                            <li class="list-group-item d-flex justify-content-between align-items-center flex-wrap">
                                <h6 class="mb-0">
                                    <i class="fas fa-building mr-2"></i>
                                    Organization
                                </h6>
                                <span class="text-muted"> <?php echo e(@$data->organization); ?></span>
                            </li>

                        </ul>

                    </div>
                                                                        
                </div>

            </div>
  


            <div class="col-lg-7 col-sm-12">
                <div class="card mb-4">
                    <div class="card-body">
                        <div class="row">

                            <div class="col-sm-3">
                                <h6 class="mb-0">Visitor Id</h6>
                            </div>
                            
                            <div class="col-sm-9">
                                <p class="text-muted d-flex justify-content-between align-items-center flex-wrap">
                                    <?php echo e(@$data->visitor_id); ?> 
                                    <a class=" btn btn-sm btn-info" 
                                        href="<?php echo e(url('/admin/visitor-detail/'.@$data->visitor->id)); ?>" 
                                        role="button">

                                        <i class="fa fa-eye"></i>
                                    </a>
                                </p>
                            </div>
                        </div>

                        <div class="row mt">
                            <div class="col-sm-3">
                                <h6 class=" mb-0 ">Status</h6>
                            </div>
                            <div class="col-sm-9">
                                <p class="text-muted"><?php echo e(@$data->status); ?></p>
                            </div>
                        </div>
                                                
                    </div>


                    <div class="card-body mt p-4" >
                            <h4 class="mt-1"> Account  Details </h4>


                        <div class="row mt">
                            <div class="col-md-4 mt-2 d-flex flex-column">
                                    <h6>Created At</h6>
                                    <p class="text-muted"><?php echo e(@$data->created_at); ?></p>
                            </div>

                            <div class="col-md-4 mt-2 d-flex flex-column">
                                <h6>Last Login Time</h6>
                                <p class="text-muted"><?php echo e(@$data->last_login_time); ?></p>
                            </div>

                            <div class="col-md-4 mt-2 d-flex flex-column">
                                <h6>Email Verifed Time</h6>
                                <p class="text-muted"><?php echo e(@$data->email_verified_at); ?></p>
                            </div>
                        </div>

                        <!-- <div class="row mt">
                            <div class="col-md-6 mt-2 d-flex flex-column">
                                    <h6>Last Login Time</h6>
                                    <p class="text-muted"><?php echo e(@$data->last_login_time); ?></p>
                            </div>

                            <div class="col-md-6 mt-2 d-flex flex-column">
                                <h6>Status</h6>
                                <p class="text-muted"><?php echo e(@$data->status); ?></p>
                            </div>
                        </div> -->


                        <?php if($data->googleUser): ?>
                            <div class="row mt">
                                <div class="col-md-6 mt-2 d-flex flex-column">
                                        <h6>Provider Id</h6>
                                        <p class="text-muted"><?php echo e(@$data->googleUser->providerId); ?></p>
                                </div>

                                <div class="col-md-6 mt-2 d-flex flex-column">
                                    <h6>U Id</h6>
                                    <p class="text-muted"><?php echo e(@$data->googleUser->uid); ?></p>
                                </div>
                            </div>
                        <?php endif; ?>

                    </div>
                            
                </div>
            </div>

        </div>

                    
        

        <!-- <?php if(@$data->type == 'Normal'): ?>
            <div class="row" style="display:none;">

                <div class="col-lg-12 col-sm-12">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-sm-4">
                                    <p class="mb-0 font-weight-bold fontColor">Visitor Id</p>
                                </div>
                                <div class="col-sm-8">
                                    <p class="text-muted mb-0"><?php echo e(@$data->visitor_id); ?></p>
                                </div>
                            </div>
                            <hr>

                            <div class="row">
                                <div class="col-sm-4">
                                    <p class="mb-0 font-weight-bold fontColor">Email</p>
                                </div>
                                <div class="col-sm-8">
                                    <p class="text-muted mb-0"><?php echo e(@$data->email); ?></p>
                                </div>
                            </div>
                            <hr>

                            <div class="row">
                                <div class="col-sm-4">
                                    <p class="mb-0 font-weight-bold fontColor">Display name</p>
                                </div>
                                <div class="col-sm-8">
                                    <p class="text-muted mb-0"><?php echo e(@$data->display_name); ?></p>
                                </div>
                            </div>
                            <hr>
                            <div class="row">
                                <div class="col-sm-4">
                                    <p class="mb-0 font-weight-bold fontColor">Country</p>
                                </div>
                                <div class="col-sm-8">
                                    <p class="text-muted mb-0">
                                        <?php echo e(@$data->visitor->countryName); ?>

                                    </p>
                                </div>
                            </div>
                            <hr>


                            <div class="row">
                                <div class="col-sm-4">
                                    <p class="mb-0 font-weight-bold fontColor">Organization</p>
                                </div>
                                <div class="col-sm-8">
                                    <p class="text-muted mb-0"><?php echo e(@$data->organization); ?></p>
                                </div>
                            </div>
                            <hr>

                            <div class="row">
                                <div class="col-sm-4">
                                    <p class="mb-0 font-weight-bold fontColor">Type</p>
                                </div>
                                <div class="col-sm-8">
                                    <p class="text-muted mb-0"><?php echo e(@$data->type); ?></p>
                                </div>
                            </div>
                            <hr>

                            <div class="row">
                                <div class="col-sm-4">
                                    <p class="mb-0 font-weight-bold fontColor">Last login time
                                    </p>
                                </div>
                                <div class="col-sm-8">
                                    <p class="text-muted mb-0"><?php echo e(@$data->last_login_time); ?></p>
                                </div>
                            </div>
                            <hr>
                            <div class="row">
                                <div class="col-sm-4">
                                    <p class="mb-0 font-weight-bold fontColor">Created at
                                    </p>
                                </div>
                                <div class="col-sm-8">
                                    <p class="text-muted mb-0"><?php echo e(@$data->created_at); ?>

                                    </p>
                                </div>
                            </div>

                        </div>

                </div>

            </div>
        <?php else: ?>
            
            <div class="row">

                <div class="col-lg-6 col-sm-12">
                    <div class="card mb-4">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-sm-4">
                                    <p class="mb-0 font-weight-bold fontColor">Visitor Id</p>
                                </div>
                                <div class="col-sm-8">
                                    <p class="text-muted mb-0"><?php echo e(@$data->visitor_id); ?></p>
                                </div>
                            </div>
                            <hr>

                            <div class="row">
                                <div class="col-sm-4">
                                    <p class="mb-0 font-weight-bold fontColor">Email</p>
                                </div>
                                <div class="col-sm-8">
                                    <p class="text-muted mb-0"><?php echo e(@$data->email); ?></p>
                                </div>
                            </div>
                            <hr>

                            <div class="row">
                                <div class="col-sm-4">
                                    <p class="mb-0 font-weight-bold fontColor">Display name</p>
                                </div>
                                <div class="col-sm-8">
                                    <p class="text-muted mb-0"><?php echo e(@$data->display_name); ?></p>
                                </div>
                            </div>
                            <hr>
                            <div class="row">
                                <div class="col-sm-4">
                                    <p class="mb-0 font-weight-bold fontColor">Country</p>
                                </div>
                                <div class="col-sm-8">
                                    <p class="text-muted mb-0">
                                        <?php echo e(@$data->visitor->countryName); ?>

                                    </p>
                                </div>
                            </div>

                            <hr>
                            <div class="row">
                                <div class="col-sm-4">
                                    <p class="mb-0 font-weight-bold fontColor">Type</p>
                                </div>
                                <div class="col-sm-8">
                                    <p class="text-muted mb-0"><?php echo e(@$data->type); ?></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-6 col-sm-12">
                    <div class="card mb-4">
                        <div class="card-body">

                            <div class="row">
                                <div class="col-sm-4">
                                    <p class="mb-0 font-weight-bold fontColor">Phone</p>
                                </div>
                                <div class="col-sm-8">
                                    <p class="text-muted mb-0"><?php echo e(@$data->googleUser->phone); ?>

                                    </p>
                                </div>
                            </div>
                            <hr>

                            <div class="row">
                                <div class="col-sm-4">
                                    <p class="mb-0 font-weight-bold fontColor">Photo Url </p>
                                </div>
                                <div class="col-sm-8">
                                    <p class="text-muted mb-0">
                                        <?php echo e(@$data->googleUser->photoUrl); ?></p>
                                </div>
                            </div>
                            <hr>

                            <div class="row">
                                <div class="col-sm-4">
                                    <p class="mb-0 font-weight-bold fontColor">Provider Id
                                    </p>
                                </div>
                                <div class="col-sm-8">
                                    <p class="text-muted mb-0">
                                        <?php echo e(@$data->googleUser->ProviderId); ?>

                                    </p>
                                </div>
                            </div>
                            <hr>
                            <div class="row">
                                <div class="col-sm-4">
                                    <p class="mb-0 font-weight-bold fontColor">U id
                                    </p>
                                </div>
                                <div class="col-sm-8">
                                    <p class="text-muted mb-0"><?php echo e(@$data->googleUser->uid); ?>

                                    </p>
                                </div>
                            </div>
                            <hr>
                            <div class="row">
                                <div class="col-sm-4">
                                    <p class="mb-0 font-weight-bold fontColor">Created at
                                    </p>
                                </div>
                                <div class="col-sm-8">
                                    <p class="text-muted mb-0"><?php echo e(@$data->created_at); ?>

                                    </p>
                                </div>
                            </div>


                        </div>
                    </div>

                </div>

            </div>
        <?php endif; ?> -->
                                    
            <div class="row mb-4">

                <div class="accordion" id="myAccordion">
                    <div class="accordion-item">
                        <h2 class="accordion-header" id="headingOne">
                            <button type="button" class="accordion-button collapsed" data-bs-toggle="collapse" data-bs-target="#collapseOne"><h5>File Uploads</h5></button>									
                        </h2>
                        <div id="collapseOne" class="accordion-collapse collapse" data-bs-parent="#myAccordion">
                            <div class="card-body">
                                <?php if(count($data->file) > 0): ?>
                                    <table class="table">
                                        <thead>
                                            <tr>
                                                <th  class="border-none">Title</th>
                                                <th  class="border-none">Link</th>
                                                <th  class="border-none">Size</th>
                                                <th  class="border-none">File Count</th>
                                                <th  class="border-none">Action</th>
                                            </tr>
                                        </thead>
                                        <tbody style="font-size: 14px;">

                                            <?php $__currentLoopData = @$data->file; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td> <?php echo e(@$file->title); ?> </td>
                                                    <td> <?php echo e(@$file->link); ?> </td>
                                                    <td><?php echo e(@$file->total_size); ?></td>
                                                    <td><?php echo e(@$file->file_count); ?></td>
                                                    <td><a class="btn btn-sm btn-info ml-2" href="<?php echo e(url('/admin/file-detail/' . $file['id'])); ?>" role="button"><i class="fa fa-eye"></i></a></td>

                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        </tbody>
                                    </table>
                                <?php else: ?>
                                    <p class="text-muted">No Files uploaded yet</p>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        


    <?php $__env->stopSection(); ?>


    <script src="https://canvasjs.com/assets/script/canvasjs.min.js"></script>


    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.js"></script>
<!-- 
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js" defer></script> -->

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>



    



<?php echo $__env->make('brackets/admin-ui::admin.layout.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\backend-zitransfer\src\resources\views/admin/user/user-detail.blade.php ENDPATH**/ ?>