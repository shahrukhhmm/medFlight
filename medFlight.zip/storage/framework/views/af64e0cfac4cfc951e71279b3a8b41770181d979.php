

<?php $__env->startSection('title', 'File'); ?>


<?php echo $__env->make('admin.components.styles', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



<?php $__env->startSection('body'); ?>


    <div class="row mt-4">
        <?php $__currentLoopData = @$t_size_with_unit; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-4 col-12 p-3">
                <div class="small-box bg-dark">
                    <div class="inner">
                        <h3><?php echo e(@$item['total_size']); ?></h3>
                        <h5><?php echo e(@$item['type']); ?></h5>
                    </div>

                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <div class="col">
            <div class="card">
                <div class="card-header">
                    <i class="fa fa-align-justify"></i> Files

                </div>
                <div class="card-body" v-cloak>

                    <?php if(session()->has('message')): ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <strong>Success</strong> &nbsp; <?php echo e(session()->get('message')); ?>

                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                    <?php endif; ?>

                    

                    
                    <div class="col-md-6 col-sm-8 col-10" style="width: 80%; margin: auto;">
                        <h1 class="text-center">File type Graph</h1>
                        <canvas id="fileTypeChart"></canvas>
                    </div>

                    <hr>
                    <div class="container">
                        <form id="filter-form" class="filter-form-container row">
                            <div class="col-sm-12 col-md-6 col-lg-5">
                                <label for="from_date" class="h6">From:</label>
                                <input type="date" id="from_date" class="form-control">
                            </div>
                            <div class="col-sm-12 col-md-6 col-lg-5">
                                <label for="to_date" class="h6">To:</label>
                                <input type="date" id="to_date" class="form-control">
                            </div>
                            <div style="margin-top: 30px" class="col-sm-12 col-md-6 col-lg-2 applyBtn">
                                <button type="submit" class="btn btn-sm btn-success">Apply Filter</button>
                            </div>
                        </form>
                    </div>

                    <table class="table table-hover file-listing table-listing" style="overflow:auto; width:100%;">
                        <thead>
                            <tr>

                                <th>ID</th>
                                <th>VisitorId</th>
                                <th>Title</th>
                                <th>Link</th>
                                <th>File count</th>
                                <th>Size</th>
                                <th>Created at</th>
                                <th>Action</th>

                            </tr>
                        </thead>
                        <tbody>

                        </tbody>
                    </table>

                </div>
            </div>
        </div>
    </div>




<?php $__env->stopSection(); ?>


<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.29.1/moment.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
<script src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js" defer></script>
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.16/css/jquery.dataTables.min.css">



<script>
    $(document).ready(function() {
        var typeChart = $('#fileTypeChart');
        var typeFile = <?php echo json_encode($fileType->pluck('type')); ?>;
        var counts = <?php echo json_encode($fileType->pluck('count')); ?>;

        var colors = [
            'lightsteelblue',
            'lightskyblue',
            'lightcoral',
            'lightblue',
            'lightpink',
            'lightseagreen',
            'lightgreen',
            'lightsalmon',
        ];

        // Create a pie chart for counts
        var pieChart = new Chart(typeChart, {
            type: 'pie',
            data: {
                labels: typeFile,
                datasets: [{
                    label: 'Counts',
                    data: counts,
                    backgroundColor: colors,
                    border: 1
                }, ],
            },
            options: {
                plugins: {
                    legend: {
                        display: true,
                        position: 'right',
                    },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                var type = typeFile[context.dataIndex];
                                var count = counts[context.dataIndex];
                                return type + ': ' + count;
                            },
                        },
                    },
                },
            },
        });



    });
</script>




<script type="text/javascript">
    $(function() {
        setTimeout(function() {
            var table = $('.file-listing').DataTable({
                processing: true,
                serverSide: true,
                ajax: {
                    url: "<?php echo e(url('/admin/file-list')); ?>",
                    data: function(d) {
                        d.from_date = $('#from_date').val();
                        d.to_date = $('#to_date').val();
                    }
                },

                columns: [{
                        data: 'id',
                        name: 'id'
                    },
                    {
                        data: 'visitor_detail',
                        name: 'visitor_detail'
                    },
                    {
                        data: 'title',
                        name: 'title'
                    },
                    {
                        data: 'link',
                        name: 'link'
                    },
                    {
                        data: 'file_count',
                        name: 'file_count'
                    },
                    {
                        data: 'total_size',
                        name: 'total_size'
                    },
                    {
                        data: 'created',
                        name: 'created'
                    },
                    {
                        data: 'action',
                        name: 'action',
                        orderable: false,
                        searchable: false
                    },
                ]
            });

            $('#filter-form').on('submit', function(e) {
                e.preventDefault();
                $('.file-listing').DataTable().ajax.reload();
            });

        }, 2000);
    });
</script>

<?php echo $__env->make('brackets/admin-ui::admin.layout.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\backend-zitransfer\src\resources\views/admin/file/index.blade.php ENDPATH**/ ?>