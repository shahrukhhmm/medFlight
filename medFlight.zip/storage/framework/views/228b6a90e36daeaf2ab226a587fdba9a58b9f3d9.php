<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Zimoteam</title>
    
</head>
<body>

    <main>
        <h1>qrcode</h1>
        <img src="<?php echo e(public_path('qrcode/qrCode.png')); ?>" alt="QR Code">
    </main>
</body>
</html>

<?php /**PATH C:\xampp\htdocs\backend-zitransfer\src\resources\views/admin/email/qrMail.blade.php ENDPATH**/ ?>