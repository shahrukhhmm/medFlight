

<?php $__env->startSection('title', 'Advertisement'); ?>


<?php echo $__env->make('admin.components.styles', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



<?php $__env->startSection('body'); ?>

    <div class="row mt-4">
        <div class="col-md-6 col-12 p-3 mt-2">
            <div class="small-box" style="background: #2c3aff7e;">
                <div class="inner">
                    <h3><i class="fas fa-users mr-3 mb-3"></i>Total video Advert</h3>
                    <h5> <?php echo e(@$VideoAdvert); ?></h5>
                </div>
            
            </div>
        </div>
        <div class="col-md-6 col-12 p-3 mt-2">
            <div class="small-box" style="background: #ff612c7e;">
                <div class="inner">
                    <h3><i class="fas fa-users mr-3 mb-3"></i>Total video Advert</h3>
                    <h5> <?php echo e(@$imageAdvert); ?></h5>
                </div>
            
            </div>
        </div>
    </div>

        <div class="row mt-4">
            <?php $__currentLoopData = $customData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
            <div class="col-md-3 col-12 p-3 mt-2">
                <div class="small-box" style="background: #2caeff7e;">
                    <div class="inner">
                        <h3><i class="fas fa-users mr-3 mb-3"></i><?php echo e(@$data['advertisement_count']); ?></h3>
                        <h5> <?php echo e(@$data['country_name']); ?></h5>
                    </div>
                  
                    <a href="<?php echo e(url('admin/visitors-country-wise/'.$data['country_id'])); ?>" class="small-box-footer">More info <i
                            class="fas fa-arrow-circle-right"></i></a>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <div class="col-12">
                <div class="card">

                    <div class="card-header">
                        <i class="fas fa-bullhorn"></i> Advertisements
                        <a class="btn btn-primary btn-sm pull-right m-b-0 add" href="#" data-toggle="modal" data-target="#addAdvertisement" role="button"><i class="fa fa-plus"></i>&nbsp; New</a>

                    </div>
                    <div  class="col-md-12 pt-4" style="background:white;  display: flex;  flex-wrap: wrap; flex-direction: row; justify-content: center;">
                        
                        <p style="margin-top: 14px;"></p>


                        <form id="filter-form" style="display:flex; align-items:center;  flex-wrap: wrap; justify-content: space-between; margin-bottom: 0px;">

                            <label for="from_date" class="me-2 h4"  ></label>
                            <input type="date" id="from_date"class="me-2 form-control"   name="from_date"  style="width:40%;">

                            <label for="to_date" class="me-2 h4" >-</label>
                            <input type="date" id="to_date" class="me-2 form-control" name="to_date"  style="width:40%;">

                            <button type="submit" class=" me-2 btn btn-primary" style="padding: 9px;"><i class="fas fa-check"></i></button>
                            
                        </form>

                    </div>

                    <div class="card-body" v-cloak>

                        <?php if(session()->has('message')): ?>
                            <div class="alert alert-success alert-dismissible fade show" role="alert">
                                <strong>Success</strong> &nbsp; <?php echo e(session()->get('message')); ?>

                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>                            
                        <?php endif; ?>
                        <table class="datatables-basic table table-hover advertisement-listing table-listing" style="overflow:auto; width:100%;">

                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Type</th>
                                    <th>Theme</th>
                                    <th>Country</th>
                                    <th>Page Tag</th>
                                    <th>Created at</th>    
                                    <th>Action</th>
                                </tr>
                            </thead>
                        </table>

                    </div>
                </div>
            </div>
        </div>
      



    


    <div class="modal fade" id="addAdvertisement" tabindex="-1" role="dialog" saria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-md" role="document">

            <div class="modal-content ">

                <div class="modal-header d-flex justify-content-between">
                    <h5 class="modal-title text-dark" id="exampleModalLabel">Add Advertisement</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>

                <div class="modal-body text-dark">
                        <form id="addAdvertForm"  enctype="multipart/form-data">

                            <input type="hidden" name="url" id="url">

                            <div id="sending-message" class="text-danger fw-bold"></div>
                        
                    
                            <div class="row d-flex justify-content-center align-items-center">
                                
                            <div class="form-group col-md-12">

                                <div class="form-group mt-3">
                                    <label for="type">Select Type</label>
                                    <select name="type" id="type" class="form-control field-radius" required>
                                        <option value="image" selected >Image</option>
                                        <option value="video">Video</option>
                                    </select>
                                </div>

                                <div class="form-group mt-3">
                                    <label for="theme_id">Select Theme</label>
                                    <select name="theme_id" id="theme_id" class="form-control field-radius" >
                                        <option value="" selected disabled>Select Theme</option>

                                        <?php $__currentLoopData = $themes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $theme): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($theme->id); ?>"><?php echo e($theme->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </select>
                                </div>

                                <div class="form-group mt-3">
                                    <label for="country_id">Select country</label>
                                    <select name="country_id" id="country_id" class="form-control field-radius" >
                                        <option value="" selected disabled>Select Country</option>
                                        <option value="all"  >All</option>

                                        <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($country->id); ?>"><?php echo e($country->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </select>
                                </div>

                                <div class="form-group mt-3">
                                    <label for="page_tag">Select Page Tag</label>
                                    <select name="page_tag" id="page_tag" class="form-control field-radius" >
                                        <option value="" selected disabled>Select Page Tag</option>
                                        <option value="Home"> Home </option>
                                        <option value="Login"> Login </option>
                                        <option value="Download"> Download </option>

                                    </select>
                                </div>


                                <div class="form-group" id="docGroup" style="margin-top: 15px;">
                                    <label for="upload_file" class="form-label">Upload File:</label>
                                    <input type="file" class="form-control field-radius" id="upload_file" name="upload_file" aria-label="upload_file" required>
                                    <div class="invalid-feedback">
                                        Please select a file.
                                    </div>
                                </div>

                                <br>
                                <div id="progress-bar-container" class="progress" style="display: none;">
                                    <div class="progress-bar progress-bar-striped progress-bar-animated" id="progress-bar" role="progressbar" style="width: 0%;" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100"></div>
                                </div>

                            </div>
                                    
                            </div>
                    
                            <button type="submit" class="btn btn-primary float-lg-right " id="uploadBtn">Submit</button>
            
                        </form>
                </div>

            </div>
        </div>
    </div>


 



<div class="modal fade" id="editAdvertisement" tabindex="-1" role="dialog" saria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-md" role="document">

        <div class="modal-content ">

            <div class="modal-header d-flex justify-content-between">
                <h5 class="modal-title text-dark" id="exampleModalLabel">Edit Advertisement</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>

            <div class="modal-body text-dark">

                    <input type="hidden" name="advertisement_id" id="advertisement_id">                                
                    <input type="hidden" name="update_url" id="update_url">

                    <div id="update-message" class="text-danger fw-bold"></div>
                
                        <div class="row d-flex justify-content-center align-items-center">
                            
                            
                            <div class="form-group col-md-12">

                                <div class="form-group mt-3">
                                    <label for="update_type">Select Type</label>
                                    <select name="update_type" id="update_type" class="form-control" required>
                                        <option value="image" selected >Image</option>
                                        <option value="video">Video</option>
                                    </select>
                                </div>


                                <div class="form-group mt-3">
                                    <label for="id_theme">Select Theme</label>

                                    <select name="id_theme" id="id_theme" class="form-control field-radius" required>
                                        <?php $__currentLoopData = $themes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $theme): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($theme->id); ?>"><?php echo e($theme->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </select>
                                </div>


                                <div class="form-group mt-3">
                                    <label for="id_country">Select Country</label>

                                    <select name="id_country" id="id_country" class="form-control field-radius" required>
                                        <option value="" selected disabled>Select Country</option>

                                        <option value="all"  >All</option>
                                        
                                        <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($country->id); ?>"><?php echo e($country->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </select>
                                </div>



                                <div class="form-group mt-3">
                                    <label for="update_page_tag">Select Page Tag</label>
                                    <select name="update_page_tag" id="update_page_tag" class="form-control field-radius" required>
                                        <option value="" selected disabled>Select Page Tag</option>
                                        <option value="Home"> Home </option>
                                        <option value="Login"> Login </option>
                                        <option value="Download"> Download </option>

                                    </select>
                                </div>

                        
                                <div class="form-group" style="margin-top: 15px;">
                                    <label for="update_file" class="form-label">Upload File:</label>
                                    <input type="file" class="form-control field-radius" id="update_file" name="update_file" aria-label="update_file">
                                    <div class="invalid-feedback">
                                        Please select a file.
                                    </div>
                                </div>

                                <br>
                                <div id="update-bar-container" class="progress" style="display: none;">
                                    <div class="progress-bar progress-bar-striped progress-bar-animated update-bar" id="update-bar" role="progressbar" style="width: 0%;" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100"></div>
                                </div>

                                </div>
                            </div>
                
                        <button type="submit" class="btn btn-primary float-lg-right " id="updateAdvertBtn">Submit</button>
           
            </div>

        </div>
    </div>
</div>







<div class="modal fade" id= "imageModal" tabindex="-1" role="dialog" aria-labelledby="imageModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="imageModalLabel">Image </h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body" style="width: 100%;">
                    <img id="imageSource" src="" width=100%>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="videoModal" tabindex="-1" role="dialog" aria-labelledby="videoModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="videoModalLabel">Video </h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <video style="width: 100%;" id="popupVideo" autoplay muted controls>
                        <source id="videoSource" src="" type="video/mp4">
                    </video>
                </div>
            </div>
        </div>
    </div>




<?php $__env->stopSection(); ?>






<script src="https://canvasjs.com/assets/script/canvasjs.min.js"></script>


<script src="https://code.jquery.com/jquery-3.7.0.js"></script>

<script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js" defer></script>

<script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap4.min.js" defer></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.2/css/bootstrap.css">
<link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap4.min.css">


<script src="https://www.gstatic.com/firebasejs/8.10.0/firebase-app.js"></script>
<script src="https://www.gstatic.com/firebasejs/8.10.0/firebase-storage.js"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>



<script type="text/javascript">

    $(function () {
        setTimeout(function () {
        var table = $('.advertisement-listing').DataTable({
            processing: true,
            serverSide: true,
            ajax: {
                url :"<?php echo e(url('admin/advertisements-list')); ?>",
                data: function (d) {
                    d.from_date = $('#from_date').val();
                    d.to_date = $('#to_date').val();
                    console.log(d);
                }
            },

            columns: [
                {
                    data: 'id',
                    name: 'id'
                },
                {
                    data: 'type',
                    name: 'type'
                },
                {
                    data: 'theme.name',
                    name: 'theme.name'
                },
                {
                    data: 'country.name',
                    name: 'country.name'
                },
                {
                    data: 'page_tag',
                    name: 'page_tag'
                },
                {
                    data: 'created',
                    name: 'created'
                },
                {
                    data: 'action', 
                    name: 'action', 
                    orderable: false, 
                    searchable: false
                },

            ],

            order: [[0, 'desc']],

        });

        $('#filter-form').on('submit', function (e) {
            e.preventDefault();
            $('.advertisement-listing').DataTable().ajax.reload();
        });

        }, 2000); 
    });
</script>



<script>
  $(document).ready(function() {


    $(document).on('click','.display' ,function () {

        var fileType = $(this).data('type');

        console.log(fileType);

        var fileUrl = $(this).val();

        if( fileType == 'image'){
            var imageSource = document.getElementById('imageSource');
            imageSource.src = fileUrl;

            $('#imageModal').modal('show');

            console.log("image_url"+fileUrl);

        }

        else if( fileType == 'video'){

            var videoSource = document.getElementById('videoSource');
            var popupVideo = document.getElementById('popupVideo');

            videoSource.src = fileUrl;

            popupVideo.load();
            $('#videoModal').modal('show');
        }
        
      
    });


    
  });
</script>





<script>
    

    function uploadFile(callback) {
   
        var uploadFile = document.getElementById("upload_file").files[0];

        var selectedType = $('#type').val();

        var progressBarContainer = document.getElementById("progress-bar-container");
        var progressBar = progressBarContainer.querySelector('.progress-bar');


        var fileName = uploadFile.name;

        if (!firebase.apps.length) {
            var firebaseConfig = {
                // Firebase configuration here
        
                apiKey: "AIzaSyBTRtct-hu1DgnG61cvpoXmwZm2lfXp6QU",
                authDomain: "ztfr-ff6ab.firebaseapp.com",
                projectId: "ztfr-ff6ab",
                storageBucket: "ztfr-ff6ab.appspot.com",
                messagingSenderId: "1080163201988",
                appId: "1:1080163201988:web:e99c813fdbbea5572e6a91",
                measurementId: "G-R6FNCSNE9R",
            
            };

            firebase.initializeApp(firebaseConfig);
        }
        

        // Get a reference to the storage service
        var storage = firebase.storage();

        if(selectedType == "image"){
            var storageRef = firebase.storage().ref('/country/homepageimages/' + fileName);
        }
        else if(selectedType == "video"){
            var storageRef = firebase.storage().ref('/advertVideos/' + fileName);
        }
        var uploadTask = storageRef.put(uploadFile);

        uploadTask.on('state_changed', function(snapshot) {
            var progress = (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
            progressBar.style.width = progress + '%';
            progressBar.setAttribute('aria-valuenow', progress);
            progressBar.innerText = progress.toFixed(2) + '%'; // Update the progress text


        }, function(error) {
            console.log(error.message);
        }, function() {
            uploadTask.snapshot.ref.getDownloadURL().then(function(downloadURL) {
                progressBarContainer.style.display = 'none';
                var url = downloadURL;
                callback(url);
                console.log(url);
            });
        });
        progressBarContainer.style.display = 'block';

    }

    
    
    //  Update file 

    function updateFile(callback) {
        
        var fileUpdate = document.getElementById("update_file").files[0];
        var selectedType = $('#update_type').val();
        console.log(selectedType);
        var updateBarContainer = document.getElementById("update-bar-container");
        var updateBar = updateBarContainer.querySelector('.update-bar');



        console.log(fileUpdate);

        var defaultURL = $('#update_url').val();

        if (!fileUpdate) {
            // Handle the case when no image is selected
            console.log("No file selected");
            callback(defaultURL);
        }
        else{

            console.log(fileUpdate);

            var fileName = fileUpdate.name;
           
            if (!firebase.apps.length) {
            var firebaseConfig = {

                // Firebase configuration here

                apiKey: "AIzaSyBTRtct-hu1DgnG61cvpoXmwZm2lfXp6QU",
                authDomain: "ztfr-ff6ab.firebaseapp.com",
                projectId: "ztfr-ff6ab",
                storageBucket: "ztfr-ff6ab.appspot.com",
                messagingSenderId: "1080163201988",
                appId: "1:1080163201988:web:e99c813fdbbea5572e6a91",
                measurementId: "G-R6FNCSNE9R",
          
            
            };

            firebase.initializeApp(firebaseConfig);
        }
           

            // Get a reference to the storage service
            var storage = firebase.storage();

            if(selectedType == "image"){
                var storageRef = firebase.storage().ref('/country/homepageimages/' + fileName);
            }
            else if(selectedType == "video"){
                var storageRef = firebase.storage().ref('/advertVideos/' + fileName);
            }

            var uploadTask = storageRef.put(fileUpdate);

            uploadTask.on('state_changed', function(snapshot) {

                var progress = (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
                updateBar.style.width = progress + '%';
                updateBar.setAttribute('aria-valuenow', progress);
                updateBar.innerText = progress.toFixed(2) + '%'; // Update the progress text

  
            }, 
            function(error) {
                console.log(error.message);
            },
            function() {
                uploadTask.snapshot.ref.getDownloadURL().then(function(downloadURL) {
                    updateBarContainer.style.display = 'none';
                    var url = downloadURL;
                    callback(url);
                    console.log(url);
                });
            });
            updateBarContainer.style.display = 'block';

        }
    }

</script>





<script>
    $(document).ready(function() {

        $('.add').click(function() {
            $('#addAdvertisement').modal('show');
        });

        $('#type').change(function() {

            $('#upload_file').val('');
            $('#sending-message').text('');


        });

        $('#upload_file').change(function() {
            var selectedType = $('#type').val();
            var uploadFile = this.files[0];
            console.log(uploadFile);

            if (!uploadFile) {
                return;
            }
            
            var fileType = uploadFile.type.split('/')[0]; 
            console.log("fileType: " + fileType);

            $('#sending-message').text('');

            if (fileType !== selectedType) {
                $('#sending-message').text('Please select a valid ' + selectedType);

                this.value = ''; 
            }

        });

        $('#addAdvertForm').submit(function(e) {
            e.preventDefault(); 

            var type = $('#type').val();

            var theme_id = $('#theme_id').val();

            var country_id = $('#country_id').val();

            var page_tag = $('#page_tag').val();

            uploadFile(function(url) {

                $('#sending-message').text('Processing request, please wait...');

                $.ajax({
                    url: "<?php echo e(url('admin/add-advertisement')); ?>", 
                    type: "GET",
                    
                    data:{
                        'type': type,
                        'theme_id': theme_id,
                        'country_id': country_id,
                        'page_tag': page_tag,
                        'url': url,
                    },
                   
                    success: function(response) {
                        

                    },
                    error: function(xhr) {
                        $('#sending-message').text(xhr);
                        console.log(xhr.responseText);
                    },
                    complete: function(){
                        $('#sending-message').text('');
                        $('#addAdvertisement').modal('hide');
                        location.reload();
                    }
                });

            });

        });
    });

</script>






<script>
    $(document).ready(function () {
       
        $(document).on('click','.status' ,function () {

            var advertisement_id = $(this).val();

            $('#editAdvertisement').modal('show');

            $('#update_type').change(function() {
           
            $('#update_file').val('');

            $('#update-message').text('');


        });

        $('#update_file').change(function() {

            var selectedType = $('#update_type').val();

            var updateFile = this.files[0];

            
            if (!updateFile) {
                return;
            }
            
            var fileType = updateFile.type.split('/')[0]; 

            
            $('#update-message').text('');

            if (fileType !== selectedType) {
                $('#update-message').text('Please select a valid ' + selectedType);

                this.value = ''; 
            }

        });

            $.ajax({
                type: "GET",
                url: "/admin/edit-advertisement/"+advertisement_id,
                success: function (response) {
                    console.log(response);
                    $('#advertisement_id').val(advertisement_id);
                    $('#update_type').val(response.advertisement.type);
                    $('#id_theme').val(response.advertisement.theme_id);
                    $('#id_country').val(response.advertisement.country_id);
                    $('#update_url').val(response.advertisement.url);
                    $('#update_page_tag').val(response.advertisement.page_tag);


                }
            });
        });
    });
</script>




<script>

    $(document).ready(function() {
        $('#updateAdvertBtn').on('click', function() {
            
            var advertisement_id = $('#advertisement_id').val();

            var type = $('#update_type').val();

            var theme_id = $('#id_theme').val();

            var country_id = $('#id_country').val();

            var page_tag = $('#update_page_tag').val();

        
            
            updateFile(function(url) {

                var updated_url = url;

                console.log(updated_url);

                $('#update-message').text('Processing request, please wait...');

                $.ajax({
                    url: '/admin/update-advertisement',
                    type: 'GET',
                    data: {
                        'advertisement_id' : advertisement_id,  
                        'type': type,
                        'theme_id': theme_id,
                        'country_id': country_id,
                        'page_tag': page_tag,
                        'updated_url': updated_url,
                    },
                    success: function(response) {
                    },
                    error: function(xhr) {

                        $('#update-message').text(xhr);
                    },
                    complete: function() {
                        $('#update-message').text('');
                        $('#editAdvertisement').modal('hide');
                        location.reload();
                    }
                });
            });
        });
    });

</script>

<?php echo $__env->make('brackets/admin-ui::admin.layout.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\backend-zitransfer\src\resources\views/admin/advertisement/index.blade.php ENDPATH**/ ?>