

<?php $__env->startSection('title', 'Med FLight'); ?>



<link
rel="stylesheet"
href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css"
integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm"
crossorigin="anonymous" />


<style>
    span{
        font-weight: bold;
    }
</style>

<?php $__env->startSection('body'); ?>


    <div class="container">
        <h1>Case 1</h1>
        <div class="row">
            <div class="col-md-6">
                <span style="text-transform: uppercase">Client</span><p><?php echo e(@$data->client); ?></p>
            </div>
            <div class="col-md-6">
                <span style="text-transform: uppercase">status</span><p><?php echo e($data->status); ?></p>
            </div>
    
            <div class="col-md-6">
                <span style="text-transform: uppercase">dob</span><p><?php echo e($data->dob); ?></p>
            </div>
            <div class="col-md-6">
                <span style="text-transform: uppercase">coordinator</span><p><?php echo e($data->coordinator); ?></p>
            </div>
            <div class="col-md-6">
                <span style="text-transform: uppercase">phone</span><p><?php echo e($data->phone); ?></p>
            </div>
            <div class="col-md-6">
                <span style="text-transform: uppercase">email</span><p><?php echo e($data->email); ?></p>
            </div>
            <div class="col-md-6">
                <span style="text-transform: uppercase">fax</span><p><?php echo e($data->fax); ?></p>
            </div>
            <div class="col-md-6">
                <span style="text-transform: uppercase">rn</span><p><?php echo e($data->rn); ?></p>
            </div>
            <div class="col-md-6">
                <span style="text-transform: uppercase">rn email</span><p><?php echo e($data->rn_email); ?></p>
            </div>
            <div class="col-md-6">
                <span style="text-transform: uppercase">rn fax</span><p><?php echo e($data->rn_fax); ?></p>
            </div>
          
        </div>


        <h1>Case 2</h1>
        <div class="row">
            <div class="col-md-6">
                <span style="text-transform: uppercase">client name</span><p><?php echo e(@$data->case_2->client_name); ?></p>
            </div>
            <div class="col-md-6">
                <span style="text-transform: uppercase">status</span><p><?php echo e(@$data->case_2->client_name); ?></p>
            </div>
    
            <div class="col-md-6">
                <span style="text-transform: uppercase">dob</span><p><?php echo e(@$data->case_2->dob); ?></p>
            </div>
            <div class="col-md-6">
                <span style="text-transform: uppercase">coordinator</span><p><?php echo e(@$data->case_2->coordinator); ?></p>
            </div>
            <div class="col-md-6">
                <span style="text-transform: uppercase">flight rn</span><p><?php echo e(@$data->case_2->flight_rn); ?></p>
            </div>
    
        </div>



        <h1>Client Document Status</h1>
        <div class="row">
            <div class="col-md-6">
                <span style="text-transform: uppercase">fitness check </span><p><?php echo e(@$data->ClientDocumentStatus->fitness_check); ?></p>
            </div>
            <div class="col-md-6">
                <span style="text-transform: uppercase">medfit check</span><p><?php echo e(@$data->ClientDocumentStatus->medfit_check); ?></p>
            </div>
         
            <div class="col-md-6">
                <span style="text-transform: uppercase">dc order  check</span><p><?php echo e(@$data->ClientDocumentStatus->dc_order_check); ?></p>
            </div>
         
            <div class="col-md-6">
                <span style="text-transform: uppercase">dc order  check</span><p><?php echo e(@$data->ClientDocumentStatus->dc_order_check); ?></p>
            </div>

            <div class="col-md-6">
                <span style="text-transform: uppercase">constent check</span><p><?php echo e(@$data->ClientDocumentStatus->constent_check); ?></p>
            </div>
         
            <div class="col-md-6">
                <span style="text-transform: uppercase">identification check</span><p><?php echo e(@$data->ClientDocumentStatus->identification_check); ?></p>
            </div>
         
            <div class="col-md-6">
                <span style="text-transform: uppercase">identification check</span><p><?php echo e(@$data->ClientDocumentStatus->other); ?></p>
            </div>
         
            <div class="col-md-6">
                <span style="text-transform: uppercase">identification check</span><p><?php echo e(@$data->ClientDocumentStatus->other); ?></p>
            </div>
         
        </div>

        <h1>Client Nurse To Nurse</h1>
        <div class="row">
            <div class="col-md-6">
                <span style="text-transform: uppercase">rn name </span><p><?php echo e(@$data->ClientNurseToNurse->rn_name); ?></p>
            </div>
            <div class="col-md-6">
                <span style="text-transform: uppercase">date time</span><p><?php echo e(@$data->ClientNurseToNurse->date_time); ?></p>
            </div>
         
            <div class="col-md-6">
                <span style="text-transform: uppercase">temp</span><p><?php echo e(@$data->ClientNurseToNurse->temp); ?></p>
            </div>
         
            <div class="col-md-6">
                <span style="text-transform: uppercase">hr</span><p><?php echo e(@$data->ClientNurseToNurse->hr); ?></p>
            </div>

            <div class="col-md-6">
                <span style="text-transform: uppercase">bp</span><p><?php echo e(@$data->ClientNurseToNurse->bp); ?></p>
            </div>
         
            <div class="col-md-6">
                <span style="text-transform: uppercase">rr</span><p><?php echo e(@$data->ClientNurseToNurse->rr); ?></p>
            </div>
         
            <div class="col-md-6">
                <span style="text-transform: uppercase">fio2</span><p><?php echo e(@$data->ClientNurseToNurse->fio2); ?></p>
            </div>
            <div class="col-md-6">
                <span style="text-transform: uppercase">spo2</span>
                <p><?php echo e(@$data->ClientNurseToNurse->spo2); ?></p>
            </div>
            <div class="col-md-6">
                <span style="text-transform: uppercase">allergies</span>
                <p><?php echo e(@$data->ClientNurseToNurse->allergies); ?></p>
            </div>
            <div class="col-md-6">
                <span style="text-transform: uppercase">nuero</span>
                <p><?php echo e(@$data->ClientNurseToNurse->nuero); ?></p>
            </div>
            <div class="col-md-6">
                <span style="text-transform: uppercase">cv</span>
                <p><?php echo e(@$data->ClientNurseToNurse->cv); ?></p>
            </div>
         
            <div class="col-md-6">
                <span style="text-transform: uppercase">pulm</span>
                <p><?php echo e(@$data->ClientNurseToNurse->pulm); ?></p>
            </div>
            <div class="col-md-6">
                <span style="text-transform: uppercase">gl</span>
                <p><?php echo e(@$data->ClientNurseToNurse->gl); ?></p>
            </div>
            <div class="col-md-6">
                <span style="text-transform: uppercase">gu</span>
                <p><?php echo e(@$data->ClientNurseToNurse->gu); ?></p>
            </div>
            <div class="col-md-6">
                <span style="text-transform: uppercase">skin</span>
                <p><?php echo e(@$data->ClientNurseToNurse->skin); ?></p>
            </div>
         
            <div class="col-md-6">
                <span style="text-transform: uppercase">analgesia</span>
                <p><?php echo e(@$data->ClientNurseToNurse->analgesia); ?></p>
            </div>
            <div class="col-md-6">
                <span style="text-transform: uppercase">sedation</span>
                <p><?php echo e(@$data->ClientNurseToNurse->sedation); ?></p>
            </div>
            <div class="col-md-6">
                <span style="text-transform: uppercase">iv</span>
                <p><?php echo e(@$data->ClientNurseToNurse->iv); ?></p>
            </div>
         
            <div class="col-md-6">
                <span style="text-transform: uppercase">notes</span>
                <p><?php echo e(@$data->ClientNurseToNurse->notes); ?></p>
            </div>
         
        </div>

        <h1>Commercial Airline</h1>
        <div class="row">
            <div class="col-md-6">
                <span style="text-transform: uppercase">passenger name </span><p><?php echo e(@$data->CommercialAirline->passenger_name); ?></p>
            </div>
         
            <div class="col-md-6">
                <span style="text-transform: uppercase">discharging md</span><p><?php echo e(@$data->CommercialAirline->discharging_md); ?></p>
            </div>
         
            <div class="col-md-6">
                <span style="text-transform: uppercase">discharging facility</span><p><?php echo e(@$data->CommercialAirline->discharging_facility); ?></p>
            </div>
         
            <div class="col-md-6">
                <span style="text-transform: uppercase"> rehab unit</span><p><?php echo e(@$data->CommercialAirline->rehab_unit); ?></p>
            </div>
         
            <div class="col-md-6">
                <span style="text-transform: uppercase">unit phone </span><p><?php echo e(@$data->CommercialAirline->unit_phone); ?></p>
            </div>
         
        </div>



        <h1>Discharging Facility</h1>
        <div class="row">
            <div class="col-md-6">
                <span style="text-transform: uppercase">present location </span><p><?php echo e(@$data->DischargingFacility->present_location); ?></p>
            </div>
            <div class="col-md-6">
                <span style="text-transform: uppercase">phone </span><p><?php echo e(@$data->DischargingFacility->phone); ?></p>
            </div>
            <div class="col-md-6">
                <span style="text-transform: uppercase">address </span><p><?php echo e(@$data->DischargingFacility->address); ?></p>
            </div>
            <div class="col-md-6">
                <span style="text-transform: uppercase">city state </span><p><?php echo e(@$data->DischargingFacility->city_state); ?></p>
            </div>
            <div class="col-md-6">
                <span style="text-transform: uppercase">room </span><p><?php echo e(@$data->DischargingFacility->room); ?></p>
            </div>
            <div class="col-md-6">
                <span style="text-transform: uppercase">zip </span><p><?php echo e(@$data->DischargingFacility->zip); ?></p>
            </div>
            <div class="col-md-6">
                <span style="text-transform: uppercase">unit </span><p><?php echo e(@$data->DischargingFacility->unit); ?></p>
            </div>
            <div class="col-md-6">
                <span style="text-transform: uppercase">unit phone </span><p><?php echo e(@$data->DischargingFacility->unit_phone); ?></p>
            </div>
            <div class="col-md-6">
                <span style="text-transform: uppercase">attending md </span><p><?php echo e(@$data->DischargingFacility->attending_md); ?></p>
            </div>
            <div class="col-md-6">
                <span style="text-transform: uppercase">fax </span><p><?php echo e(@$data->DischargingFacility->fax); ?></p>
            </div>
            <div class="col-md-6">
                <span style="text-transform: uppercase">admission date </span><p><?php echo e(@$data->DischargingFacility->admission_date); ?></p>
            </div>
            <div class="col-md-6">
                <span style="text-transform: uppercase">admission date </span><p><?php echo e(@$data->DischargingFacility->admission_date); ?></p>
            </div>
         
        </div>

        <h1>Flight Detail</h1>
        <div class="row">
            <div class="col-md-6">
                <span style="text-transform: uppercase">rn outbound </span><p><?php echo e(@$data->FlightDetail->rn_outbound); ?></p>
            </div>
            <div class="col-md-6">
                <span style="text-transform: uppercase">client rn </span><p><?php echo e(@$data->FlightDetail->client_rn); ?></p>
            </div>
            <div class="col-md-6">
                <span style="text-transform: uppercase">rn return </span><p><?php echo e(@$data->FlightDetail->rn_return); ?></p>
            </div>
            <div class="col-md-6">
                <span style="text-transform: uppercase">notes </span><p><?php echo e(@$data->FlightDetail->notes); ?></p>
            </div>
           
         
        </div>

        <h1>Flight Angels</h1>
        <div class="row">
            <div class="col-md-6">
                <span style="text-transform: uppercase">from </span><p><?php echo e(@$data->FlyingAngels->from); ?></p>
            </div>
            <div class="col-md-6">
                <span style="text-transform: uppercase">to</span><p><?php echo e(@$data->FlyingAngels->to); ?></p>
            </div>
            <div class="col-md-6">
                <span style="text-transform: uppercase">fax </span><p><?php echo e(@$data->FlyingAngels->fax); ?></p>
            </div>
            <div class="col-md-6">
                <span style="text-transform: uppercase">pages </span><p><?php echo e(@$data->FlyingAngels->pages); ?></p>
            </div>
            <div class="col-md-6">
                <span style="text-transform: uppercase">phone </span><p><?php echo e(@$data->FlyingAngels->phone); ?></p>
            </div>
           
            <div class="col-md-6">
                <span style="text-transform: uppercase">date </span><p><?php echo e(@$data->FlyingAngels->date); ?></p>
            </div>
           
            <div class="col-md-6">
                <span style="text-transform: uppercase">re </span><p><?php echo e(@$data->FlyingAngels->re); ?></p>
            </div>
           
            <div class="col-md-6">
                <span style="text-transform: uppercase">dear name </span><p><?php echo e(@$data->FlyingAngels->dear_name); ?></p>
            </div>
           
            <div class="col-md-6">
                <span style="text-transform: uppercase">facesheet check </span><p><?php echo e(@$data->FlyingAngels->facesheet_check); ?></p>
            </div>
           
            <div class="col-md-6">
                <span style="text-transform: uppercase">commercial check </span><p><?php echo e(@$data->FlyingAngels->commercial_check); ?></p>
            </div>
           
            <div class="col-md-6">
                <span style="text-transform: uppercase">fitness check </span><p><?php echo e(@$data->FlyingAngels->fitness_check); ?></p>
            </div>
           
            <div class="col-md-6">
                <span style="text-transform: uppercase">constent check</span><p><?php echo e(@$data->FlyingAngels->constent_check); ?></p>
            </div>
           
            <div class="col-md-6">
                <span style="text-transform: uppercase">photo check</span><p><?php echo e(@$data->FlyingAngels->photo_check); ?></p>
            </div>
           
            <div class="col-md-6">
                <span style="text-transform: uppercase">appropiate check</span><p><?php echo e(@$data->FlyingAngels->appropiate_check); ?></p>
            </div>
           
            <div class="col-md-6">
                <span style="text-transform: uppercase">other</span><p><?php echo e(@$data->FlyingAngels->other); ?></p>
            </div>
           
            <div class="col-md-6">
                <span style="text-transform: uppercase">other check</span><p><?php echo e(@$data->FlyingAngels->other_check); ?></p>
            </div>
           
            <div class="col-md-6">
                <span style="text-transform: uppercase">please check</span><p><?php echo e(@$data->FlyingAngels->please_check); ?></p>
            </div>
           
         
           
            <div class="col-md-6">
                <span style="text-transform: uppercase">comment</span><p><?php echo e(@$data->FlyingAngels->comment); ?></p>
            </div>
           
         
        </div>

        <h1>Flying Rule</h1>
        <div class="row">
            <div class="col-md-6">
                <span style="text-transform: uppercase">pre diet check </span><p><?php echo e(@$data->FlyingRule->pre_diet_check); ?></p>
            </div>
            <div class="col-md-6">
                <span style="text-transform: uppercase">pre dvt check</span><p><?php echo e(@$data->FlyingRule->pre_dvt_check); ?></p>
            </div>
            <div class="col-md-6">
                <span style="text-transform: uppercase">pre bowel check</span><p><?php echo e(@$data->FlyingRule->pre_bowel_check); ?></p>
            </div>
            <div class="col-md-6">
                <span style="text-transform: uppercase">pre other check </span><p><?php echo e(@$data->FlyingRule->pre_other_check); ?></p>
            </div>
            <div class="col-md-6">
                <span style="text-transform: uppercase">in oxygen check</span><p><?php echo e(@$data->FlyingRule->in_oxygen_check); ?></p>
            </div>
            <div class="col-md-6">
                <span style="text-transform: uppercase">in foley check</span><p><?php echo e(@$data->FlyingRule->in_foley_check); ?></p>
            </div>
            <div class="col-md-6">
                <span style="text-transform: uppercase">iv fluids</span><p><?php echo e(@$data->FlyingRule->iv_fluids); ?></p>
            </div>
            <div class="col-md-6">
                <span style="text-transform: uppercase">iv fluid check </span><p><?php echo e(@$data->FlyingRule->iv_fluid_check); ?></p>
            </div>
            <div class="col-md-6">
                <span style="text-transform: uppercase">solution </span><p><?php echo e(@$data->FlyingRule->solution); ?></p>
            </div>
            <div class="col-md-6">
                <span style="text-transform: uppercase">solution check </span><p><?php echo e(@$data->FlyingRule->solution_check); ?></p>
            </div>
            <div class="col-md-6">
                <span style="text-transform: uppercase">rate ml </span><p><?php echo e(@$data->FlyingRule->rate_ml); ?></p>
            </div>
            <div class="col-md-6">
                <span style="text-transform: uppercase">rate ml check </span><p><?php echo e(@$data->FlyingRule->rate_ml_check); ?></p>
            </div>
            <div class="col-md-6">
                <span style="text-transform: uppercase">in other check</span><p><?php echo e(@$data->FlyingRule->in_other_check); ?></p>
            </div>
            <div class="col-md-6">
                <span style="text-transform: uppercase">in medication check</span><p><?php echo e(@$data->FlyingRule->in_medication_check); ?></p>
            </div>
            <div class="col-md-6">
                <span style="text-transform: uppercase">hour </span><p><?php echo e(@$data->FlyingRule->in_hour); ?></p>
            </div>
            <div class="col-md-6">
                <span style="text-transform: uppercase">in sedation check</span><p><?php echo e(@$data->FlyingRule->in_sedation_check); ?></p>
            </div>
            <div class="col-md-6">
                <span style="text-transform: uppercase">in analgesia check </span><p><?php echo e(@$data->FlyingRule->in_analgesia_check); ?></p>
            </div>
            <div class="col-md-6">
                <span style="text-transform: uppercase">in provider </span><p><?php echo e(@$data->FlyingRule->in_provider); ?></p>
            </div>
            <div class="col-md-6">
                <span style="text-transform: uppercase">in signature </span><p><?php echo e(@$data->FlyingRule->in_signature); ?></p>
            </div>
            <div class="col-md-6">
                <span style="text-transform: uppercase">in date </span><p><?php echo e(@$data->FlyingRule->in_date); ?></p>
            </div>
           
         
        </div>

        <h1>Ground Detail</h1>
        <div class="row">
            <div class="col-md-6">
                <span style="text-transform: uppercase">departure </span><p><?php echo e(@$data->GroundDetail->departure); ?></p>
            </div>
            <div class="col-md-6">
                <span style="text-transform: uppercase">arrival </span><p><?php echo e(@$data->GroundDetail->arrival); ?></p>
            </div>
            <div class="col-md-6">
                <span style="text-transform: uppercase">notes </span><p><?php echo e(@$data->GroundDetail->notes); ?></p>
            </div>
          
        </div>


        <h1>Intake</h1>
        <div class="row">
            <div class="col-md-6">
                <span style="text-transform: uppercase">departure </span><p><?php echo e(@$data->intake->client_name); ?></p>
            </div>
            <div class="col-md-6">
                <span style="text-transform: uppercase">dob </span><p><?php echo e(@$data->intake->dob); ?></p>
            </div>
            <div class="col-md-6">
                <span style="text-transform: uppercase">age </span><p><?php echo e(@$data->intake->age); ?></p>
            </div>
          
            <div class="col-md-6">
                <span style="text-transform: uppercase">diagnosis </span><p><?php echo e(@$data->intake->diagnosis); ?></p>
            </div>
          
          
            <div class="col-md-6">
                <span style="text-transform: uppercase">height </span><p><?php echo e(@$data->intake->height); ?></p>
            </div>
          
          
            <div class="col-md-6">
                <span style="text-transform: uppercase">weight </span><p><?php echo e(@$data->intake->weight); ?></p>
            </div>
          
          
            <div class="col-md-6">
                <span style="text-transform: uppercase">contact number </span><p><?php echo e(@$data->intake->contact_number); ?></p>
            </div>
          
            <div class="col-md-6">
                <span style="text-transform: uppercase">secondary contact </span><p><?php echo e(@$data->intake->secondary_contact); ?></p>
            </div>
          
            <div class="col-md-6">
                <span style="text-transform: uppercase">contact number 2 </span><p><?php echo e(@$data->intake->contact_number_2); ?></p>
            </div>
          
          
            <div class="col-md-6">
                <span style="text-transform: uppercase">realtionship </span><p><?php echo e(@$data->intake->relationship); ?></p>
            </div>
          
            <div class="col-md-6">
                <span style="text-transform: uppercase">email </span><p><?php echo e(@$data->intake->email); ?></p>
            </div>
          
            <div class="col-md-6">
                <span style="text-transform: uppercase">other </span><p><?php echo e(@$data->intake->other); ?></p>
            </div>
          
            <div class="col-md-6">
                <span style="text-transform: uppercase">address </span><p><?php echo e(@$data->intake->address); ?></p>
            </div>
          
          
            <div class="col-md-6">
                <span style="text-transform: uppercase">client rep </span><p><?php echo e(@$data->intake->client_rep); ?></p>
            </div>
          
        </div>

        
        <h1>Loading Detail</h1>
        <div class="row">
            <div class="col-md-6">
                <span style="text-transform: uppercase">loading_1 </span><p><?php echo e(@$data->intake->loading_1); ?></p>
            </div>
            <div class="col-md-6">
                <span style="text-transform: uppercase">loading_2 </span><p><?php echo e(@$data->intake->loading_2); ?></p>
            </div>
            <div class="col-md-6">
                <span style="text-transform: uppercase">loading_3 </span><p><?php echo e(@$data->intake->loading_3); ?></p>
            </div>
        
          
        </div>
        <h1>Medical Need</h1>
        <div class="row">
            <div class="col-md-6">
                <span style="text-transform: uppercase">oxygen </span><p><?php echo e(@$data->MedicalNeed->oxygen); ?></p>
            </div>
            <div class="col-md-6">
                <span style="text-transform: uppercase">spo2_target </span><p><?php echo e(@$data->MedicalNeed->spo2_target); ?></p>
            </div>
            <div class="col-md-6">
                <span style="text-transform: uppercase">class of service </span><p><?php echo e(@$data->MedicalNeed->class_of_service); ?></p>
            </div>
        
            <div class="col-md-6">
                <span style="text-transform: uppercase">sit up tolerance </span><p><?php echo e(@$data->MedicalNeed->sit_up_tolerance); ?></p>
            </div>
        
            <div class="col-md-6">
                <span style="text-transform: uppercase">econ acceptable</span><p><?php echo e(@$data->MedicalNeed->econ_acceptable); ?></p>
            </div>
        
            <div class="col-md-6">
                <span style="text-transform: uppercase">staff needed</span><p><?php echo e(@$data->MedicalNeed->staff_needed); ?></p>
            </div>
        
            <div class="col-md-6">
                <span style="text-transform: uppercase">special service request</span><p><?php echo e(@$data->MedicalNeed->special_service_request); ?></p>
            </div>
        
            <div class="col-md-6">
                <span style="text-transform: uppercase">oxygen needed during</span><p><?php echo e(@$data->MedicalNeed->oxygen_needed_during); ?></p>
            </div>
        
            <div class="col-md-6">
                <span style="text-transform: uppercase">oxygen needed during</span><p><?php echo e(@$data->MedicalNeed->oxygen_needed_during); ?></p>
            </div>
        
          
        </div>
        <h1>Medical Treatment</h1>
        <div class="row">
            <div class="col-md-6">
                <span style="text-transform: uppercase">name </span><p><?php echo e(@$data->MedicalTreatment->name); ?></p>
            </div>
            
            <div class="col-md-6">
                <span style="text-transform: uppercase">text2 </span><p><?php echo e(@$data->MedicalTreatment->text2); ?></p>
            </div>
            
            <div class="col-md-6">
                <span style="text-transform: uppercase">from </span><p><?php echo e(@$data->MedicalTreatment->from); ?></p>
            </div>
            
            <div class="col-md-6">
                <span style="text-transform: uppercase">to </span><p><?php echo e(@$data->MedicalTreatment->to); ?></p>
            </div>
            
            
            <div class="col-md-6">
                <span style="text-transform: uppercase">from1 </span><p><?php echo e(@$data->MedicalTreatment->from1); ?></p>
            </div>
            
            
            <div class="col-md-6">
                <span style="text-transform: uppercase">to1 </span><p><?php echo e(@$data->MedicalTreatment->to1); ?></p>
            </div>
            
            <div class="col-md-6">
                <span style="text-transform: uppercase">client signature </span><p><?php echo e(@$data->MedicalTreatment->client_signature); ?></p>
            </div>
            
            <div class="col-md-6">
                <span style="text-transform: uppercase">client date </span><p><?php echo e(@$data->MedicalTreatment->client_date); ?></p>
            </div>
            <div class="col-md-6">
                <span style="text-transform: uppercase">guardian signature </span><p><?php echo e(@$data->MedicalTreatment->guardian_signature); ?></p>
            </div>
            <div class="col-md-6">
                <span style="text-transform: uppercase">guardian date </span><p><?php echo e(@$data->MedicalTreatment->guardian_date); ?></p>
            </div>
            
          
        </div>

        <h1>Physican Statement</h1>
        <div class="row">
            <div class="col-md-6">
                <span style="text-transform: uppercase">passenger name </span><p><?php echo e(@$data->PhysicanStatement->passenger_name); ?></p>
            </div>
            <div class="col-md-6">
                <span style="text-transform: uppercase">date of travel </span><p><?php echo e(@$data->PhysicanStatement->date_of_travel); ?></p>
            </div>
            <div class="col-md-6">
                <span style="text-transform: uppercase">from </span><p><?php echo e(@$data->PhysicanStatement->from); ?></p>
            </div>
            <div class="col-md-6">
                <span style="text-transform: uppercase">to </span><p><?php echo e(@$data->PhysicanStatement->to); ?></p>
            </div>
            
            <div class="col-md-6">
                <span style="text-transform: uppercase">to </span><p><?php echo e(@$data->PhysicanStatement->to); ?></p>
            </div>
            
            <div class="col-md-6">
                <span style="text-transform: uppercase">airline </span><p><?php echo e(@$data->PhysicanStatement->airline); ?></p>
            </div>

            <div class="col-md-6">
                <span style="text-transform: uppercase">flight </span><p><?php echo e(@$data->PhysicanStatement->flight); ?></p>
            </div>
            

            <div class="col-md-6">
                <span style="text-transform: uppercase">departure time </span><p><?php echo e(@$data->PhysicanStatement->departure_time); ?></p>
            </div>

            <div class="col-md-6">
                <span style="text-transform: uppercase">arrival time </span><p><?php echo e(@$data->PhysicanStatement->arrival_time); ?></p>
            </div>
            <div class="col-md-6">
                <span style="text-transform: uppercase">arrival time </span><p><?php echo e(@$data->PhysicanStatement->arival_time); ?></p>
            </div>

            <div class="col-md-6">
                <span style="text-transform: uppercase">discharging facility </span><p><?php echo e(@$data->PhysicanStatement->discharging_facility); ?></p>
            </div>
            
           

            <div class="col-md-6">
                <span style="text-transform: uppercase">discharging md</span><p><?php echo e(@$data->PhysicanStatement->discharging_md); ?></p>
            </div>
            

            <div class="col-md-6">
                <span style="text-transform: uppercase">facility address</span><p><?php echo e(@$data->PhysicanStatement->facility_address); ?></p>
            </div>

            <div class="col-md-6">
                <span style="text-transform: uppercase">phone_number</span><p><?php echo e(@$data->PhysicanStatement->phone_number); ?></p>
            </div>

            <div class="col-md-6">
                <span style="text-transform: uppercase">addmision date</span><p><?php echo e(@$data->PhysicanStatement->addmision_date); ?></p>
            </div>

            <div class="col-md-6">
                <span style="text-transform: uppercase">diagnosis</span><p><?php echo e(@$data->PhysicanStatement->diagnosis); ?></p>
            </div>

            <div class="col-md-6">
                <span style="text-transform: uppercase">ftf from date</span><p><?php echo e(@$data->PhysicanStatement->ftf_from_date); ?></p>
            </div>
            

            <div class="col-md-6">
                <span style="text-transform: uppercase">class of service</span><p><?php echo e(@$data->PhysicanStatement->class_of_service); ?></p>
            </div>
            

            <div class="col-md-6">
                <span style="text-transform: uppercase">economy</span><p><?php echo e(@$data->PhysicanStatement->economy); ?></p>
            </div>
            

            <div class="col-md-6">
                <span style="text-transform: uppercase">passenger</span><p><?php echo e(@$data->PhysicanStatement->passenger); ?></p>
            </div>

            <div class="col-md-6">
                <span style="text-transform: uppercase">oxygen required</span><p><?php echo e(@$data->PhysicanStatement->oxygen_required); ?></p>
            </div>

            <div class="col-md-6">
                <span style="text-transform: uppercase">oxygen needed</span><p><?php echo e(@$data->PhysicanStatement->oxygen_needed); ?></p>
            </div>

            <div class="col-md-6">
                <span style="text-transform: uppercase">sop2 target</span><p><?php echo e(@$data->PhysicanStatement->sop2_target); ?></p>
            </div>
            

            <div class="col-md-6">
                <span style="text-transform: uppercase">attendant</span><p><?php echo e(@$data->PhysicanStatement->attendant); ?></p>
            </div>

            <div class="col-md-6">
                <span style="text-transform: uppercase">special service</span><p><?php echo e(@$data->PhysicanStatement->special_service); ?></p>
            </div>

            <div class="col-md-6">
                <span style="text-transform: uppercase">for seen</span><p><?php echo e(@$data->PhysicanStatement->forseen); ?></p>
            </div>

            <div class="col-md-6">
                <span style="text-transform: uppercase">contagious</span><p><?php echo e(@$data->PhysicanStatement->contagious); ?></p>
            </div>

            <div class="col-md-6">
                <span style="text-transform: uppercase">prognosis</span><p><?php echo e(@$data->PhysicanStatement->prognosis); ?></p>
            </div>
            

            <div class="col-md-6">
                <span style="text-transform: uppercase">address</span><p><?php echo e(@$data->PhysicanStatement->address); ?></p>
            </div>

            <div class="col-md-6">
                <span style="text-transform: uppercase">address</span><p><?php echo e(@$data->PhysicanStatement->address); ?></p>
            </div>
            

            <div class="col-md-6">
                <span style="text-transform: uppercase">physician name</span><p><?php echo e(@$data->PhysicanStatement->physician_name); ?></p>
            </div>

            <div class="col-md-6">
                <span style="text-transform: uppercase">signature</span><p><?php echo e(@$data->PhysicanStatement->signature); ?></p>
            </div>

            <div class="col-md-6">
                <span style="text-transform: uppercase">date</span><p><?php echo e(@$data->PhysicanStatement->date); ?></p>
            </div>
          
        </div>

        <h1>Receiving Facility</h1>
        <div class="row">
            <div class="col-md-6">
                <span style="text-transform: uppercase">destination </span><p><?php echo e(@$data->ReceivingFacility->destination); ?></p>
            </div>

            <div class="col-md-6">
                <span style="text-transform: uppercase">phone </span><p><?php echo e(@$data->ReceivingFacility->phone); ?></p>
            </div>
         

            <div class="col-md-6">
                <span style="text-transform: uppercase">address </span><p><?php echo e(@$data->ReceivingFacility->address); ?></p>
            </div>
         
            <div class="col-md-6">
                <span style="text-transform: uppercase">city state </span><p><?php echo e(@$data->ReceivingFacility->city_state); ?></p>
            </div>

            <div class="col-md-6">
                <span style="text-transform: uppercase">room </span><p><?php echo e(@$data->ReceivingFacility->room); ?></p>
            </div>

            <div class="col-md-6">
                <span style="text-transform: uppercase">zip </span><p><?php echo e(@$data->ReceivingFacility->zip); ?></p>
            </div>

            <div class="col-md-6">
                <span style="text-transform: uppercase">contact person </span><p><?php echo e(@$data->ReceivingFacility->contact_person); ?></p>
            </div>

            <div class="col-md-6">
                <span style="text-transform: uppercase">phone2 </span><p><?php echo e(@$data->ReceivingFacility->phone2); ?></p>
            </div>

            <div class="col-md-6">
                <span style="text-transform: uppercase">attending md </span><p><?php echo e(@$data->ReceivingFacility->attending_md); ?></p>
            </div>

            <div class="col-md-6">
                <span style="text-transform: uppercase">other </span><p><?php echo e(@$data->ReceivingFacility->other); ?></p>
            </div>
         
          
        </div>

        <h1>Third Party Payor</h1>
        <div class="row">
            <div class="col-md-6">
                <span style="text-transform: uppercase">company </span><p><?php echo e(@$data->ThirdPartyPayor->company); ?></p>
            </div>
            <div class="col-md-6">
                <span style="text-transform: uppercase">contact </span><p><?php echo e(@$data->ThirdPartyPayor->contact); ?></p>
            </div>
            <div class="col-md-6">
                <span style="text-transform: uppercase">phone </span><p><?php echo e(@$data->ThirdPartyPayor->phone); ?></p>
            </div>
            <div class="col-md-6">
                <span style="text-transform: uppercase">email </span><p><?php echo e(@$data->ThirdPartyPayor->email); ?></p>
            </div>
            <div class="col-md-6">
                <span style="text-transform: uppercase">address </span><p><?php echo e(@$data->ThirdPartyPayor->address); ?></p>
            </div>
            <div class="col-md-6">
                <span style="text-transform: uppercase">additional rep </span><p><?php echo e(@$data->ThirdPartyPayor->additional_rep); ?></p>
            </div>
            <div class="col-md-6">
                <span style="text-transform: uppercase">relevent history </span><p><?php echo e(@$data->ThirdPartyPayor->relevent_history); ?></p>
            </div>
            <div class="col-md-6">
                <span style="text-transform: uppercase">other </span><p><?php echo e(@$data->ThirdPartyPayor->other); ?></p>
            </div>

           
        </div>

        <h1>Travel Info</h1>
        <div class="row">
            <div class="col-md-6">
                <span style="text-transform: uppercase">travel date </span><p><?php echo e(@$data->TravelInfo->travel_date); ?></p>
            </div>
  
            <div class="col-md-6">
                <span style="text-transform: uppercase">travel_hour </span><p><?php echo e(@$data->TravelInfo->travel_hour); ?></p>
            </div>
  
            <div class="col-md-6">
                <span style="text-transform: uppercase">travel ftf start date </span><p><?php echo e(@$data->TravelInfo->travel_ftf_start_date); ?></p>
            </div>
  
            <div class="col-md-6">
                <span style="text-transform: uppercase">travel ftf end date </span><p><?php echo e(@$data->TravelInfo->travel_ftf_end_date); ?></p>
            </div>

            <div class="col-md-6">
                <span style="text-transform: uppercase">depart airport </span><p><?php echo e(@$data->TravelInfo->depart_airport); ?></p>
            </div>

            <div class="col-md-6">
                <span style="text-transform: uppercase">arrive airport </span><p><?php echo e(@$data->TravelInfo->arrive_airport); ?></p>
            </div>

            <div class="col-md-6">
                <span style="text-transform: uppercase">airline </span><p><?php echo e(@$data->TravelInfo->airline); ?></p>
            </div>
  
            <div class="col-md-6">
                <span style="text-transform: uppercase">depart time </span><p><?php echo e(@$data->TravelInfo->depart_time); ?></p>
            </div>
  
            <div class="col-md-6">
                <span style="text-transform: uppercase">depart facility</span><p><?php echo e(@$data->TravelInfo->depart_facility); ?></p>
            </div>
  
            <div class="col-md-6">
                <span style="text-transform: uppercase">arrive time</span><p><?php echo e(@$data->TravelInfo->arrive_time); ?></p>
            </div>
  
            <div class="col-md-6">
                <span style="text-transform: uppercase">arrive date</span><p><?php echo e(@$data->TravelInfo->arrive_date); ?></p>
            </div>
  
        </div>

        <h1>TravelInstruction</h1>
        <div class="row">
            <div class="col-md-6">
                <span style="text-transform: uppercase">general </span><p><?php echo e(@$data->TravelInstruction->general); ?></p>
            </div>
            <div class="col-md-6">
                <span style="text-transform: uppercase">loading_2 </span><p><?php echo e(@$data->TravelInstruction->loading_2); ?></p>
            </div>
  
            <div class="col-md-6">
                <span style="text-transform: uppercase">loading_3 </span><p><?php echo e(@$data->TravelInstruction->loading_3); ?></p>
            </div>
  
         
        </div>
    </div>

<?php $__env->stopSection(); ?> 


<?php echo $__env->make('brackets/admin-ui::admin.layout.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\medFlight\resources\views/admin/medFlight/detail.blade.php ENDPATH**/ ?>