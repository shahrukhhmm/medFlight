

<?php $__env->startSection('title', 'Theme'); ?>


<?php echo $__env->make('admin.components.styles', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



<?php $__env->startSection('body'); ?>


    <div class="row mt-4" >
        <div class="col">
            <div class="card">

                <div class="card-header">
                    <i class="fas fa-paint-brush"></i> Themes
                    <a class="btn btn-primary btn-sm pull-right m-b-0 add" href="#" data-toggle="modal"
                        data-target="#addBgImage" role="button"><i class="fa fa-plus"></i>&nbsp; New</a>

                </div>

                <div  class="col-md-12 pt-4" style="background:white;  display: flex;  flex-wrap: wrap; flex-direction: row; justify-content: center;">
                            

                    <form id="filter-form" style="display:flex; align-items:center;  flex-wrap: wrap; justify-content: space-between; margin-bottom: 0px;">

                        <label for="from_date" class="me-2 h4"  ></label>
                        <input type="date" id="from_date"class="me-2 form-control"   name="from_date"  style="width:40%;">

                        <label for="to_date" class="me-2 h4" >-</label>
                        <input type="date" id="to_date" class="me-2 form-control" name="to_date"  style="width:40%;">

                        <button type="submit" class=" me-2 btn btn-primary" style="padding: 9px;"><i class="fas fa-check"></i></button>
                        
                    </form>

                </div>

                <div class="card-body" v-cloak>

                    <?php if(session()->has('message')): ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <strong>Success</strong> &nbsp; <?php echo e(session()->get('message')); ?>

                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                    <?php endif; ?>

                    <!-- <div class="container">
                        <form id="filter-form" class="filter-form-container row">
                            <div class="col-sm-12 col-md-6 col-lg-5">
                                <label for="from_date" class="h6">From:</label>
                                <input type="date" id="from_date" class="form-control">
                            </div>
                            <div class="col-sm-12 col-md-6 col-lg-5">
                                <label for="to_date" class="h6">To:</label>
                                <input type="date" id="to_date" class="form-control">
                            </div>
                            <div style="margin-top: 30px;" class="col-sm-12 col-md-6 col-lg-2 applyBtn">
                                <button type="submit" class="btn btn-sm btn-success">Apply Filter</button>
                            </div>
                        </form>
                    </div> -->


                    <table class="datatables-basic table table-hover theme-listing table-listing" style="overflow:auto;">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Name</th>
                                <th>Created at</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                    </table>

                </div>
            </div>
        </div>
    </div>



    


    <div class="modal fade" id="addTheme" tabindex="-1" role="dialog" saria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog modal-md" role="document">

            <div class="modal-content ">

                <div class="modal-header d-flex justify-content-between">
                    <h5 class="modal-title text-dark" id="exampleModalLabel">Add Theme</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>

                <div class="modal-body text-dark">
                    <form id="addThemeForm" enctype="multipart/form-data">

                        <div id="sending-message" class="text-danger fw-bold"></div>

                        <div class="row d-flex justify-content-center align-items-center">

                            <div class="form-group col-md-12">

                                <label class="control-label">Name</label>
                                <input type="text" name="name" id="name" class="form-control field-radius">

                                <br>
                                <div id="progress-bar-container" class="progress" style="display: none;">
                                    <div class="progress-bar progress-bar-striped progress-bar-animated" id="progress-bar"
                                        role="progressbar" style="width: 0%;" aria-valuenow="0" aria-valuemin="0"
                                        aria-valuemax="100"></div>
                                </div>

                            </div>

                        </div>

                        <button type="submit" class="btn btn-primary float-lg-right " id="uploadBtn">Submit</button>

                    </form>
                </div>

            </div>
        </div>
    </div>





    

    <div class="modal fade" id="editTheme" tabindex="-1" role="dialog" saria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-md" role="document">

            <div class="modal-content ">

                <div class="modal-header d-flex justify-content-between">
                    <h5 class="modal-title text-dark" id="exampleModalLabel">Edit Theme</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>

                <div class="modal-body text-dark">

                    <input type="hidden" name="theme_id" id="theme_id">

                    <div id="update-message" class="text-danger fw-bold"></div>

                    <div class="row d-flex justify-content-center align-items-center">


                        <div class="form-group col-md-12">

                                <label class="control-label">Name</label>
                                <input type="text" name="update_name" id="update_name" class="form-control field-radius">

                            <br>
                            <div id="update-bar-container" class="progress" style="display: none;">
                                <div class="progress-bar progress-bar-striped progress-bar-animated update-bar" id="update-bar" role="progressbar" style="width: 0%;" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>

                        </div>
                    </div>

                    <button type="submit" class="btn btn-primary float-lg-right " id="updateBtn">Submit</button>

                </div>

            </div>
        </div>
    </div>



<?php $__env->stopSection(); ?>



<script src="https://canvasjs.com/assets/script/canvasjs.min.js"></script>

<script src="https://code.jquery.com/jquery-3.7.0.js"></script>

<script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js" defer></script>

<script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap4.min.js" defer></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.2/css/bootstrap.css">
<link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap4.min.css">




<script type="text/javascript">
    $(function() {
        setTimeout(function() {
            var table = $('.theme-listing').DataTable({
                processing: true,
                serverSide: true,
                ajax: {
                    url: "<?php echo e(url('admin/themes-list')); ?>",
                    data: function(d) {
                        d.from_date = $('#from_date').val();
                        d.to_date = $('#to_date').val();
                        console.log(d);
                    }
                },

                columns: [{
                        data: 'id',
                        name: 'id'
                    },
                    {
                        data: 'name',
                        name: 'name'
                    },
                    {
                        data: 'created',
                        name: 'created'
                    },
                    {
                        data: 'action',
                        name: 'action',
                        orderable: false,
                        searchable: false
                    },

                ],

                order: [
                    [0, 'desc']
                ],

            });

            $('#filter-form').on('submit', function(e) {
                e.preventDefault();
                $('.theme-listing').DataTable().ajax.reload();
            });

        }, 2000);
    });
</script>






<script>
    $(document).ready(function() {

        $('.add').click(function() {
            $('#addTheme').modal('show');
        });

        $('#addThemeForm').submit(function(e) {
            e.preventDefault();

            var name = $('#name').val();

            $('#sending-message').text('Processing request, please wait...');

            $.ajax({
                url: "<?php echo e(url('admin/add-theme')); ?>",
                type: "GET",

                data:{
                        'name': name
                    },
               
                success: function(response) {


                },
                error: function(xhr) {
                    // Handle error response
                    $('#sending-message').text(xhr);
                    console.log(xhr.responseText);
                },
                complete: function() {
                    $('#sending-message').text('');
                    $('#addTheme').modal('hide');
                    location.reload();
                }
            });

        });
    });
</script>






<script>
    $(document).ready(function() {

        $(document).on('click', '.status', function() {
            var themeId = $(this).val();

            $('#editTheme').modal('show');

            $.ajax({
                type: "GET",
                url: "/admin/edit-theme/" + themeId,
                success: function(response) {

                    $('#theme_id').val(themeId);

                    $('#update_name').val(response.theme.name);

                }
            });
        });
    });
</script>




<script>
    $(document).ready(function() {
        $('#updateBtn').on('click', function() {

            var themeId = $('#theme_id').val();

            var name = $('#update_name').val();

            console.log(themeId);

            $('#update-message').text('Processing request, please wait...');

            $.ajax({
                url: '/admin/update-theme',
                type: 'GET',
                data: {
                    'themeId': themeId,
                    'name': name
                },
                success: function(response) {},

                error: function(xhr) {

                    $('#update-message').text(xhr);
                },
                complete: function() {
                    $('#update-message').text('');
                    $('#editTheme').modal('hide');
                    location.reload();
                }
            });
            
        });
    });
</script>

<?php echo $__env->make('brackets/admin-ui::admin.layout.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\backend-zitransfer\src\resources\views/admin/theme/index.blade.php ENDPATH**/ ?>