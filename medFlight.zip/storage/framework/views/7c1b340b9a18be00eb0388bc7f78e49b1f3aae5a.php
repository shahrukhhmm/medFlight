

<?php $__env->startSection('title', trans('admin.admin-user.actions.index')); ?>

<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">


<style>
    .dataTables_wrapper .visitor-listing td {
        text-align: left;
        vertical-align: middle;
    }

    .table-listing td:last-of-type {
        justify-content: flex-start !important;
    }
</style>


<?php $__env->startSection('body'); ?>
    

    <div class="row">
        <div class="col">
            <div class="card">

                <div class="card-header">
                    <i class="fa fa-align-justify"></i> Visitors
                </div>


                <div class="card-body" v-cloak>

                    <div class="col-12 text-center">
                        <h1 style="text-transform: uppercase"><span id="filter-text"></span>&nbsp;&nbsp;&nbsp; Visitors</h1>
                    </div>

                    <div class="container">
                            <form id="filter-form" class="filter-form-container row">
                                
                                <div class="col-sm-12 col-md-6 col-lg-5">
                                    <label for="from_date" class="h6">From:</label>
                                    <input type="date" id="from_date" class="form-control">
                                </div>
                                <div class="col-sm-12 col-md-6 col-lg-5">
                                    <label for="to_date" class="h6">To:</label>
                                    <input type="date" id="to_date" class="form-control">
                                </div>
                                <div style="margin-top: 30px" class="col-sm-12 col-md-6 col-lg-2 applyBtn">
                                    <button type="submit" class="btn btn-sm btn-success">Apply Filter</button>
                                </div>
                            </form>
                        </div>

    
                    </div>

                    <div class= "container">    
                        <table class="table table-hover visitor-listing table-listing">
                            <thead>
                                <tr>                
                                    <th>ID</th>
                                    <th>Ip address</th>
                                    <th>Country Name</th>
                                    <th>City Name</th>
                                    <th>Zip Code</th>
                                    <th>Device</th>
                                    <th>Platform</th>
                                    <th>System</th>
                                    <th>Latlng</th>
                                    <th>Created at</th>
                                    <th>Action</th>
                            
                                </tr>
                            </thead>

                            <tbody>    
                                
                            
                            </tbody>
                        </table>
                    </div>


                </div>

            </div>        
        </div>

    </div>


<?php $__env->stopSection(); ?>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.js"></script>

<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>

<script src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js" defer></script>

<link rel="stylesheet" href="https://cdn.datatables.net/1.10.16/css/jquery.dataTables.min.css">



<script type="text/javascript">

    var filter = <?php echo json_encode($filter); ?>;
    console.log(filter);
    var url = "/admin/visitor-interval-list/"+filter;

    $(function () {
        setTimeout(function () {
            var csrfToken = $('meta[name="csrf-token"]').attr('content');

            var table = $('.visitor-listing').DataTable({
                processing: true,
                serverSide: true,
                ajax: {
                    url :"/admin/visitor-interval-list/"+filter,
                    headers: {
                        'X-CSRF-TOKEN': csrfToken
                        },
                    data: function (d) {
                    d.from_date = $('#from_date').val();
                    d.to_date = $('#to_date').val();
                    }
                },

                columns: [
                    {data: 'id', name: 'id'},
                    {data: 'ip_address', name: 'ip_address'},
                    {data: 'countryName', name: 'countryName'},
                    {data: 'cityName', name: 'cityName'},
                    {data: 'zipCode', name: 'zipCode'},
                    {data: 'device', name: 'device'},
                    {data: 'platform', name: 'platform'},
                    {data: 'system', name: 'system'},
                    {
                        data: 'map', 
                        name: 'map', 
                        orderable: false, 
                        searchable: false
                    },
                    {
                        data: 'created', name: 'created'},
                    {
                        data: 'action', 
                        name: 'action', 
                        orderable: false, 
                        searchable: false
                    },
                ]
            });
            
            $('#filter-form').on('submit', function (e) {
                e.preventDefault();
                $('.visitor-listing').DataTable().ajax.reload();
            });
        }, 2000); 

        filterText(filter);

    });


    function filterText(filter){
        if(filter == 'today'){
            $("#filter-text").text("Daily")
        }
        
        if(filter == 'week'){
            $("#filter-text").text("Weekly")
        }        
        
        if(filter == 'month'){
            $("#filter-text").text("Monthly")
        }

        if(filter == 'year'){
            $("#filter-text").text("Yearly")
        }
    }
</script>








<?php echo $__env->make('brackets/admin-ui::admin.layout.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\backend-zitransfer\src\resources\views/admin/visitors/visitor-interval-details.blade.php ENDPATH**/ ?>