


<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('favicon'); ?>
    <link rel="icon" href="<?php echo e(public_path('images/ZTFR.png')); ?>" type="image/x-icon">
<?php $__env->stopSection(); ?>



<?php echo $__env->make('admin.components.styles', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



<?php $__env->startSection('body'); ?>
    
    <?php echo $__env->make('admin.components.background-image', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <div class="row">


        <div class="col-md-3 col-12 p-3 mt-2">
            <div class="small-box" style="background: #ff3b2c94;">
                <div class="inner">
                    <h3><i class="fas fa-users mr-3 mb-3"></i><?php echo e(@$totalVisitor); ?></h3>
                    <h5>Total Visitors</h5>
                </div>
              
                <a href="<?php echo e(url('admin/visitors-all')); ?>" class="small-box-footer">More info <i
                        class="fas fa-arrow-circle-right"></i></a>
            </div>
        </div>
        <div class="col-md-3 col-12 p-3 mt-2">
            <div class="small-box"   style="background: #00ffff78;">
                <div class="inner">
                    <h3><i class="fas fa-globe mr-3 mb-3"></i><?php echo e(@$humanReadableSizeOfBucket); ?></h3>
                    <h5>Orbit Size</h5>
                    <a href="" class="small-box-footer">&nbsp;</a>
                </div>

            </div>
        </div>
        <div class="col-md-3 col-12 p-3 mt-2">
            <div class="small-box"  style="background: #0c0c0c8f;">
                <div class="inner">
                    <h3><i class="fas fa-file mr-3 mb-3"></i><?php echo e(@$numberOfObjects); ?></h3>
                    <h5>Total Files</h5>
                    <a href="" class="small-box-footer">&nbsp;</a>
                </div>

            </div>
        </div>
        <div class="col-md-3 col-12 p-3 mt-2">
            <div class="small-box"  style="background: #00968875;">
                <div class="inner">
                    <h3><i class="fas fa-user mr-3 mb-3"></i><?php echo e(@$totalUser); ?></h3>
                    <h5>Total Users</h5>
                </div>
             
                <a href="<?php echo e(url('admin/users-all')); ?>" class="small-box-footer">More info <i
                        class="fas fa-arrow-circle-right"></i></a>
            </div>
        </div>


        
        <div class="col-md-12 col-12 mt-5" style="width: 80%; margin: auto;">
            <h1 class="text-center">Visitor Daily Graph</h1>
            <canvas id="visitorChart"></canvas>
        </div>

        
        <div class="col-md-12 col-12 mt-5" style="width: 80%; margin: auto;">
            <h1 class="text-center">User Daily Graph</h1>
            <canvas id="userChart"></canvas>
        </div>

        
        <div class="col-md-6 col-12 mt-5" style="width: 80%; margin: auto;">
            <h1 class="text-center">File Daily Graph</h1>
            <canvas id="fileChart"></canvas>
        </div>

          
        <div class="col-md-6 col-sm-8 col-10" style="width: 80%; margin: auto;">
            <h1 class="text-center mt-5">File Type Graph</h1>
            <canvas id="fileTypeChart"></canvas>
        </div>


        

    
    </div>


    
    <div class="row mt-4">
        <div class="col">
            <div class="card" style="overflow:auto; width:100% !important;">
                <div class="card-header">
                    <div  class="col-md-12" style="background:white;  display: flex;  flex-wrap: wrap; flex-direction: row; justify-content: space-between;">
                        
                        <p style="margin-top: 14px;"><i class="fa fa-user"></i> Today User Login</p>

                    </div>
                     
                </div>

               
                <div class="card-body" v-cloak>

                    <div class="table-responsive">
                        <table class="table table-hover user-listing table-listing table-hover " style=" width:100%;">
                            <thead>
                                <tr>

                                    <th>ID</th>
                                    <th>Visitor Id</th>
                                    <th>Name</th>
                                    <th>Email</th>
                                    <th>Type</th>
                                    <th>Status</th>
                                    <th>Today File Upload </th>
                                    <th>Created at</th>
                                    <th>Action</th>

                                </tr>
                            </thead>
                            <tbody>


                            </tbody>
                        </table>
                    </div>
                </div>

            </div>
        </div>
    </div>

    
    <div class="row mt-4">
        <div class="col">
            <div class="card-body" v-cloak>

                <div class="card-header">
                    <div  class="col-md-12" style="background:white;  display: flex;  flex-wrap: wrap; flex-direction: row; justify-content: space-between;">
                        
                        <p style="margin-top: 14px;"><i class="fa fa-user"></i> Today File upload</p>

                    </div>
                     
                </div>
                <div class="card-body" v-cloak>

                    <div class="table-responsive">
                        <table class="table table-hover file-listing table-listing table-hover " style=" width:100%;">
                    
                            <thead>
                                <tr>

                                    <th>ID</th>
                                    <th>VisitorId</th>
                                    <th>Title</th>
                                    <th>Link</th>
                                    <th>File count</th>
                                    <th>Size</th>
                                    <th>Created at</th>
                                    <th>Action</th>

                                </tr>
                            </thead>
                            <tbody>

                            </tbody>
                        </table>

                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>


<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.29.1/moment.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<script src="https://code.jquery.com/jquery-3.7.0.js"></script>

<script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js" defer></script>

<script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap4.min.js" defer></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.2/css/bootstrap.css">
<link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap4.min.css">


<script>
    $(document).ready(function() {
        var ctx = document.getElementById('visitorChart').getContext('2d');

        var dates = <?php echo json_encode($visitorData->pluck('date')); ?>;
        var counts = <?php echo json_encode($visitorData->pluck('count')); ?>;

        var visitorChart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: dates,
                datasets: [{
                    label: 'Visitors',
                    data: counts,
                    backgroundColor: 'blue',
                    borderWidth: 1,
                }]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true,
                    }
                },
                plugins: {
                    legend: {
                        display: false
                    },
                    tooltip: {
                        callbacks: {
                            title: function(context) {
                                return moment(context[0].label).format('MMM DD, YYYY');
                            }
                        }
                    }
                }
            }
        });


        // user graph

        var utx = document.getElementById('userChart').getContext('2d');

        var date = <?php echo json_encode($userData->pluck('date')); ?>;
        var count = <?php echo json_encode($userData->pluck('count')); ?>;

        var userChart = new Chart(utx, {
            type: 'line',
            data: {
                labels: date,
                datasets: [{
                    label: 'Users',
                    data: count,
                    backgroundColor: 'blue',
                    borderWidth: 1,
                    

                }]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true,
                        
                    }
                },
                plugins: {
                    legend: {
                        display: false
                    },
                    tooltip: {
                        callbacks: {
                            title: function(context) {
                                return moment(context[0].label).format('MMM DD, YYYY');
                            }
                        }
                    }
                }
            }
        });

        // file graph

        var ftx = document.getElementById('fileChart').getContext('2d');

        var date = <?php echo json_encode($fileData->pluck('date')); ?>;
        var count = <?php echo json_encode($fileData->pluck('count')); ?>;

        var userChart = new Chart(ftx, {
            type: 'line',
            data: {
                labels: date,
                datasets: [{
                    label: 'File',
                    data: count,
                    backgroundColor: 'blue',
                    borderWidth: 1,

                }]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true,
                    }
                },
                plugins: {
                    legend: {
                        display: false
                    },
                    tooltip: {
                        callbacks: {
                            title: function(context) {
                                return moment(context[0].label).format('MMM DD, YYYY');
                            }
                        }
                    }
                }
            }
        });


        // file graph

        var typeChart = $('#fileTypeChart');
        var typeFile = <?php echo json_encode($fileType->pluck('type')); ?>;
        var counts = <?php echo json_encode($fileType->pluck('count')); ?>;

        var colors = [
            'lightsteelblue',
            'lightskyblue',
            'lightcoral',
            'lightblue',
            'lightpink',
            'lightseagreen',
            'lightgreen',
            'lightsalmon',
        ];

        // Create a pie chart for counts
        var pieChart = new Chart(typeChart, {
            type: 'pie',
            data: {
                labels: typeFile,
                datasets: [{
                    label: 'Counts',
                    data: counts,
                    backgroundColor: colors,
                    border: 1
                }, ],
            },
            options: {
                plugins: {
                    legend: {
                        display: true,
                        position: 'right',
                    },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                var type = typeFile[context.dataIndex];
                                var count = counts[context.dataIndex];
                                return type + ': ' + count;
                            },
                        },
                    },
                },
            },
        });

    });





</script>



 
<script type="text/javascript">
    $(function() {
        setTimeout(function() {
            var table = $('.user-listing').DataTable({
                processing: true,
                serverSide: true,
                ajax: {
                    url: "<?php echo e(url('admin/login-users-list')); ?>"
                },

                columns: [{
                        data: 'id',
                        name: 'id'
                    },
                    {
                        data: 'visitor_detail',
                        name: 'visitor_detail'
                    },
                    {
                        data: 'display_name',
                        name: 'display_name'
                    },
                    {
                        data: 'email',
                        name: 'email'
                    },
                    {
                        data: 'type',
                        name: 'type'
                    },
                    {
                        data: 'status',
                        name: 'status'
                    },                
                    {
                        data: 'fileUpload',
                        name: 'fileUpload'
                    },
                    {
                        data: 'created',
                        name: 'created'
                    },
                    {
                        data: 'action',
                        name: 'action',
                        orderable: false,
                        searchable: false
                    },
                ],
                order: [[0, 'desc']],
            });
        }, 2000);
    });


    
</script>







<script type="text/javascript">
    $(function() {
        setTimeout(function() {
            var table = $('.file-listing').DataTable({
                processing: true,
                serverSide: true,
                ajax: {
                    url: "<?php echo e(url('/admin/today-file-upload')); ?>",
             

                },

                columns: [{
                        data: 'id',
                        name: 'id'
                    },
                    {
                        data: 'visitor_detail',
                        name: 'visitor_detail'
                    },
                    {
                        data: 'title',
                        name: 'title'
                    },
                    {
                        data: 'link',
                        name: 'link'
                    },
                    {
                        data: 'file_count',
                        name: 'file_count'
                    },
                    {
                        data: 'total_size',
                        name: 'total_size'
                    },
                    {
                        data: 'created',
                        name: 'created'
                    },
                    {
                        data: 'action',
                        name: 'action',
                        orderable: false,
                        searchable: false
                    },
                ],
                order: [[0, 'desc']],
            });

        }, 2000);
    });
</script>

<?php echo $__env->make('brackets/admin-ui::admin.layout.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\backend-zitransfer\src\resources\views/admin/dashboard/index.blade.php ENDPATH**/ ?>