

<?php $__env->startSection('title', trans('admin.admin-user.actions.index')); ?>


<style>
    .dataTables_wrapper .bg-image-listing th {
        text-align: middle;
        vertical-align: middle !important;
    }

    .dataTables_wrapper .bg-image-listing td {
        text-align: middle;
        vertical-align: middle !important;
    }

    .table-listing td:last-of-type {
        display: revert !important;
    }

    .modal-footer {
        border-top: none !important;
    }
</style>

<?php $__env->startSection('body'); ?>



    <div class="row">
        <div class="col">
            <div class="card">

                <div class="card-header">
                    <i class="fa fa-align-justify"></i> Background Home Image
                    <a class="btn btn-primary btn-sm pull-right m-b-0 add" href="#" data-toggle="modal"
                        data-target="#addBgImage" role="button"><i class="fa fa-plus"></i>&nbsp; New</a>

                </div>

                <div class="card-body" v-cloak>

                    <?php if(session()->has('message')): ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <strong>Success</strong> &nbsp; <?php echo e(session()->get('message')); ?>

                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                    <?php endif; ?>

                    <div class="container">
                        <form id="filter-form" class="filter-form-container row">
                            <div class="col-sm-12 col-md-6 col-lg-5">
                                <label for="from_date" class="h6">From:</label>
                                <input type="date" id="from_date" class="form-control">
                            </div>
                            <div class="col-sm-12 col-md-6 col-lg-5">
                                <label for="to_date" class="h6">To:</label>
                                <input type="date" id="to_date" class="form-control">
                            </div>
                            <div style="margin-top: 30px;" class="col-sm-12 col-md-6 col-lg-2 applyBtn">
                                <button type="submit" class="btn btn-sm btn-success">Apply Filter</button>
                            </div>
                        </form>
                    </div>


                    <table class="datatables-basic table bg-image-listing table-listing" style="overflow:scroll">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Image</th>
                                <th>Default</th>
                                <th>Created at</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                    </table>

                </div>
            </div>
        </div>
    </div>



    


    <div class="modal fade" id="addBgImage" tabindex="-1" role="dialog" saria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog modal-md" role="document">

            <div class="modal-content ">

                <div class="modal-header d-flex justify-content-between">
                    <h5 class="modal-title text-dark" id="exampleModalLabel">Add Background Home Image</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>

                <div class="modal-body text-dark">
                    <form id="addBgImageForm" enctype="multipart/form-data">

                        <input type="hidden" name="url_image" id="url_image">

                        <div id="sending-message" class="text-danger fw-bold"></div>


                        <div class="row d-flex justify-content-center align-items-center">

                            <div class="form-group col-md-12">

                                <div class="form-group" id="docGroup" style="margin-top: 15px;">
                                    <label for="add_image" class="form-label">Set Default:</label>
                                    <select name="default" id="add_default" class="form-control">
                                        <option value="0">false</option>
                                        <option value="1">true</option>
                                    </select>
                                </div>

                                <div class="form-group" id="docGroup" style="margin-top: 15px;">
                                    <label for="add_image" class="form-label">Upload Image:</label>
                                    <input type="file" class="form-control" id="upload_image" name="upload_image"
                                        aria-label="upload_image" required>
                                    <div class="invalid-feedback">
                                        Please select a file.
                                    </div>
                                </div>

                                <br>
                                <div id="progress-bar-container" class="progress" style="display: none;">
                                    <div class="progress-bar progress-bar-striped progress-bar-animated" id="progress-bar"
                                        role="progressbar" style="width: 0%;" aria-valuenow="0" aria-valuemin="0"
                                        aria-valuemax="100"></div>
                                </div>

                            </div>

                        </div>

                        <button type="submit" class="btn btn-primary float-lg-right " id="uploadImageBtn">Submit</button>

                    </form>
                </div>

            </div>
        </div>
    </div>





    
    <div class="modal fade" id="editBgImage" tabindex="-1" role="dialog" saria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog modal-md" role="document">

            <div class="modal-content ">

                <div class="modal-header d-flex justify-content-between">
                    <h5 class="modal-title text-dark" id="exampleModalLabel">Edit Background Home Image</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>

                <div class="modal-body text-dark">

                    <input type="hidden" name="bg-home-id" id="bg-home-id">
                    <input type="hidden" name="image_url" id="image_url">

                    <div id="update-message" class="text-danger fw-bold"></div>

                    <div class="row d-flex justify-content-center align-items-center">


                        <div class="form-group col-md-12">

                            <div class="form-group" id="docGroup" style="margin-top: 15px;">
                                <label for="" class="form-label">Set Default:</label>
                                <select name="default" id="default" class="form-control">
                                    <option value="0">false</option>
                                    <option value="1">true</option>
                                </select>
                            </div>


                            <div class="form-group" style="margin-top: 15px;">
                                <label for="image_upload" class="form-label">Upload Image:</label>
                                <input type="file" class="form-control" id="image_upload" name="image_upload"
                                    aria-label="image_upload">
                                <div class="invalid-feedback">
                                    Please select a file.
                                </div>
                            </div>

                            <br>
                            <div id="update-bar-container" class="progress" style="display: none;">
                                <div class="progress-bar progress-bar-striped progress-bar-animated update-bar"
                                    id="update-bar" role="progressbar" style="width: 0%;" aria-valuenow="0"
                                    aria-valuemin="0" aria-valuemax="100"></div>
                            </div>

                        </div>
                    </div>

                    <button type="submit" class="btn btn-primary float-lg-right " id="updateBgImageBtn">Submit</button>

                </div>

            </div>
        </div>
    </div>



<?php $__env->stopSection(); ?>



<script src="https://canvasjs.com/assets/script/canvasjs.min.js"></script>


<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.js"></script>

<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>

<script src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js" defer></script>

<link rel="stylesheet" href="https://cdn.datatables.net/1.10.16/css/jquery.dataTables.min.css">


<script src="https://www.gstatic.com/firebasejs/8.10.0/firebase-app.js"></script>
<script src="https://www.gstatic.com/firebasejs/8.10.0/firebase-storage.js"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>



<script type="text/javascript">
    $(function() {
        setTimeout(function() {
            var table = $('.bg-image-listing').DataTable({
                processing: true,
                serverSide: true,
                ajax: {
                    url: "<?php echo e(url('admin/bg-home-images-list')); ?>",
                    data: function(d) {
                        d.from_date = $('#from_date').val();
                        d.to_date = $('#to_date').val();
                        console.log(d);
                    }
                },

                columns: [{
                        data: 'id',
                        name: 'id'
                    },
                    {
                        data: 'image',
                        name: 'image'
                    },
                    {
                        data: 'default',
                        name: 'default'
                    },
                    {
                        data: 'created',
                        name: 'created'
                    },
                    {
                        data: 'action',
                        name: 'action',
                        orderable: false,
                        searchable: false
                    },

                ],

                order: [
                    [0, 'desc']
                ],

            });

            $('#filter-form').on('submit', function(e) {
                e.preventDefault();
                $('.bg-image-listing').DataTable().ajax.reload();
            });

        }, 2000);
    });
</script>





<script>
    //  upload image on firebase
    function uploadImage(callback) {

        var uploadImage = document.getElementById("upload_image").files[0];
        var progressBarContainer = document.getElementById("progress-bar-container");
        var progressBar = progressBarContainer.querySelector('.progress-bar');


        var imageName = uploadImage.name;
        var fileExtension = imageName.split('.').pop();
        console.log(imageName);


        if (!firebase.apps.length) {
            var firebaseConfig = {
                // Firebase configuration here
                apiKey: "AIzaSyBTRtct-hu1DgnG61cvpoXmwZm2lfXp6QU",
                authDomain: "ztfr-ff6ab.firebaseapp.com",
                projectId: "ztfr-ff6ab",
                storageBucket: "ztfr-ff6ab.appspot.com",
                messagingSenderId: "1080163201988",
                appId: "1:1080163201988:web:e99c813fdbbea5572e6a91",
                measurementId: "G-R6FNCSNE9R",


            };

            firebase.initializeApp(firebaseConfig);
        }

        // Get a reference to the storage service
        var storage = firebase.storage();

        var storageRef = firebase.storage().ref('/country/homepageimages/' + imageName);

        var uploadTask = storageRef.put(uploadImage);

        uploadTask.on('state_changed', function(snapshot) {
            var progress = (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
            progressBar.style.width = progress + '%';
            progressBar.setAttribute('aria-valuenow', progress);
            progressBar.innerText = progress.toFixed(2) + '%'; // Update the progress text


        }, function(error) {
            console.log(error.message);
        }, function() {
            uploadTask.snapshot.ref.getDownloadURL().then(function(downloadURL) {
                progressBarContainer.style.display = 'none';
                var url = downloadURL;
                callback(url);
                console.log(url);
            });
        });
        progressBarContainer.style.display = 'block';
    }

    //  update image on firebase

    function updateImage(callback) {

        var imageUpload = document.getElementById("image_upload").files[0];
        var updateBarContainer = document.getElementById("update-bar-container");
        var updateBar = updateBarContainer.querySelector('.update-bar');



        var defaultURL = $('#image_url').val();

        if (!imageUpload) {
            // Handle the case when no image is selected
            console.log("No image selected");
            callback(defaultURL);
        } else {

            console.log(imageUpload);

            var imageName = imageUpload.name;
            var fileExtension = imageName.split('.').pop();

            if (!firebase.apps.length) {
                var firebaseConfig = {
                    // Firebase configuration here
                    apiKey: "AIzaSyBTRtct-hu1DgnG61cvpoXmwZm2lfXp6QU",
                    authDomain: "ztfr-ff6ab.firebaseapp.com",
                    projectId: "ztfr-ff6ab",
                    storageBucket: "ztfr-ff6ab.appspot.com",
                    messagingSenderId: "1080163201988",
                    appId: "1:1080163201988:web:e99c813fdbbea5572e6a91",
                    measurementId: "G-R6FNCSNE9R",

                };

                firebase.initializeApp(firebaseConfig);
            }

            // Get a reference to the storage service
            var storage = firebase.storage();

            var storageRef = firebase.storage().ref('/country/homepageimages/' + imageName);

            var uploadTask = storageRef.put(imageUpload);

            uploadTask.on('state_changed', function(snapshot) {

                    var progress = (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
                    updateBar.style.width = progress + '%';
                    updateBar.setAttribute('aria-valuenow', progress);
                    updateBar.innerText = progress.toFixed(2) + '%'; // Update the progress text


                },
                function(error) {
                    console.log(error.message);
                },
                function() {
                    uploadTask.snapshot.ref.getDownloadURL().then(function(downloadURL) {
                        updateBarContainer.style.display = 'none';
                        var url = downloadURL;
                        callback(url);
                        console.log(url);
                    });
                });
            updateBarContainer.style.display = 'block';

        }
    }
</script>





<script>
    $(document).ready(function() {

        $('.add').click(function() {
            $('#addBgImage').modal('show');
        });

        $('#addBgImageForm').submit(function(e) {
            e.preventDefault();


            var form = $(this);
            var formData = new FormData(form[0]);

            uploadImage(function(url) {

                var csrfToken = document.querySelector('meta[name="csrf-token"]').getAttribute(
                    'content');

                var url = formData.append('url_image', url);

                console.log(url);

                $('#sending-message').text('Processing request, please wait...');

                $.ajax({
                    url: "<?php echo e(url('admin/add-bg-home-image')); ?>",
                    type: "POST",
                    headers: {
                        'X-CSRF-TOKEN': csrfToken
                    },
                    data: formData,
                    contentType: false,
                    processData: false,
                    success: function(response) {


                    },
                    error: function(xhr) {
                        // Handle error response
                        $('#sending-message').text(xhr);
                        console.log(xhr.responseText);
                    },
                    complete: function() {
                        $('#sending-message').text('');
                        $('#addBgImage').modal('hide');
                        location.reload();
                    }
                });

            });

        });
    });
</script>






<script>
    $(document).ready(function() {

        $(document).on('click', '.status', function() {
            var bgImageId = $(this).val();

            console.log(bgImageId);


            $('#editBgImage').modal('show');

            $.ajax({
                type: "GET",
                url: "/admin/edit-bg-home-image/" + bgImageId,
                success: function(response) {
                    console.log(response);
                    $('#bg-home-id').val(bgImageId);

                    $('#default').val(response.bgImage.default);
                    $('#image_url').val(response.bgImage.image_url);

                }
            });
        });
    });
</script>




<script>
    $(document).ready(function() {
        $('#updateBgImageBtn').on('click', function() {

            var bgImageId = $('#bg-home-id').val();

            var image_url = $('#image_url').val();

            console.log(bgImageId);


            updateImage(function(url) {


                $('#update-message').text('Processing request, please wait...');

                $.ajax({
                    url: '/admin/update-bg-home-image',
                    type: 'GET',
                    data: {
                        'bgImageId': bgImageId,

                        'image_url': url
                    },
                    success: function(response) {},
                    error: function(xhr) {

                        $('#update-message').text(xhr);
                    },
                    complete: function() {
                        $('#update-message').text('');
                        $('#editBgImage').modal('hide');
                        location.reload();
                    }
                });
            });
        });
    });
</script>

<?php echo $__env->make('brackets/admin-ui::admin.layout.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\backend-zitransfer\src\resources\views/admin/bg-home-image/index.blade.php ENDPATH**/ ?>