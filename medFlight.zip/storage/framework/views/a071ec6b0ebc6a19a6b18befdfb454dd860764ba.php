

<?php $__env->startSection('title', trans('admin.admin-user.actions.index')); ?>

<style>
    ::-webkit-scrollbar {
        width: 1px;
    }

    ::-webkit-scrollbar-track {
        border-radius: 5px;
        -webkit-box-shadow: inset 0 0 1px rgba(0, 0, 0, 0.3);
    }

    ::-webkit-scrollbar-thumb {
        border-radius: 5px;
        background-color: #000000;
        outline: 1px solid slategrey;
    }

    ::-webkit-scrollbar:vertical {
        display: none;
    }

    h5 {
        font-weight: bold;
        font-size: 20px;
    }
</style>

<?php $__env->startSection('body'); ?>

    <div class="row">
        <div class="col">
            <div class="card">

                <div class="card-body" v-cloak>

                    <div class="container">
                        <h1 class="text-center" id="lid">#ZM<?php echo e(@$data->id); ?></h1>

                        <div class="card card-solid">
                            <div class="card-body">
                                <div class="container py-5" style=" margin-top: 35px; background-color: #f9f9f9;">


                                    <div class="row">
                                        <div class="col-12 ">
                                            <h1 class=" text-center display-5"
                                                style="text-shadow:1px 1px 3px black; margin-top: -23px; margin-bottom: 22px;">
                                                File
                                                DETAIL</h1>
                                        </div>
                                    </div>

                                    <div class="row">

                                        <div class="col-lg-6 col-sm-12">
                                            <div class="card mb-4">
                                                <div class="card-body">
                                                    <div class="row">
                                                        <div class="col-sm-3">
                                                            <p class="mb-0 font-weight-bold fontColor">Visitor Id</p>
                                                        </div>
                                                        <div class="col-sm-9">
                                                            <p class="text-muted mb-0"> <a
                                                                    href="<?php echo e(url('admin/visitor-detail/' . @$data->visitor->id)); ?>"><?php echo e(@$data->visitor_id); ?></a>
                                                            </p>
                                                        </div>
                                                    </div>
                                                    <hr>

                                                    <div class="row">
                                                        <div class="col-sm-3">
                                                            <p class="mb-0 font-weight-bold fontColor">UserName</p>
                                                        </div>
                                                        <div class="col-sm-9">
                                                            <p class="text-muted mb-0"><?php echo e(@$data->user->display_name); ?></p>
                                                        </div>
                                                    </div>
                                                    <hr>

                                                    <div class="row">
                                                        <div class="col-sm-3">
                                                            <p class="mb-0 font-weight-bold fontColor">Title</p>
                                                        </div>
                                                        <div class="col-sm-9">
                                                            <p class="text-muted mb-0"><?php echo e(@$data->title); ?></p>
                                                        </div>
                                                    </div>
                                                    <hr>
                                                    <div class="row">
                                                        <div class="col-sm-3">
                                                            <p class="mb-0 font-weight-bold fontColor">Country</p>
                                                        </div>
                                                        <div class="col-sm-9">
                                                            <p class="text-muted mb-0">
                                                                <?php echo e(@$data->visitor->countryName); ?>

                                                            </p>
                                                        </div>
                                                    </div>


                                                    <hr>
                                                    <div class="row">
                                                        <div class="col-sm-3">
                                                            <p class="mb-0 font-weight-bold fontColor">Note</p>
                                                        </div>
                                                        <div class="col-sm-9">
                                                            <p class="text-muted mb-0">
                                                                <?php echo e(@$data->note); ?>

                                                            </p>
                                                        </div>
                                                    </div>

                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-lg-6 col-sm-12">
                                            <div class="card mb-4">
                                                <div class="card-body">



                                                    <div class="row">
                                                        <div class="col-sm-3">
                                                            <p class="mb-0 font-weight-bold fontColor">Expiry date</p>
                                                        </div>
                                                        <div class="col-sm-9">
                                                            <p class="text-muted mb-0"><?php echo e(@$data->expiry_date); ?></p>
                                                        </div>
                                                    </div>
                                                    <hr>

                                                    <div class="row">
                                                        <div class="col-sm-3">
                                                            <p class="mb-0 font-weight-bold fontColor">Link
                                                            </p>
                                                        </div>
                                                        <div class="col-sm-9">
                                                            <p class="text-muted mb-0"><?php echo e(@$data->link); ?></p>
                                                        </div>
                                                    </div>
                                                    <hr>
                                                    <div class="row">
                                                        <div class="col-sm-3">
                                                            <p class="mb-0 font-weight-bold fontColor">Link type
                                                            </p>
                                                        </div>
                                                        <div class="col-sm-9">
                                                            <p class="text-muted mb-0"><?php echo e(@$data->link_type); ?>

                                                            </p>
                                                        </div>
                                                    </div>
                                                    <hr>
                                                    <div class="row">
                                                        <div class="col-sm-3">
                                                            <p class="mb-0 font-weight-bold fontColor">File count
                                                            </p>
                                                        </div>
                                                        <div class="col-sm-9">
                                                            <p class="text-muted mb-0"><?php echo e(@$data->file_count); ?>

                                                            </p>
                                                        </div>
                                                    </div>
                                                    <hr>
                                                    <div class="row">
                                                        <div class="col-sm-3">
                                                            <p class="mb-0 font-weight-bold fontColor">Total size
                                                            </p>
                                                        </div>
                                                        <div class="col-sm-9">
                                                            <p class="text-muted mb-0"><?php echo e(@$data->total_size); ?>

                                                            </p>
                                                        </div>
                                                    </div>
                                                    <hr>
                                                    <div class="row">
                                                        <div class="col-sm-3">
                                                            <p class="mb-0 font-weight-bold fontColor">Created at
                                                            </p>
                                                        </div>
                                                        <div class="col-sm-9">
                                                            <p class="text-muted mb-0"><?php echo e(@$data->created_at); ?>

                                                            </p>
                                                        </div>
                                                    </div>

                                                </div>
                                            </div>

                                        </div>

                                    </div>

                                    
                                    <div class="row">

                                        <div class="col-lg-12 col-sm-12" style="overflow: scroll;width:100%">
                                            <div class="card mb-4">
                                                <div class="card-body" style="overflow-x: scroll !important;width:100%;">
                                                    <h3 style="text-transform: uppercase">File data Links</h3>
                                                    <table class="table">
                                                        <thead>
                                                            <tr>
                                                                <th scope="col">File size</th>
                                                                <th scope="col">File link</th>
                                                                <th scope="col">Type</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>

                                                            <?php $__currentLoopData = @$data->file_detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <tr>
                                                                    <td><?php echo e(@$detail->file_size); ?> <?php echo e(@$detail->unit); ?>

                                                                    </td>
                                                                    <td><?php echo e(@$detail->file_link); ?></td>
                                                                    <td><?php echo e(@$detail->type); ?></td>

                                                                </tr>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                        </tbody>
                                                    </table>

                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                    

                                    <div class="row">

                                        <div class="col-lg-12 col-sm-12" style="width:100%">
                                            <div class="card mb-4" style="width:100%">
                                                <div class="card-body" style="overflow-x: scroll !important;width:100%;">
                                                    <h3 style="text-transform: uppercase">Shared with</h3>
                                                    <table class="table">
                                                        <thead>
                                                            <tr>
                                                                <th scope="col">Platform</th>
                                                                <th scope="col"> From</th>
                                                                <th scope="col">To</th>
                                                                <th scope="col">ScheduleDate</th>
                                                                <th scope="col">AssigneeName</th>
                                                                <th scope="col">SendDate</th>
                                                                <th scope="col">Note</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>

                                                            <?php $__currentLoopData = @$data->shared; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <tr>
                                                                    <td><?php echo e(@$detail->platform); ?></td>
                                                                    <td><?php echo e(@$detail->form_user); ?></td>
                                                                    <td><?php echo e(@$detail->to_user); ?></td>
                                                                    <td><?php echo e(@$detail->schedule_date); ?></td>
                                                                    <td><?php echo e(@$detail->assignee_name); ?></td>
                                                                    <td><?php echo e(@$detail->created_at); ?></td>
                                                                    <td><?php echo e(@$detail->note); ?></td>

                                                                </tr>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                        </tbody>
                                                    </table>

                                                </div>
                                            </div>
                                        </div>

                                    </div>

                                    

                                    <div class="row">

                                        <div class="col-lg-12 col-sm-12" style="width:100%">
                                            <div class="card mb-4" style="width:100%">
                                                <div class="card-body" style="overflow-x: scroll !important;width:100%;">
                                                    <h3 style="text-transform: uppercase">Download detail</h3>
                                                    <table class="table">
                                                        <thead>
                                                            <tr>
                                                                <th scope="col">Sender</th>
                                                                <th scope="col"> Receiver</th>
                                                                <th scope="col">Date</th>
                                                                <th scope="col">Time</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>

                                                            <?php $__currentLoopData = @$data->downloaded; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <tr>
                                                                    <td>
                                                                        <a
                                                                            href="<?php echo e(url('admin/visitor-detail/' . @$detail->sender_visitor_id)); ?>"><?php echo e(@$detail->sender_visitor_id); ?></a>
                                                                    </td>
                                                                    <td>
                                                                        <a
                                                                            href="<?php echo e(url('admin/visitor-detail/' . @$detail->receiver_visitor_id)); ?>"><?php echo e(@$detail->receiver_visitor_id); ?></a>
                                                                    </td>
                                                                    <td><?php echo e(@$detail->date); ?></td>
                                                                    <td><?php echo e(@$detail->time); ?></td>

                                                                </tr>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                        </tbody>
                                                    </table>

                                                </div>
                                            </div>
                                        </div>

                                    </div>



                                </div>
                            </div>

                        </div>

                    </div>

                </div>

            </div>

        </div>


    <?php $__env->stopSection(); ?>


    <script src="https://canvasjs.com/assets/script/canvasjs.min.js"></script>


    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.js"></script>

    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js" defer></script>

<?php echo $__env->make('brackets/admin-ui::admin.layout.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\backend-zitransfer\src\resources\views/admin/file/file-detail.blade.php ENDPATH**/ ?>