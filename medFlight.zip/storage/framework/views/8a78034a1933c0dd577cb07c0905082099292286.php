<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>ZiTransfer</title>

        <style>
            *{
                font-family:'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;
                margin: 0;padding: 0;box-sizing: border-box;
                font-weight: 400;
            }

            body{
                background-color: white;
                letter-spacing: 3px;
            }

            #main{
                background-color: white;
                max-width: 592px;
                margin: auto;
                border-left: 2px solid #e1e1e1;
                border-right: 2px solid #e1e1e1;
                padding: 10px;
            }

            a{
                text-decoration: none;
                color: black !important;
            }

            .card{
                padding-right: 40px;
                padding-left: 40px;
                padding-top: 10px;
                padding-bottom: 10px;
            }

            .logo{
                width: 190px;
                height: 46px;
                padding: 8px;
            }

            .text{
                font-size: 12px;
                letter-spacing: 1px;
                text-align: center;
            }
            
            .head-text{
                letter-spacing: 2.4px;
                font-size: 15px;
                text-align: center;
            }

            .body-text{
                font-size: 12px;
                letter-spacing: 1px;
                line-height: 16px;
            }

            .link{
                color: black;
                font-weight: 600;
                text-decoration: underline;
            }

            .mt{
                margin-top:7px;
            }

            .yes-its-me{
                margin-top: 22px;
                margin-bottom: 25px;
            }

            .yes-its-me p{
                padding-left: 22px;
                font-weight:600;
                letter-spacing:1.5px;
                margin-top: 1.5px;
                font-size: 15px;
            }

            .arrow{
                width: 2%;
                vertical-align: middle;
                margin-left: 6px;
            }

            .tick{
                width: 28%;
                margin-left: 35px;
                vertical-align: middle;
            }

            .brands-card{
                margin-left: 45px;
                margin-right: 45px;
                border-top: 1px solid black;
                border-bottom: 1px solid black;
                margin-top: 40px;
            }
            
            .brands-container{
                text-align: center;
                margin-top: 20px;
                margin-bottom: 40px;

            }
            
            .brands{
                display: inline-block;
                width: 10%;
                margin: 0px 17px;
            }

            .brands:first-child {
                margin-left: 0;
            }

            .brands:last-child {
                margin-right: 0;
            }

            .zimo-img{
                width: 13%;
            }
            .footer-top{
                width:10%;
                margin-top: 20px; 
            }
            
            .zimo-group{
                text-align: center;
            }
            .zimo-group p{
                display: inline-block; 
                font-size: 8px;
                letter-spacing: 1px;
                word-spacing: 2px;
            }

            .zimo-group img{
                display: inline-block; 
                margin-left: 4px;
                width: 11px;
                vertical-align: bottom;
            }

            .copyright-text{
                font-size: 8px;
                letter-spacing: 1px;
                word-spacing: 2px;
                margin-top: 10px;
                margin-left: 155px;
            }

            .copyright-text img{
                width: 62px;
                margin-left: 68px;
            }

            .end-note{
                text-align: center;
                font-size: 8px;
                letter-spacing: 1px;
                word-spacing: 0px;
                margin-top: 20px;
            }

            .end-note img{
                width: 1%;
                margin-right: 5px;
            }


            @media  only screen and (max-width: 590px) {
                .text{
                    font-size: 11px;
                }

                .body-text{
                    font-size: 11px;
                }

                .brands{
                    margin: 0px 17px;
                }

            
                .copyright-text img {
                    width: 55px;
                    margin-left: 55px;
                }


            }

            @media  only screen and (max-width: 575px) {
            
                .copyright-text img {
                    width: 53px;
                    margin-left: 57px;
                }
                .copyright-text {
                    word-spacing: 1px;
                }

            }

            @media  only screen and (max-width: 559px) {
                .brands{
                    margin: 0px 16px;
                }

                .copyright-text img {
                    margin-left: 43px;
                }

            }

            @media  only screen and (max-width: 545px) {

                .copyright-text img {
                    margin-left: 33px;
                    width: 41px;
                }

                .card {
                    padding-right: 28px;
                    padding-left: 28px;
                }

            }
            @media  only screen and (max-width: 519px) {

                .card{
                    padding-right: 25px;
                    padding-left: 25px;
                }
              
                .copyright-text{
                    margin-left: 102px;
                }
                .copyright-text img {
                    margin-left: 50px;
                }
            }

            @media  only screen and (max-width: 482px) {

                /* .brands-card {
                    margin-left: 30px;
                    margin-right: 30px;
                } */
                .brands {
                    margin: 0px 15px;
                }

                .body-text {
                    letter-spacing: 0.7px;
                }
                .copyright-text {
                    margin-left: 47px;
                }
                
                .copyright-text img {
                    width: 44px;
                    margin-left: 53px;
                }
            }

            @media  only screen and (max-width: 445px) {

                .brands {
                    margin: 0px 13px;
                }

                .copyright-text {
                    margin-left: 56px;
                }
                
                .copyright-text img {
                    width: 42px;
                    margin-left: 8px;
                }
            }

            @media  only screen and (max-width: 425px) {
                
                .head-text{
                    font-size: 13px;
                }

                .yes-its-me p {
                    padding-left: 13px;
                }

                .tick {
                    width: 27%;
                    margin-left: 17px;
                }

                .brands-card{
                    margin-left: 20px;
                    margin-right: 20px;
                }

                .brands {
                    margin: 0px 10px;
                }

                .text {
                    font-size: 10px;
                }
                .copyright-text {
                    margin-left: 56px;
                }

                .copyright-text img {
                    width: 40px;
                    margin-left: 20px;
                }

                .end-note img {
                   width: 2%;
                }

            }

            @media  only screen and (max-width: 403px) {
                .card {
                    padding-right: 20px;
                    padding-left: 20px;
                }

                .brands-card {
                    margin-left: 15px;
                    margin-right: 15px;
                }
                .copyright-text img {
                    margin-left: 9px;
                }

                .end-note{
                    font-size: 7px;
                }
                .end-note img{
                    width: 2%;
                }

            }

            @media  only screen and (max-width: 392px) {

                .brands-card {
                    margin-left: 10px;
                    margin-right: 10px;
                }
                .copyright-text img {
                    margin-left: 0px;
                }

                .copyright-text{
                    margin-left: 0px;
                }
            }

            @media  only screen and (max-width: 375px) {

                .arrow {
                    width: 4%;
                }

                .tick {
                    width: 32%;
                    margin-left: 9px;
                }

                .head-text {
                    font-size: 12px;
                }
                .yes-its-me p{
                    font-size: 14px;
                    font-weight: 900;
                }
        
                .body-text{
                    letter-spacing: 0.7px;
                }

                .copyright-text {
                    margin-left: 12px;
                }
                .copyright-text img {
                    margin-left: 19px;
                }
            }

            @media  only screen and (max-width: 360px) {
            
                .card {
                    padding-right: 18px;
                    padding-left: 18px;
                }
                .copyright-text {
                    margin-left: 8px;
                }
                .copyright-text img {
                    margin-left: 8px;
                }
            
            }
               

            @media  only screen and (max-width: 344px) {


                .brands-container{
                    margin-top: 17px;
                    margin-bottom: 28px;
                }

                .brands{
                    width: 8%;
                }

                .end-note{
                    font-size: 7px;
                }
                .end-note img {
                    width: 2%;
                }

                .copyright-text {
                    margin-left: 5px;
                    font-size:7px;
                }
                .copyright-text img {
                    margin-left: 0px;
                }
            
            }

            @media  only screen and (max-width: 320px) {
               
                .copyright-text {
                    font-size: 7px;
                    word-spacing: 0px;
                    margin-left: 0px;
                }
            }

        </style>

    </head>
    <body>

    <div id= "main">
        <div class="card">
            <div class="row logo" style="margin:auto;">
                <img src="<?php echo e(url('https://firebasestorage.googleapis.com/v0/b/uploadimage-6caaa.appspot.com/o/images%2FZITRANSFER.png?alt=media&token=e5cfa074-0fcd-4b17-9665-70264b1382d4')); ?>" width="100%"  alt="ztfr-logo">
            </div>
                
            <p class="text mt" style="text-decoration:none !important; color:black !important;">[<?php echo e(@$email); ?>]</p>

            <br>
            <h4 class="head-text mt">ALMOST AT THE FINISH LINE</h4>

            <br>
            <p class="body-text" style="margin-top: 12px;">Hello [<?php echo e(@$display_name); ?>]</p>

            <br>
            <p class="body-text">Please verify your email address to finish setting up your ZiTransfer User ID. You will
                then be able to continue to enjoy all the features that ZTFR has to offer.</p>
            
            <div class="yes-its-me">
                <a href="<?php echo e(url('http://zitransfer.com/verify-email?session=encrypt(email)')); ?>">
                    <p style="color:black;">YES IT'S ME 
                        <img src="<?php echo e(url('https://firebasestorage.googleapis.com/v0/b/uploadimage-6caaa.appspot.com/o/images%2FArrown%20large%20open.png?alt=media&token=e7f2378a-f874-4577-84bc-21d17da81b69')); ?>"  class="arrow" alt="arrow">
                        <img src="<?php echo e(url('https://firebasestorage.googleapis.com/v0/b/uploadimage-6caaa.appspot.com/o/images%2FCreate%20User%20ID%20Tick%20Transparent.png?alt=media&token=6ef85cbe-5705-4dc1-b5b5-f12885ce3a0b')); ?>"  class="tick" alt="tick">
                    </p>
                </a>
            </div>

            <p class="body-text">Don't see the Create User ID check/tick mark? No issues , here is <a href="http://zitransfer.com/verify-email?session=encrypt(email)" class="link">your link</a></p>

            <?php
                $encodedEmail = base64_encode($email);
                $url = "http://127.0.0.1:8000/api/unauthenticated-user?email={$encodedEmail}";
                $request_url = "http://127.0.0.1:8000/api/request-new?email={$encodedEmail}";
            ?>

            <br>
            <p class="body-text">This link will be active for 48 hours . If you don't make it in time, no worries, you can 
                always  <a href="<?php echo e($request_url); ?>" class="link">request a new one here</a>.</p>


            <br>
            <p class="body-text"> 
                If you weren’t expecting this email and you believe it was sent in error, someone else
                may have entered your email address by accident. Please disregard this email or if you want to know what all
                the fuss is about, <a href="<?php echo e($url); ?>" class="link">click here</a>.
            </p>

            <div class="brands-card">

                <p class="text" style="margin-top: 15px;">OUR BRANDS</p>

                <div class="brands-container">
                    <a href="<?php echo e(url('https://zitransfer.com/')); ?>" ><img src="<?php echo e(url('https://firebasestorage.googleapis.com/v0/b/uploadimage-6caaa.appspot.com/o/images%2FZTFR.png?alt=media&token=291a63d9-8fbe-4025-824d-c5c7701fec74')); ?>" class="brands" alt="ztfr"></a>
                    <a href="<?php echo e(url('https://zimomeet.com/')); ?>"><img src="<?php echo e(url('https://firebasestorage.googleapis.com/v0/b/uploadimage-6caaa.appspot.com/o/images%2FZIMO%20MEET.png?alt=media&token=207ff61c-3154-482b-ae1d-d6a5b6b3d201')); ?>" class="brands" alt="zimo-meet"></a>
                    <a href="<?php echo e(url('https://zimogroup.org/')); ?>"><img src="<?php echo e(url('https://firebasestorage.googleapis.com/v0/b/uploadimage-6caaa.appspot.com/o/images%2FZIMO%20(thicker)%20updated%20B.png?alt=media&token=558db11a-1798-4907-bb06-9f09f60a2601')); ?>" class="brands zimo-img" alt="zimo"></a>
                    <a href=""><img src="<?php echo e(url('https://firebasestorage.googleapis.com/v0/b/uploadimage-6caaa.appspot.com/o/images%2FZiDoc%20with%20Sec%20Lock.png?alt=media&token=b97fbdfd-01e4-4393-9bc7-9c0df71f1acb')); ?>" class="brands" alt="zimo-doc"></a>
                    <a href=""><img src="<?php echo e(url('https://firebasestorage.googleapis.com/v0/b/uploadimage-6caaa.appspot.com/o/images%2FZIMO%20BRICK%20AI.png?alt=media&token=1375e38e-b2e3-47ae-bceb-b9cab4bdf383')); ?>" class="brands" alt="zimo-ai"></a>
                </div>

            </div>

            <p class="text" style="margin-top: 33px;  text-align: left; text-decoration:none !important; color:black;">To make sure our emails arrive, please add noreply@zitransfer.com to your contact.</p>

            <div class="mt" style="text-align: center;">
                <a href="<?php echo e(url('https://zitransfer.com/')); ?>">
                    <img src="<?php echo e(url('https://firebasestorage.googleapis.com/v0/b/uploadimage-6caaa.appspot.com/o/images%2FZTFR.png?alt=media&token=291a63d9-8fbe-4025-824d-c5c7701fec74')); ?>" class="footer-top"  alt="ztfr">
                </a>
                </div>

            <div class="zimo-group">
                <p>ZIMO GROUP LONDON UNITED KINGDOM <img src="<?php echo e(url('https://firebasestorage.googleapis.com/v0/b/uploadimage-6caaa.appspot.com/o/images%2FCountry%20Flag.png?alt=media&token=a0cb9402-fc24-464e-8709-c3559ebdbabd')); ?>" alt="uk-flag"> </p>
            </div>

            <div style="text-align: center;">
                <a href="#" style="pointer-events:none;"><img src="<?php echo e(url('https://firebasestorage.googleapis.com/v0/b/uploadimage-6caaa.appspot.com/o/images%2FZIMO%20ZIG%20B.png?alt=media&token=8e3d7312-ba12-47d4-8d9d-3b2d476fe99f')); ?>" class="footer-top" alt="zimo-zig"></a>
            </div>
            

        </div>
        <p class="copyright-text">COPYRIGHT © 2023 ZIMO GROUP ALL RIGHTS RESERVED. <a href="#" style="pointer-events:none;"><img src="https://firebasestorage.googleapis.com/v0/b/uploadimage-6caaa.appspot.com/o/images%2FLET'S%20DO%20THIS.png?alt=media&token=a62703f7-0ef2-4dd8-82bc-45f0d7a47873')}}" alt="let-do-this"></a></p>

        <p class="end-note"><img src="<?php echo e(url('https://firebasestorage.googleapis.com/v0/b/uploadimage-6caaa.appspot.com/o/images%2FSecurity%20Lock%20B.png?alt=media&token=c1e62c4a-796f-4859-8211-08b91bb0ec58')); ?>" alt="sec-lock"> ZITRANSFER USES ADVANCED ENCRYPTION STANDARD (AES) 256-BIT TO PROTECT THE CONFIDENTIIALITY OF THE DATA YOU UPLOAD.</p>

    </div>

    </body>
</html><?php /**PATH C:\xampp\htdocs\backend-zitransfer\src\resources\views/admin/email/ztfr-email-1.blade.php ENDPATH**/ ?>