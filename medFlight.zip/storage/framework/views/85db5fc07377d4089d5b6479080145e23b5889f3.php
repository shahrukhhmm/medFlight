<a href="<?php echo e(url('admin')); ?>" class="navbar-brand">
    
    <img src="https://drive.google.com/uc?export=download&id=1tAc_lSfy3Ndu1HD5XzbOWUIv3S1ETKc8" alt="Med Flight" ><span style="color: black; font-size:12px">RN MEDFLIGHTS</span>

    

</a><?php /**PATH C:\xampp\htdocs\medFlight\resources\views/admin/layout/logo.blade.php ENDPATH**/ ?>