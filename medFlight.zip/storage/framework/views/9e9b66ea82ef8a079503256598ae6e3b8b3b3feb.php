<!DOCTYPE HTML>
<html>
<script src="https://canvasjs.com/assets/script/canvasjs.min.js"></script>

<body>
<div id="dailyBusiness" style="height: 370px; width: 100%; margin-top: 20px;">
</div>
</body>
</html>


<script type="text/javascript">

        var chartvisitor = new CanvasJS.Chart("dailyBusiness", {
            animationEnabled: true, 
		    animationDuration: 1000, 
            title: {
                text: 'Daily Visitors Report',
                fontFamily: "arial",
                fontSize: 25,
                fontWeight:"bold"
            },
            axisX: {
                // interval: 2,
                // intervalType: "day"
            },
            data: [
                {
                    type: "line",
                    dataPoints: <?php echo json_encode($dailyVisitors,
                        JSON_NUMERIC_CHECK); ?>
                }
            ]
        });
        chartvisitor.render();

</script>
<?php /**PATH C:\xampp\htdocs\backend-zitransfer\src\resources\views/admin/graph/daily-visitor.blade.php ENDPATH**/ ?>