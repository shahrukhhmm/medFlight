<a href="<?php echo e(url('admin')); ?>" class="navbar-brand">
    
    <img src="https://firebasestorage.googleapis.com/v0/b/uploadimage-6caaa.appspot.com/o/images%2FZTFR.png?alt=media&token=291a63d9-8fbe-4025-824d-c5c7701fec74" alt="ZIMO">

    

</a><?php /**PATH C:\xampp\htdocs\backend-zitransfer\src\resources\views/admin/layout/logo.blade.php ENDPATH**/ ?>