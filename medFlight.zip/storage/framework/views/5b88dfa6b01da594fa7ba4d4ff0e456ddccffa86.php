<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Zimo Transfer</title>

        <style>
            *{
                font-family:'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;
                margin: 0;padding: 0;box-sizing: border-box;
                font-weight: 400;
            }

            body{
                background-color: white;
                letter-spacing: 3px;
            }

            #main{
                background-color: white;
                max-width: 592px;
                margin: auto;
                border-left: 2px solid #e1e1e1;
                border-right: 2px solid #e1e1e1;
                padding: 10px;
            }

            a{
                text-decoration: none;
                color: black !important;
            }

            .card{
                padding-right: 40px;
                padding-left: 40px;
                padding-top: 10px;
                padding-bottom: 10px;
            }

            .logo{
                width: 190px;
                height: 46px;
                padding: 8px;
            }

            .text{
                font-size: 11px;
                letter-spacing: 1px;
                text-align: center;
                line-height: 16px;
                /* color: black !important;
                text-decoration: none !important; */
            }
            
            .head-text{
                letter-spacing: 2.4px;
                text-align: center;
                font-weight: 100;
                font-size: 17px;
            }

            .ztfr-top{
                width: 7%;
            }

            .ztfr-logo{
                width: 8%;
                margin-bottom: 20px;
                margin-left: 30px;
            }

            .body-text{
                font-size: 11px;
                letter-spacing: 0.5px;
                line-height: 16px;
            }

            .link{
                color: black;
                font-weight: 600;
            }

            .mt{
                margin-top:7px;
            }
            
            .lets-get-text{
                font-size: 10px;
                letter-spacing: 1.5px;
                margin-top: 23px;
            }

            .lets-get-text span{                         
                display: block;
                font-size: 18px;
                letter-spacing: 1.5px;
                margin-top:1px;
            }

            .ztfr-screen1 img, .ztfr-screen2 img{
                width: 90%;
            }

            .ztfr-screen3 img{
                width: 77%;
            }

            .share-text, .control-text{
                font-size: 18px;
                letter-spacing: 1px;
                font-weight: 500;
            }

            .lets-do-this-logo{
                width: 22%;
                margin-top: 20px;
            }

            .arrow{
                width: 7px;
                margin-left: 2px;
                margin-bottom: 21px;
            }

            .share-logos{
                text-align: center;
                margin-top: 16px;
            }

            .share-logos img{
                display: inline-block;
                margin: 0px 5px;
                width: 11%;
            }
        

            .brands-card{
                margin-left: 45px;
                margin-right: 45px;
                border-top: 1px solid black;
                border-bottom: 1px solid black;
                margin-top: 40px;
            }
            
            .brands-container{
                text-align: center;
                margin-top: 20px;
                margin-bottom: 40px;

            }
            
            .brands{
                display: inline-block;
                width: 10%;
                margin: 0px 17px;
            }

            .brands:first-child {
                margin-left: 0;
            }

            .brands:last-child {
                margin-right: 0;
            }

            .zimo-img{
                width: 13%;
            }
            .footer-top{
                width:10%;
                margin-top: 20px; 
            }
            
            .zimo-group{
                text-align: center;
            }
            .zimo-group p{
                display: inline-block; 
                font-size: 8px;
                letter-spacing: 1px;
                word-spacing: 2px;
            }

            .zimo-group img{
                display: inline-block; 
                margin-left: 4px;
                width: 11px;
                vertical-align: bottom;
            }

            .copyright-text{
                text-align: center;
                font-size: 8px;
                letter-spacing: 1px;
                word-spacing: 2px;
                margin-top: 10px;
            }
            .end-note{
                text-align: center;
                font-size: 8px;
                letter-spacing: 1px;
                word-spacing: 0px;
                margin-top: 10px;
            }

            .end-note img{
                width: 1%;
                margin-right: 5px;
            }

            @media  only screen and (max-width: 590px) {
                .text{
                    font-size: 11px;
                }

                .body-text{
                    font-size: 11px;
                }

                .brands{
                    margin: 0px 17px;
                }

            }

            @media  only screen and (max-width: 559px) {
                .brands{
                    margin: 0px 16px;
                }
            }

            @media  only screen and (max-width: 545px) {
                .card {
                    padding-right: 28px;
                    padding-left: 28px;
                }
                .share-logos img {
                    margin: 0px 4px;
                }
            }

            @media  only screen and (max-width: 519px) {

                .card{
                    padding-right: 25px;
                    padding-left: 25px;
                }
                .brands-card {
                    margin-left: 35px;
                    margin-right: 35px;
                }
            }

            @media  only screen and (max-width: 482px) {

                .brands-card {
                    margin-left: 30px;
                    margin-right: 30px;
                }
                .brands {
                    margin: 0px 15px;
                }

                .body-text {
                    letter-spacing: 0.7px;
                }
                .ztfr-logo {
                    width: 12%;
                }

            }

            @media  only screen and (max-width: 445px) {

                .brands {
                    margin: 0px 13px;
                }

            }

            @media  only screen and (max-width: 425px) {
                
                .head-text{
                    font-size: 13px;
                }

                .yes-its-me p {
                    padding-left: 13px;
                }

                .ztfr-top {
                    width: 9%;
                }

                .ztfr-logo{
                    width: 12%;
                }

                .tick {
                    width: 27%;
                    margin-left: 17px;
                }

                .brands-card{
                    margin-left: 20px;
                    margin-right: 20px;
                }

                .brands {
                    margin: 0px 10px;
                }

                .text {
                    font-size: 10px;
                }

                .copyright-text {
                    word-spacing: 1px;
                }

                .share-logos img {
                    margin: 0px 5px;
                    width: 10%;
                }

            }


            @media  only screen and (max-width: 403px) {
                .card {
                    padding-right: 20px;
                    padding-left: 20px;
                }

                .brands-card {
                    margin-left: 15px;
                    margin-right: 15px;
                }
                .ztfr-logo{
                    width: 12%;
                }
                .lets-do-this-logo {
                    width: 24%;
                }

                .arrow{
                    margin-bottom: 20px;
                }

            }

            @media  only screen and (max-width: 392px) {

                .copyright-text {
                    word-spacing: 0px;
                    font-size: 7px;
                }

                .brands-card {
                    margin-left: 10px;
                    margin-right: 10px;
                }

                .share-logos img {
                    margin: 0px 3px;
                }

                .end-note{
                    font-size: 7px;
                }
                .end-note img{
                    width: 2%;
                }
            }

            @media  only screen and (max-width: 375px) {

                .head-text {
                    font-size: 12px;
                }
                .yes-its-me p{
                    font-size: 13px;
                }
                .ztfr-top {
                    width: 9%;
                }

            
                .brands {
                    margin: 0px 8px;
                    width: 11%;
                }
        
                .body-text{
                    letter-spacing: 0.7px;
                }
                .copyright-text {
                    font-size: 7px;
                    word-spacing: 0px;
                }

                .ztfr-top{
                    width: 8%; /**/
                }

                .end-note{
                    font-size: 7px;
                }
                .end-note img{
                    width: 2%;
                }
            }

            @media  only screen and (max-width: 360px) {

                .card {
                    padding-right: 18px;
                    padding-left: 18px;
                }
                
            }

            @media  only screen and (max-width: 344px) {

                .brands-container{
                    margin-top: 17px;
                    margin-bottom: 28px;
                }
               
                .body-text {
                    line-height: 14px;
                }

                .lets-do-this-logo {
                    width: 33%;
                }

                .brands{
                    width: 9%;
                }

                .ztfr-top {
                    width: 9%;
                }
                .copyright-text {
                    word-spacing: 0px;
                }

                .share-logos img {
                    margin: 0px 3px;
                }

                .end-note{
                    font-size: 7px;
                }
                .end-note img {
                    width: 2%;
                }

          
            }

            @media  only screen and (max-width: 313px){
                .ztfr-top {
                    width: 10%;
                }
                .share-logos img {
                    margin: 0px 2px;
                }
            }

            @media  only screen and (max-width: 296px) {
                .share-logos img {
                    margin: 0px 2px;
                }
                .end-note{
                    font-size: 7px;
                }
                .lets-do-this-logo {
                    width: 31%;
                }
                .ztfr-logo{
                    width: 16%;
                }
                .brands-card {
                    margin-left: 10px;
                    margin-right: 10px;
                }
            }

            @media  only screen and (max-width: 288px) {

                .card {
                    padding-right: 17px;
                    padding-left: 17px;
                }
                .brands-card {
                    margin-left: 6px;
                    margin-right: 6px;
                }

            }

            @media  only screen and (max-width: 278px) {
                .card{
                    padding-right: 0px;
                    padding-left: 0px;
                }
                .end-note {
                    font-size: 6px;
                }
                .ztfr-top {
                    width: 12%;
                }
            }
        </style>

    </head>
    <body>

    <div id= "main">
        <div class="card">
            <div class="row logo" style="margin:auto;">
                <img src="https://firebasestorage.googleapis.com/v0/b/uploadimage-6caaa.appspot.com/o/images%2FZITRANSFER.png?alt=media&token=e5cfa074-0fcd-4b17-9665-70264b1382d4" width="100%"  alt="ztfr-logo">
            </div>
                
            <p class="text mt" style="text-decoration:none !important; color:black !important;"><?php echo e(@$email); ?></p>

            <br>
            <p class="head-text mt">GREAT! YOUR <a href="#" style="pointer-events:none;"><img src="https://firebasestorage.googleapis.com/v0/b/uploadimage-6caaa.appspot.com/o/images%2FZTFR.png?alt=media&token=291a63d9-8fbe-4025-824d-c5c7701fec74" class="ztfr-top" alt="ztfr-logo"></a></p>
            <p class="head-text" style="margin-top: 2px;">USER ID IS OFFICIAL</p>

            <br>
            <p class="body-text" style="margin-top: 20px;">Hello <?php echo e(@$display_name); ?> <?php echo e(@$organization); ?></p>

            <br>
            <p class="body-text">It's OFFICIAL! Welcome to your new ZiTransfer User ID account. Now it’s super easier 
                to get all your files where they need to be. Unlimited and FREE!
            </p>
        

            <p class="lets-get-text">LET'S GET <span style="font-weight: 500;">STARTED</span></p>

            <p class="body-text" style="margin-top: 16px;">With a ZTFR User ID account you don’t have to worry about verifying your email
                whenever you send a file. Just drag and drop up to a whopping 1TB and share everything
                and anything with a Link, QR Code, Email, WhatsApp, Message, Facebook, or X (Twitter).
            </p>

            <br>
            <div class="ztfr-screen1" style="text-align: center;" >
                <a href="#" style="pointer-events:none;"><img src="https://firebasestorage.googleapis.com/v0/b/uploadimage-6caaa.appspot.com/o/images%2Fztfr%2FHomescreen%20visual%201.png?alt=media&token=3d29e984-0fc6-40fe-bd40-ec943be42dc7"  alt="ztfr-screen1"></a>
            </div>

            <p class="share-text" style="margin-top: 17px;">SHARE</p>

        </div>
        
        <div class="share-logos">
            <a href="#"><img src="https://firebasestorage.googleapis.com/v0/b/uploadimage-6caaa.appspot.com/o/images%2FLink.png?alt=media&token=75eb15a5-eeba-4dd2-93a0-dc764f4e0517" alt="Link">
            <a href="#"><img src="https://firebasestorage.googleapis.com/v0/b/uploadimage-6caaa.appspot.com/o/images%2FQR%20Code.png?alt=media&token=ede7cb87-f85d-4fdd-be76-eb00394d6fb1" alt="QR code">
            <a href="https://mail.google.com/" style="text-decoration:none;"><img src="https://firebasestorage.googleapis.com/v0/b/uploadimage-6caaa.appspot.com/o/images%2FEmail.png?alt=media&token=3167dbe6-dfe0-4609-9672-1c1d3c56395d" alt="Email">
            <a href="https://web.whatsapp.com/" style="text-decoration:none;"><img src="https://firebasestorage.googleapis.com/v0/b/uploadimage-6caaa.appspot.com/o/images%2FWhatsApp.png?alt=media&token=0d17e287-a865-4b2f-b7f4-3733345f41b8" alt="WhatsApp">
            <a href="https://www.messenger.com/" style="text-decoration:none;"><img src="https://firebasestorage.googleapis.com/v0/b/uploadimage-6caaa.appspot.com/o/images%2FMessages.png?alt=media&token=3b4ea2ae-de3c-4d25-b0a0-7896d22f352f" alt="Message">
            <a href="https://www.facebook.com/" style="text-decoration:none;"><img src="https://firebasestorage.googleapis.com/v0/b/uploadimage-6caaa.appspot.com/o/images%2FFacebook.png?alt=media&token=70df4d67-abf1-408c-a3bf-e340feb525cf" alt="Facebook"></a>
            <a href="https://twitter.com/" style="text-decoration:none;"><img src="https://firebasestorage.googleapis.com/v0/b/uploadimage-6caaa.appspot.com/o/images%2FTwitter%20X.png?alt=media&token=0074a346-bddb-45ee-92ec-0e1e11124e5b" alt="Twitter"></a>
        </div>

        <div class="card">
            <br>
            <div class="ztfr-screen2" style="text-align: center;" >
                <a href="#" style="pointer-events:none;"><img src="https://firebasestorage.googleapis.com/v0/b/uploadimage-6caaa.appspot.com/o/images%2Fztfr%2FHomescreen%20visual%202.png?alt=media&token=5c86b18c-935d-4ca1-97e4-51740d966f61"  alt="ztfr-screen2"></a>
            </div>
            
            <br>
            <p class="control-text mt">CONTROL</p>

            <br>
            <p class="body-text">Sent the wrong version? Forgot to include someone? With unlimited storage for sent files, and 
                with multiple options on how to share, you can easily go back and manage your ZTFR's up to 7 days after you send them. It' s that easy.
            </p>

            <br>
            <div class="ztfr-screen3" style="text-align: center;" >
                <a href="#" style="pointer-events:none;"><img src="https://firebasestorage.googleapis.com/v0/b/uploadimage-6caaa.appspot.com/o/images%2Fztfr%2FHomescreen%20visual%203.png?alt=media&token=1ffc2d73-0191-4deb-a566-8a5cc1638f92"  alt="ztfr-screen3"></a>
            </div>

            <br>
            <div style="text-align: center;">
                <a href="https://zitransfer.com/" style="text-decoration: none;">
                    <img src="https://firebasestorage.googleapis.com/v0/b/uploadimage-6caaa.appspot.com/o/images%2FLET'S%20DO%20THIS.png?alt=media&token=a62703f7-0ef2-4dd8-82bc-45f0d7a47873"  class="lets-do-this-logo" alt="arrow">
                    <img src="https://firebasestorage.googleapis.com/v0/b/uploadimage-6caaa.appspot.com/o/images%2FZTFR.png?alt=media&token=291a63d9-8fbe-4025-824d-c5c7701fec74" class="ztfr-logo" alt="ztfr-logo">
                    <img src="https://firebasestorage.googleapis.com/v0/b/uploadimage-6caaa.appspot.com/o/images%2FArrown%20large%20open.png?alt=media&token=e7f2378a-f874-4577-84bc-21d17da81b69"  class="arrow" alt="arrow">
                </a>
            </div>


            <div class="brands-card">

                <p class="text" style="margin-top: 15px;">OUR BRANDS</p>

                <div class="brands-container">
                    <a href="https://zitransfer.com/" style="text-decoration:none;"><img src="https://firebasestorage.googleapis.com/v0/b/uploadimage-6caaa.appspot.com/o/images%2FZTFR.png?alt=media&token=291a63d9-8fbe-4025-824d-c5c7701fec74" class="brands" alt="ztfr">
                    <a href="https://zimomeet.com/" style="text-decoration:none;"><img src="https://firebasestorage.googleapis.com/v0/b/uploadimage-6caaa.appspot.com/o/images%2FZIMO%20MEET.png?alt=media&token=207ff61c-3154-482b-ae1d-d6a5b6b3d201" class="brands" alt="zimo-meet">
                    <a href="https://zimogroup.org/" style="text-decoration:none;"><img src="https://firebasestorage.googleapis.com/v0/b/uploadimage-6caaa.appspot.com/o/images%2FZIMO%20(thicker)%20updated%20B.png?alt=media&token=558db11a-1798-4907-bb06-9f09f60a2601" class="brands zimo-img" alt="zimo">
                    <a href="" style="text-decoration:none;"><img src="https://firebasestorage.googleapis.com/v0/b/uploadimage-6caaa.appspot.com/o/images%2FZiDoc%20with%20Sec%20Lock.png?alt=media&token=b97fbdfd-01e4-4393-9bc7-9c0df71f1acb" class="brands" alt="zimo-doc">
                    <a href="" style="text-decoration:none;"><img src="https://firebasestorage.googleapis.com/v0/b/uploadimage-6caaa.appspot.com/o/images%2FZIMO%20BRICK%20AI.png?alt=media&token=1375e38e-b2e3-47ae-bceb-b9cab4bdf383" class="brands" alt="zimo-ai">
                </div>

            </div>

            <p class="text" style="margin-top: 33px;  text-align: left;">You received this because you subscribed to updates from ZiTransfer. If you no longer
                wish to receive updates you can disable them from within your ZTFR User ID Account.</p>

            <div class="mt" style="text-align: center;">
                <a href="https://zitransfer.com/" style="text-decoration: none;">
                    <img src="https://firebasestorage.googleapis.com/v0/b/uploadimage-6caaa.appspot.com/o/images%2FZTFR.png?alt=media&token=291a63d9-8fbe-4025-824d-c5c7701fec74" class="footer-top" alt="ztfr">
                </a>
                </div>

            <div class="zimo-group">
                <p>ZIMO GROUP LONDON UNITED KINGDOM <img src="https://firebasestorage.googleapis.com/v0/b/uploadimage-6caaa.appspot.com/o/images%2FCountry%20Flag.png?alt=media&token=a0cb9402-fc24-464e-8709-c3559ebdbabd" alt="uk-flag"> </p>
            </div>

            <div style="text-align: center;">
                <a href="#" style="pointer-events:none;"><img src="https://firebasestorage.googleapis.com/v0/b/uploadimage-6caaa.appspot.com/o/images%2FZIMO%20ZIG%20B.png?alt=media&token=8e3d7312-ba12-47d4-8d9d-3b2d476fe99f" class="footer-top" alt="zimo-zig"></a>
            </div>
            
            <p class="copyright-text">COPYRIGHT © 2023 ZIMO GROUP ALL RIGHTS RESERVED.</p>
        </div>
        <p class="end-note"><img src="https://firebasestorage.googleapis.com/v0/b/uploadimage-6caaa.appspot.com/o/images%2FSecurity%20Lock%20B.png?alt=media&token=c1e62c4a-796f-4859-8211-08b91bb0ec58" alt="sec-lock"> ZITRANSFER USES ADVANCED ENCRYPTION STANDARD (AES) 256-BIT TO PROTECT THE CONFIDENTIIALITY OF THE DATA YOU UPLOAD.</p>
    </div>

    </body>
</html><?php /**PATH C:\xampp\htdocs\backend-zitransfer\src\resources\views/admin/email/account-official.blade.php ENDPATH**/ ?>