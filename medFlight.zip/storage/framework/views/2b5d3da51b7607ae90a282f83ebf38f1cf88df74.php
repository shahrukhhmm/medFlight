<div class="bg-image"></div>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        const backgroundContainer = document.querySelector('.bg-image');
        const images = <?php echo json_encode($imageUrls); ?>;

        let currentImageIndex = 0;

        function changeBackground() {
            currentImageIndex = (currentImageIndex + 1) % images.length;
            

            if (currentImageIndex === images.length) {
                currentImageIndex = 0;
            }

            backgroundContainer.style.backgroundImage = `url('${images[currentImageIndex]}')`;
        }

        changeBackground();

        setInterval(changeBackground, 15000); 
    });

</script><?php /**PATH C:\xampp\htdocs\backend-zitransfer\src\resources\views/admin/components/background-image.blade.php ENDPATH**/ ?>