

<?php $__env->startSection('title', 'Visitor Detail'); ?>
 

<?php echo $__env->make('admin.components.styles', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php $__env->startSection('body'); ?>

    <div class="row">
        <div class="col-lg-4">
            
            <div class="card mb-4">
                <div class="card-body text-center" style="border-radius: 15px; box-shadow: rgb(149 157 165 / 7%) 0px 8px 24px; margin-top: 40px;">
                            
                    <div class="d-flex justify-content-center mt-4">
                        <div class="flag-frame">
                            <img src="<?php echo e(@$data->country->flag_url); ?>" alt="Image Alt Text" class="circle-image">
                        </div>
                    </div>

                    <div class="row mt-5 pl-3 flex-nowrap">
                        <div class="col-sm-6 text-left">
                            <h6 class="">ID</h6>
                        </div>
                        <div class="col-sm-6 text-left">
                            <p class="text-muted">#ZM<?php echo e(@$data->id); ?></p>
                        </div>
                    </div>

                    <div class="row pl-3 flex-nowrap">
                        <div class="col-sm-6 text-left">
                            <h6 class="">IP Address</h6>
                        </div>
                        <div class="col-sm-6 text-left">
                            <p class="text-muted"><?php echo e(@$data->ip_address); ?></p>
                        </div>
                    </div>

                    <div class="row pl-3 flex-nowrap">
                        <div class="col-sm-6 text-left">
                            <h6 class="">Platform</h6>
                        </div>
                        <div class="col-sm-6 text-left">
                            <p class="text-muted"><?php echo e(@$data->platform); ?></p>
                        </div>
                    </div>
                   
                    <div class="row pl-3 flex-nowrap">
                        <div class="col-sm-6 text-left">
                            <h6 class="">Browser</h6>
                        </div>
                        <div class="col-sm-6 text-left">
                            <p class="text-muted"><?php echo e(@$data->browser); ?></p>
                        </div>
                    </div>

                    <div class="row pl-3 flex-nowrap">
                        <div class="col-sm-6 text-left">
                            <h6 class="">Browser Version</h6>
                        </div>
                        <div class="col-sm-6 text-left">
                            <p class="text-muted"><?php echo e(@$data->browser_version); ?></p>
                        </div>
                    </div>

                    <div class="row pl-3 flex-nowrap">
                        <div class="col-sm-6 text-left">
                            <h6 class=" ">Device</h6>
                        </div>
                        <div class="col-sm-6 text-left">
                            <p class="text-muted "><?php echo e(@$data->device); ?></p>
                        </div>
                    </div>    

                    <div class="row pl-3 mb-2 flex-nowrap">
                        <div class="col-sm-6 text-left">
                            <h6 class="">System</h6>
                        </div>
                        <div class="col-sm-6 text-left">
                            <p class="text-muted "><?php echo e(@$data->system); ?></p>
                        </div>
                    </div>

                    
                </div>  
            </div>

        </div>   
        
        
        <div class="col-lg-8 col-sm-12">
            <div class="card mb-4">
                <div class="card-body" style="border-radius: 15px; padding: 35px; ">

                <div class="row mt-2 flex-nowrap">
                    <div class="col-sm-8">
                            <h6 class="">Visitor Id</h6>
                        
                            <p class="text-muted"><?php echo e(@$data->visitor_id); ?></p>
                        </div>
                        <div class="col-sm-4 text-center ">
                            <a target="_blank" href="https://maps.google.com/?q=<?php echo e(@$data->lat); ?>,<?php echo e(@$data->lng); ?>" style="margin:auto; " >
                                <p><i class="fas fa-map-marker-alt map"></i></p>
                            </a>
                            <h6>Find on map</h6>

                        
                        </div>
                    </div>
                    <h3 style="font-size: 24px; font-weight: 600;position: relative; font-size: 24px; font-weight: 600; top: -25px;">
                        Country Details
                    </h3>
                    

                    <div class="row pl-3 mt-2 flex-nowrap">
                        <div class="col-sm-6">
                            <h6 class="">Country Name</h6>
                        </div>
                        <div class="col-sm-6">
                            <p class="text-muted"><?php echo e(@$data->countryName); ?></p>
                        </div>
                    </div>
                   

                    <div class="row pl-3 flex-nowrap">
                        <div class="col-sm-6">
                            <h6 class="">City Name</h6>
                        </div>
                        <div class="col-sm-6">
                            <p class="text-muted"><?php echo e(@$data->cityName); ?></p>
                        </div>
                    </div>

                    <div class="row pl-3 flex-nowrap">
                        <div class="col-sm-6">
                            <h6 class="">Time Zone</h6>
                        </div>
                        <div class="col-sm-6">
                            <p class="text-muted"><?php echo e(@$data->timezone); ?></p>
                        </div>
                    </div>

                    
                    <div class="row pl-3 flex-nowrap">
                        <div class="col-sm-6">
                            <h6 class=" ">Country Code</h6>
                        </div>
                        <div class="col-sm-6">
                            <p class="text-muted "><?php echo e(@$data->countryCode); ?></p>
                        </div>
                    </div> 

                    <div class="row pl-3 flex-nowrap">
                        <div class="col-sm-6">
                            <h6 class=" ">Zip Code</h6>
                        </div>
                        <div class="col-sm-6">
                            <p class="text-muted "><?php echo e(@$data->zipCode); ?></p>
                        </div>
                    </div>    

                    <div class="row pl-3 flex-nowrap">
                        <div class="col-sm-6">
                            <h6 class="">Region Code</h6>
                        </div>
                        <div class="col-sm-6">
                            <p class="text-muted "><?php echo e(@$data->regionCode); ?></p>
                        </div>
                    </div>

                    <div class="row pl-3 flex-nowrap">
                        <div class="col-sm-6">
                            <h6 class="">Area Code</h6>
                        </div>
                        <div class="col-sm-6">
                            <p class="text-muted "><?php echo e(@$data->areaCode); ?></p>
                        </div>
                    </div>

                    <div class="row pl-3 flex-nowrap">
                        <div class="col-sm-6">
                            <h6 class="">Postal Code</h6>
                        </div>
                        <div class="col-sm-6">
                            <p class="text-muted "><?php echo e(@$data->postalCode); ?></p>
                        </div>
                    </div>

                    <div class="row pl-3 flex-nowrap">
                        <div class="col-sm-6">
                            <h6 class="">ISO Code</h6>
                        </div>
                        <div class="col-sm-6">
                            <p class="text-muted "><?php echo e(@$data->isoCode); ?></p>
                        </div>
                    </div>



                </div>
            </div>
        </div>

     
    </div>




<?php $__env->stopSection(); ?>


<script src="https://canvasjs.com/assets/script/canvasjs.min.js"></script>


<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.js"></script>

<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
<script src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js" defer></script>




<?php echo $__env->make('brackets/admin-ui::admin.layout.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\backend-zitransfer\src\resources\views/admin/visitors/visitor-detail.blade.php ENDPATH**/ ?>