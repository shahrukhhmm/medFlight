

<?php $__env->startSection('title', trans('admin.admin-user.actions.index')); ?>


<style>
    .dataTables_wrapper .role-listing td {
        text-align: left;
        vertical-align: middle;
    }

    .table-listing td:last-of-type {
        justify-content: flex-start !important;
    }

    .modal-footer{
        border-top: none !important;
    }
</style>

<?php $__env->startSection('body'); ?>

  

        <div class="row">
            <div class="col">
                <div class="card">
                    <div class="card-header">
                        <i class="fa fa-align-justify"></i> Roles
                        <a class="btn btn-primary btn-sm pull-right m-b-0 add" href="#" data-toggle="modal" data-target="#addRole" role="button"><i class="fa fa-plus"></i>&nbsp; New</a>
                    </div>
                    <div class="card-body" v-cloak>

                        <?php if(session()->has('message')): ?>
                            <div class="alert alert-success alert-dismissible fade show" role="alert">
                                <strong>Success</strong> &nbsp; <?php echo e(session()->get('message')); ?>

                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>                            
                        <?php endif; ?>

                    <div class="container">
                        <form id="filter-form" class="filter-form-container row">
                            <div class="col-sm-12 col-md-6 col-lg-5">
                                <label for="from_date" class="h6">From:</label>
                                <input type="date" id="from_date" class="form-control">
                            </div>
                            <div class="col-sm-12 col-md-6 col-lg-5">
                                <label for="to_date" class="h6">To:</label>
                                <input type="date" id="to_date" class="form-control">
                            </div>
                            <div style="margin-top: 30px" class="col-sm-12 col-md-6 col-lg-2 applyBtn">
                                <button type="submit" class="btn btn-sm btn-success">Apply Filter</button>
                            </div>
                        </form>
                    </div>

                        <table class="table table-hover role-listing table-listing">
                            <thead>
                                <tr>
                                     
                                    <th>ID</th>
                                    <th>Name</th>
                                    <th>Guard Name</th>
                                    <th>Created at</th>
                                    <th>Action</th>

                                </tr>
                            </thead>
                            <tbody>
                                
                               
                            </tbody>
                        </table>
 

	                  
                    </div>
                </div>
            </div>
        </div>





<div class="modal fade" id="addRole" tabindex="-1" role="dialog" saria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-md" role="document">
        <div class="modal-content ">

            <div class="modal-header d-flex justify-content-between">
                <h5 class="modal-title text-dark" id="exampleModalLabel">Add Role</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>

            <div class="modal-body text-dark">
                <form id="addRoleForm"  enctype="multipart/form-data"> 

                    <div id="sending-message" class="text-danger fw-bold"></div>
                    <br>

                        <div class="row d-flex justify-content-center align-items-center">
                            
                                <div class="form-group col-md-12">
                                   
                                    <label class="control-label">Name</label>
                                    <input type="text" name="name" id="name" class="form-control" required>

                                    <label class="control-label">Guard Name</label>
                                    <input type="text" name="guard_name" id="guard_name" class="form-control" required>
                    
                                </div>
                            </div>
                
                            <div class="modal-footer">
                                <button type="submit" class="btn btn-primary">Add</button>
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                            </div>
           
                </form> 
            </div>

        </div>
    </div>
</div>
 




<div class="modal fade" id="editRole" tabindex="-1" role="dialog" saria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-md" role="document">
        <div class="modal-content ">

            <div class="modal-header d-flex justify-content-between">
                <h5 class="modal-title text-dark" id="exampleModalLabel">Edit Role</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>

            <div class="modal-body text-dark">
                

                    <input type="hidden" name="role_id" id="role_id">
                    
                        <div id="update-message" class="text-danger fw-bold"></div>
                        <br>
                
                        <div class="row d-flex justify-content-center align-items-center">
                            
                                <div class="form-group col-md-12">
                                        
                                    <label class="control-label">Name</label>
                                    <input type="text" name="role_name" id="role_name" class="form-control">


                                    <label class="control-label">Guard Name</label>
                                    <input type="text" name="role_guard" id = "role_guard" class="form-control">
                                

                                </div>
                            </div>
                
                        <button type="submit" class="btn btn-primary float-lg-right " id="updateRoleBtn">Submit</button>
           
                
            </div>

        </div>
    </div>
</div>
<!--      -->








<?php $__env->stopSection(); ?>


<script src="https://canvasjs.com/assets/script/canvasjs.min.js"></script>


<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.js"></script>

<script src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js" defer></script>


<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>

<link rel="stylesheet" href="https://cdn.datatables.net/1.10.16/css/jquery.dataTables.min.css">


<script type="text/javascript">

    $(function () {
        setTimeout(function () {
      var table = $('.role-listing').DataTable({
          processing: true,
          serverSide: true,
          ajax: {
            url :"<?php echo e(url('/admin/roles-list')); ?>",
            data: function (d) {
            d.from_date = $('#from_date').val();
            d.to_date = $('#to_date').val();
        }
        },

        columns: [
            {data: 'id', name: 'id'},
            {data: 'name', name: 'name'},
            {data: 'guard_name', name: 'guard_name'},

            {data: 'created', name: 'created'},
            {
                data: 'action', 
                name: 'action', 
                orderable: false, 
                searchable: false
            },
          ]
        });

        $('#filter-form').on('submit', function (e) {
            e.preventDefault();
            $('.role-listing').DataTable().ajax.reload();
        });

    }, 2000); 
    });

</script>





<script>
   $(document).ready(function() {

        $('.add').click(function() {
            $('#addRole').modal('show');
        });

        $('#addRoleForm').submit(function(e) {
        e.preventDefault(); 


        var form = $(this);
        var formData = new FormData(form[0]);

        var csrfToken = document.querySelector('meta[name="csrf-token"]').getAttribute('content');

        $('#sending-message').text('Processing request, please wait...');
        
        $.ajax({
        url: "<?php echo e(url('admin/add-role')); ?>", 
        type: "POST",
        headers: {
          'X-CSRF-TOKEN': csrfToken
        },
        data: formData,
        contentType: false,
        processData: false,
        success: function(response) {
            // $('#addRole').modal('hide');
            // $('.role-listing').DataTable().ajax.reload();
            // location.reload();

        },
        error: function(xhr) {
            // Handle error response
            $('#sending-message').text(xhr);
            console.log(xhr.responseText);
        },
        complete: function() {
            $('#sending-message').text('');
            $('#addRole').modal('hide');
            // $('.role-listing').DataTable().ajax.reload();
            location.reload();

        }
        });

    });

    });

</script>





<script>
    $(document).ready(function () {
       
        $(document).on('click','.status' ,function () {
            var role_id = $(this).val();

            console.log(role_id);


            $('#editRole').modal('show');

            $.ajax({
                type: "GET",
                url: "/admin/edit-role/"+role_id,

                dataType:"json",
                success: function (response) {
                    console.log(response);

                    $('#role_id').val(role_id);
                    $('#role_name').val(response.role.name);
                    $('#role_guard').val(response.role.guard_name);


                }
            });
        });
    });
</script>






<script>


    $(document).ready(function() {
         $('#updateRoleBtn').on('click', function() {
            
            var role_id = $('#role_id').val();
            var name = $('#role_name').val();
            var guard_name = $('#role_guard').val();

            $('#update-message').text('Processing request, please wait...');

                $.ajax({
                    url: '/admin/update-role',
                    type: 'GET',
                    data: {
                        'role_id': role_id,
                        'name': name,
                        'guard_name': guard_name,

                    },
                    success: function(response) {
    
                    },
                    error: function(xhr) {
                        $('#update-message').text(xhr);
                    },
                    complete: function() {
                        $('#update-message').text('');
                        $('#editRole').modal('hide');
                        $('.role-listing').DataTable().ajax.reload();
                    }
                });
            });
        });


</script>
<?php echo $__env->make('brackets/admin-ui::admin.layout.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\backend-zitransfer\src\resources\views/admin/role/index.blade.php ENDPATH**/ ?>