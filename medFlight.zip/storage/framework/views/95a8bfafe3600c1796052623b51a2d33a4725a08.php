

<?php $__env->startSection('title', trans('admin.admin-user.actions.index')); ?>



<!-- font awesome -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css" integrity="sha512-MV7K8+y+gLIBoVD59lQIYicR65iaqukzvf/nwasF0nqhPay5w/9lJmVM2hMDcnK1OnMGCdVK+iQrJ7lzPJQd1w==" crossorigin="anonymous" referrerpolicy="no-referrer" />

<?php $__env->startSection('body'); ?>


<?php $__env->startSection('content'); ?>
<div class="container">
    
    <div class="row my-3">
        <div class="col-md-12">
            <div id="visitorCountries" style="height: 370px; width: 100%;"></div>
        </div>
    </div>


    <div class="row mt-5">
   
        <div class="col">
           
            <div id="visitor_data">
                <div class="card" style="overflow:scroll">
                    
                        <table class="table table-hover city-visitor-listing table-listing" style="overflow:scroll">
                            <thead>
                            <tr>                
                                <th>ID</th>
                                <th>Ip address</th>
                                <th>Country Name</th>
                                <th>City Name</th>
                                <th>Zip Code</th>
                                <th>Device</th>
                                <th>Platform</th>
                                <th>System</th>
                                <th>Latlng</th>
                                <th>Created at</th>
                                <th>Action</th>
                
                            </tr>
                            </thead>
                            <tbody>
                            
                        </tbody>
                     </table>
                
                </div>
            </div>

        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>


<script src="https://canvasjs.com/assets/script/canvasjs.min.js"></script>


<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.js"></script>

<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>


<script type="text/javascript">

    $(function () {
  
        var data = "<?php echo e($country); ?>";
      var table = $('.city-visitor-listing').DataTable({

          processing: true,
          serverSide: true,
          ajax: "<?php echo e(url('admin/city-visitor-list')); ?>"+ "/" + data,
          columns: [
              {data: 'id', name: 'id'},
              {data: 'ip_address', name: 'ip_address'},
              {data: 'countryName', name: 'countryName'},
              {data: 'cityName', name: 'cityName'},
              {data: 'zipCode', name: 'zipCode'},
              {data: 'device', name: 'device'},
              {data: 'platform', name: 'platform'},
              {data: 'system', name: 'system'},
              {
                  data: 'map', 
                  name: 'map', 
                  orderable: false, 
                  searchable: false
              },
              {data: 'created_at', name: 'created_at'},
              {
                  data: 'action', 
                  name: 'action', 
                  orderable: false, 
                  searchable: false
              },
          ]
      });
  
    });
</script>


<script type="text/javascript">
window.onload = function () {


    var visitorCities = new CanvasJS.Chart("visitorCountries", {
        theme: "dark1",
        exportFileName: "Doughnut Chart",
        exportEnabled: true,
        animationEnabled: true,
        title:{
            text: "<?php echo e($country); ?>"
        },
        legend:{
            cursor: "pointer",
            itemclick: explodecountry
        },
        data: [{
            type: "doughnut",
            innerRadius: 90,
            showInLegend: true,
            dataPoints:  <?php echo json_encode(@$visitorCity, JSON_NUMERIC_CHECK); ?>
        }]
    });

    visitorCountries.render();

    function explodecountry (e) {
   
        if(typeof (e.dataSeries.dataPoints[e.dataPointIndex].exploded) === "undefined" || !e.dataSeries.dataPoints[e.dataPointIndex].exploded) {
            e.dataSeries.dataPoints[e.dataPointIndex].exploded = true;
        } else {
            e.dataSeries.dataPoints[e.dataPointIndex].exploded = false;
        }
     
        e.visitorCountries.render();

    }

}
</script>




<?php echo $__env->make('brackets/admin-ui::admin.layout.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\backend-zitransfer\src\resources\views/admin/visitors/visitorCity.blade.php ENDPATH**/ ?>